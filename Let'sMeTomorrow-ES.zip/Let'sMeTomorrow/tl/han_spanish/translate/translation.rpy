translate han_spanish strings:

    old "Save"
    new "Ahorrar"

    old "Load"
    new "Carga"

    old "Delete"
    new "Borrar"

    old "Quick Save"
    new "Ahorro rápido"

    old "Quick Load"
    new "Carga rápida"

    old "Auto"
    new "Auto"

    old "Page"
    new "Página"

    old "Empty Slot"
    new "Espacio vacío"

    old "Are you sure?"
    new "¿Está seguro?"

    old "Yes"
    new "Sí"

    old "No"
    new "No"

    old "Cancel"
    new "Cancelar"

    old "OK"
    new "DE ACUERDO"

    old "Confirm"
    new "Confirmar"

    old "Preferences"
    new "Preferencias"

    old "Settings"
    new "Ajustes"

    old "Display"
    new "Mostrar"

    old "Audio"
    new "Audio"

    old "Accessibility"
    new "Accesibilidad"

    old "Text Speed"
    new "Velocidad de texto"

    old "Auto-Forward Time"
    new "Avance automático de la hora"

    old "Music Volume"
    new "Volumen de música"

    old "Sound Volume"
    new "Volumen de sonido"

    old "Voice Volume"
    new "Volumen de voz"

    old "Mute All"
    new "Silenciar todo"

    old "Fullscreen"
    new "Pantalla completa"

    old "Window"
    new "Ventana"

    old "Skip"
    new "Saltar"

    old "After Choices"
    new "Después de las elecciones"

    old "Transitions"
    new "Transiciones"

    old "Skipping"
    new "Salto a la comba"

    old "Continue"
    new "Continuar"

    old "Stop Skipping"
    new "Deja de saltarte"

    old "History"
    new "Historia"

    old "Back"
    new "Atrás"

    old "Return"
    new "Devolver"

    old "Main Menu"
    new "Menú principal"

    old "Start"
    new "Comenzar"

    old "New Game"
    new "Nuevo juego"

    old "Load Game"
    new "Cargar juego"

    old "Save Game"
    new "Guardar partida"

    old "Options"
    new "Opciones"

    old "Extras"
    new "Extras"

    old "Gallery"
    new "Galería"

    old "Music Room"
    new "Sala de música"

    old "Replay"
    new "Repetición"

    old "Quit"
    new "Abandonar"

    old "Exit"
    new "Salida"

    old "Credits"
    new "Créditos"

    old "About"
    new "Acerca de"

    old "Help"
    new "Ayuda"

    old "Next"
    new "Próximo"

    old "Previous"
    new "Anterior"

    old "Clear"
    new "Claro"

    old "Reset"
    new "Reiniciar"

    old "Default"
    new "Por defecto"

    old "Apply"
    new "Aplicar"

    old "Close"
    new "Cerca"

    old "Hide"
    new "Esconder"

    old "Show"
    new "Espectáculo"

    old "Toggle"
    new "Palanca"

    old "Enable"
    new "Permitir"

    old "Disable"
    new "Desactivar"

    old "On"
    new "En"

    old "Off"
    new "Apagado"

    old "Monday"
    new "Lunes"

    old "Tuesday"
    new "Martes"

    old "Wednesday"
    new "Miércoles"

    old "Thursday"
    new "Jueves"

    old "Friday"
    new "Viernes"

    old "Saturday"
    new "Sábado"

    old "Sunday"
    new "Domingo"

    old "January"
    new "Enero"

    old "February"
    new "Febrero"

    old "March"
    new "Marzo"

    old "April"
    new "Abril"

    old "May"
    new "Puede"

    old "June"
    new "Junio"

    old "July"
    new "Julio"

    old "August"
    new "Agosto"

    old "September"
    new "Septiembre"

    old "October"
    new "Octubre"

    old "November"
    new "Noviembre"

    old "December"
    new "Diciembre"

    old "Error"
    new "Error"

    old "Warning"
    new "Advertencia"

    old "Information"
    new "Información"

    old "Loading..."
    new "Cargando..."

    old "Saving..."
    new "Ahorro..."

    old "File not found"
    new "Archivo no encontrado"

    old "Cannot save"
    new "No se puede guardar"

    old "Cannot load"
    new "No se puede cargar"

    old "Self-voicing"
    new "Autoexpresión"

    old "Clipboard voicing"
    new "Voz del portapapeles"

    old "Debug voicing"
    new "Voz de depuración"

    old "Opens the accessibility menu"
    new "Abre el menú de accesibilidad"

    old "Closes the game menu"
    new "Cierra el menú del juego"

    old "Chapter"
    new "Capítulo"

    old "Scene"
    new "Escena"

    old "Episode"
    new "Episodio"

    old "Part"
    new "Parte"

    old "Volume"
    new "Volumen"

    old "Ending"
    new "Final"

    old "Bad End"
    new "Mal final"

    old "Good End"
    new "Buen final"

    old "True End"
    new "Fin verdadero"

    old "Please enter your name:"
    new "Por favor, introduzca su nombre:"

    old "Enter text:"
    new "Introduzca el texto:"

    old "Input required"
    new "Entrada requerida"

    old "What is your choice?"
    new "¿Cuál es tu elección?"

    old "Select an option"
    new "Seleccione una opción"

    old "Game saved."
    new "Partida guardada."

    old "Game loaded."
    new "Juego cargado."

    old "Quick save created."
    new "Guardado rápido realizado."

    old "Cannot quick save here."
    new "No se puede guardar rápidamente aquí."

    old "No save data."
    new "No se guardaron los datos."

    old "Save data corrupted."
    new "Los datos guardados están dañados."

    old "Unknown error occurred."
    new "Se ha producido un error desconocido."

    old "The game will now quit."
    new "El juego se cerrará ahora."

    old "Are you sure you want to quit?"
    new "¿Estás seguro de que quieres renunciar?"

    old "Are you sure you want to return to the main menu?"
    new "¿Seguro que quieres volver al menú principal?"

    old "Joystick mapping has been reset to default."
    new "La configuración del joystick se ha restablecido a los valores predeterminados."

    old "This save was created on a different device. Timestamps may be inaccurate."
    new "Esta partida se guardó en un dispositivo diferente. Las marcas de tiempo pueden ser inexactas."

    old "The input you entered is not a valid filename."
    new "El nombre de archivo que has introducido no es válido."

    old "The filename is too long."
    new "El nombre del archivo es demasiado largo."

    old "{#month_short}Jan"
    new "{#month_short} Enero"

    old "{#month_short}Feb"
    new "{#month_short} Feb"

    old "{#month_short}Mar"
    new "{#month_short} Mar"

    old "{#month_short}Apr"
    new "{#month_short} Abril"

    old "{#month_short}May"
    new "{#month_short} Mayo"

    old "{#month_short}Jun"
    new "{#month_short} Junio"

    old "{#month_short}Jul"
    new "{#month_short} Julio"

    old "{#month_short}Aug"
    new "{#month_short} Agosto"

    old "{#month_short}Sep"
    new "{#month_short} Sep"

    old "{#month_short}Oct"
    new "{#month_short} Octubre"

    old "{#month_short}Nov"
    new "{#month_short} Noviembre"

    old "{#month_short}Dec"
    new "{#month_short} Dic"

    old "[config.name!t]"
    new " [config.name!t]"

    old "[config.version]"
    new " [config.version]"

    old "http://twitter.com/sodara9 I'd appreciate being given credit if you do end up using it! :D Would really make my day to know I helped some people out! Really hope this can help the community create some really neat ways to spice up their dialogue! http://opensource.org/licenses/mit-license.php Forum Post: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags"
    new "http://twitter.com/sodara9 ¡Agradecería que me dieran crédito si terminan usándolo! :D ¡Me alegraría mucho saber que ayudé a algunas personas! ¡Realmente espero que esto pueda ayudar a la comunidad a crear formas realmente geniales de animar sus diálogos! http://opensource.org/licenses/mit-license.php Publicación en el foro: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags"

    old "ATL Text Tags Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"
    new "Etiquetas de texto ATL Módulo Ren'Py 2021 Daniel Westfall<SoDaRa2595@gmail.com>"

    old "#f00"
    new "#f00"

    old "#00f"
    new "#00f"

    old "-#"
    new "-#"

    old "image"
    new "imagen"

    old "atl"
    new "atl"

    old "han_english"
    new "han_english"

    old "choice"
    new "elección"

    old "hide"
    new "esconder"

    old "unicode"
    new "Unicode"

    old "Language"
    new "Idioma"

    old "%s"
    new "%s"

    old "Paloslios"
    new "Paloslia"

    old "http://twitter.com/sodara9 I'd appreciate being given credit if you do end up using it! :D Would really make my day to know I helped some people out! Really hope this can help the community create some really neat ways to spice up their dialogue! http://opensource.org/licenses/mit-license.php Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags Forum Post: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b"
    new "http://twitter.com/sodara9 ¡Agradecería que me dieran crédito si lo usan! :D ¡Me alegraría mucho saber que ayudé a alguien! ¡Espero que esto ayude a la comunidad a crear formas geniales de darle más sabor a sus diálogos! http://opensource.org/licenses/mit-license.php Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags Publicación en el foro: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b"

    old "Kinetic Text Tags Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"
    new "Etiquetas de texto cinéticas Módulo Ren'Py 2021 Daniel Westfall<SoDaRa2595@gmail.com>"

    old "class RotateText(renpy.Displayable): def __init__(self, child, speed=100, **kwargs): super(RotateText, self).__init__(**kwargs)"
    new "clase RotateText(renpy.Displayable):\n def __init__(self, child, speed=100, **kwargs):\n super(RotateText, self).__init__(**kwargs)"

    old "self.child = child self.speed = speed # The speed of our rotation"
    new "self.child = niño\n self.speed = velocidad # La velocidad de nuestra rotación"

    old "def render(self, width, height, st, at): angle = st * self.speed # Which parameter you put the 'angle' into will affect which axis the render rotates on. # Try moving it around and seeing what happens. rotation_m = renpy.display.matrix.rotate(angle,0,0)"
    new "def render(self, width, height, st, at):\n ángulo = st * velocidad.propia\n # El parámetro en el que introduzcas el 'ángulo' afectará al eje sobre el que gira el renderizado.\n # Intenta moverlo y mira qué pasa.\n rotación_m = renpy.display.matrix.rotate(angle,0,0)"

    old "child_render = renpy.render(self.child, width, height, st, at) c_width, c_height = child_render.get_size() # This applies the rotation to our child's render. child_render.reverse = rotation_m"
    new "child_render = renpy.render(self.child, width, height, st, at)\n c_width, c_height = child_render.get_size()\n # Esto aplica la rotación al renderizado de nuestro hijo.\n child_render.reverse = rotation_m"

    old "self.width, self.height = child_render.get_size() render = renpy.Render(self.width, self.height)"
    new "self.width, self.height = child_render.get_size()\n render = renpy.Render(self.width, self.height)"

    old "# Math nerds might realize I'm not offsetting the transform. # While renpy.display.matrix.offset(x,y,z) is a thing, it won't change much # The real place to apply the offset is in your final blit. Which is what we'll calculate here"
    new "# Los aficionados a las matemáticas podrían darse cuenta de que no estoy compensando la transformación.\n # Si bien renpy.display.matrix.offset(x,y,z) existe, no cambiará mucho.\n # El lugar real para aplicar el desplazamiento es en tu blit final. Que es lo que calcularemos aquí."

    old "# Rotations on x axis theta2 = math.radians(st * float(self.speed) + 180) c = math.cos(theta2) + 1.0 xoff = 0 yoff = c * self.height if yoff > self.height: yoff = self.height"
    new "# Rotaciones en el eje x\n theta2 = math.radians(st * float(self.speed) + 180)\n c = math.cos(theta2) + 1.0\n xoff = 0\n yoff = c * altura propia\n si yoff > altura propia:\n yoff = altura propia"

    old "render.subpixel_blit(child_render, (xoff,yoff)) renpy.redraw(self, 0) return render"
    new "render.subpixel_blit(child_render, (xoff,yoff))\n renpy.redraw(self, 0)\n devolver render"

    old "def visit(self): return [ self.child ]"
    new "def visita(yo):\n devolver [self.child]"

    old "# Template tag function to copy off of. def TEMPLATE_tag(tag, argument, contents): new_list = [ ] if argument == \"\": argument = 5 my_style = DispTextStyle() for kind,text in contents: if kind == renpy.TEXT_TEXT: for char in text: char_text = Text(my_style.apply_style(char)) char_disp = TEMPLATEText(char_text, argument) new_list.append((renpy.TEXT_DISPLAYABLE, char_disp)) elif kind == renpy.TEXT_TAG: if not my_style.add_tags(text): new_list.append((kind, text)) else: new_list.append((kind,text)) return new_list"
    new "# Función de etiqueta de plantilla para copiar.\n def TEMPLATE_tag(tag, argument, contents):\n nueva_lista = []\n si argumento == '':\n argumento = 5\n mi_estilo = DispTextStyle()\n para tipo, texto en contenido:\n si kind == renpy.TEXT_TEXT:\n para cada carácter en el texto:\n char_text = Text(my_style.apply_style(char))\n char_disp = TEMPLATEText(char_text, argumento)\n nueva_lista.append((renpy.TEXT_DISPLAYABLE, char_disp))\n elif kind == renpy.TEXT_TAG:\n Si no my_style.add_tags(texto):\n nueva_lista.append((tipo, texto))\n demás:\n nueva_lista.append((tipo,texto))\n devolver nueva_lista"

    old "+ tag for tag in accepted_tags] def __init__(self): self.tags = {} def add_tags(self, char): tag, _, value = char.partition("
    new "+ etiqueta para etiqueta en accepted_tags]\n def __init__(self):\n self.tags = {}\n\n\n def add_tags(self, char):\n etiqueta, _, valor = char.partition("

    old "{\" + tag + \"}"
    new "{' + tag + '}"

    old "{\" + tag + \"=\" +self.tags[tag] + \"}"
    new "{' + tag + '=' +self.tags [tag] + '} slate='no'> [tag] + '}"

    old "omega"
    new "omega"

    old "bt"
    new "bt"

    old "fi"
    new "ser"

    old "sc"
    new "Carolina del Sur"

    old "rotat"
    new "ratas"

    old "chaos"
    new "caos"

    old "move"
    new "mover"

    old "color"
    new "color"

    old "alpha"
    new "alfa"

    old "font"
    new "fuente"

    old "size"
    new "tamaño"

    old "outlinecolor"
    new "color de contorno"

    old "plain"
    new "plano"

    old "color="
    new "color="

    old "size="
    new "tamaño="

    old "font="
    new "fuente="

    old "class RotateText(renpy.Displayable): def __init__(self, child, speed=100, **kwargs): super(RotateText, self).__init__(**kwargs) self.child = child self.speed = speed # The speed of our rotation def render(self, width, height, st, at): angle = st * self.speed # Which parameter you put the 'angle' into will affect which axis the render rotates on. # Try moving it around and seeing what happens. rotation_m = renpy.display.matrix.rotate(angle,0,0) child_render = renpy.render(self.child, width, height, st, at) c_width, c_height = child_render.get_size() # This applies the rotation to our child's render. child_render.reverse = rotation_m self.width, self.height = child_render.get_size() render = renpy.Render(self.width, self.height) # Math nerds might realize I'm not offsetting the transform. # While renpy.display.matrix.offset(x,y,z) is a thing, it won't change much # The real place to apply the offset is in your final blit. Which is what we'll calculate here # Rotations on x axis theta2 = math.radians(st * float(self.speed) + 180) c = math.cos(theta2) + 1.0 xoff = 0 yoff = c * self.height if yoff > self.height: yoff = self.height render.subpixel_blit(child_render, (xoff,yoff)) renpy.redraw(self, 0) return render def visit(self): return [ self.child ]"
    new "clase RotateText(renpy.Displayable):\n def __init__(self, child, speed=100, **kwargs):\n super(RotateText, self).__init__(**kwargs)\n\n self.child = niño\n self.speed = velocidad # La velocidad de nuestra rotación\n\n def render(self, width, height, st, at):\n ángulo = st * velocidad.propia\n # El parámetro en el que introduzcas el 'ángulo' afectará al eje sobre el que gira el renderizado.\n # Intenta moverlo y mira qué pasa.\n rotación_m = renpy.display.matrix.rotate(angle,0,0)\n\n child_render = renpy.render(self.child, width, height, st, at)\n c_width, c_height = child_render.get_size()\n # Esto aplica la rotación al renderizado de nuestro hijo.\n child_render.reverse = rotation_m\n\n self.width, self.height = child_render.get_size()\n render = renpy.Render(self.width, self.height)\n\n # Los aficionados a las matemáticas podrían darse cuenta de que no estoy compensando la transformación.\n # Si bien renpy.display.matrix.offset(x,y,z) existe, no cambiará mucho.\n # El lugar real para aplicar el desplazamiento es en tu blit final. Que es lo que calcularemos aquí.\n\n # Rotaciones en el eje x\n theta2 = math.radians(st * float(self.speed) + 180)\n c = math.cos(theta2) + 1.0\n xoff = 0\n yoff = c * altura propia\n si yoff > altura propia:\n yoff = altura propia\n\n render.subpixel_blit(child_render, (xoff,yoff))\n renpy.redraw(self, 0)\n devolver render\n\n def visita(yo):\n devolver [self.child]"

    old "ERROR!"
    new "¡ERROR!"

    old "# Template tag function to copy off of. def TEMPLATE_tag(tag, argument, contents): new_list = [ ] if argument =="
    new "# Función de etiqueta de plantilla para copiar.\n def TEMPLATE_tag(tag, argument, contents):\n nueva_lista = []\n si argumento =="

    old ": argument = 5 my_style = DispTextStyle() for kind,text in contents: if kind == renpy.TEXT_TEXT: for char in text: char_text = Text(my_style.apply_style(char)) char_disp = TEMPLATEText(char_text, argument) new_list.append((renpy.TEXT_DISPLAYABLE, char_disp)) elif kind == renpy.TEXT_TAG: if not my_style.add_tags(text): new_list.append((kind, text)) else: new_list.append((kind,text)) return new_list"
    new ":\n argumento = 5\n mi_estilo = DispTextStyle()\n para tipo, texto en contenido:\n si kind == renpy.TEXT_TEXT:\n para cada carácter en el texto:\n char_text = Text(my_style.apply_style(char))\n char_disp = TEMPLATEText(char_text, argumento)\n nueva_lista.append((renpy.TEXT_DISPLAYABLE, char_disp))\n elif kind == renpy.TEXT_TAG:\n Si no my_style.add_tags(texto):\n nueva_lista.append((tipo, texto))\n demás:\n nueva_lista.append((tipo,texto))\n devolver nueva_lista"

    old "swap"
    new "intercambio"

    old "para"
    new "a"

    old "lets meet tomorow"
    new "Nos vemos mañana"

    old "1.0"
    new "1.0"

    old "auto"
    new "auto"

    old "letsmeettomorow-1745689328"
    new "nos vemos mañana-1745689328"

    old "letsmeettomorow"
    new "Veamos mañana"

    old "Prefs"
    new "Preferencias"

    old "End Replay"
    new "Fin de la reproducción"

    old "Version [config.version!t]"
    new "Versión [config.version!t]"

    old "[gui.about!t]"
    new " [gui.about!t]"

    old "[config.name!t] is a short visual novel made in 24h by the VN Game Dev Dreamty."
    new " [config.name!t] es una novela visual corta creada en 24 horas por el desarrollador de juegos de novelas visuales Dreamty."

    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only]. [renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/} Ren'Py {/a} [renpy.version_only].\n\n [renpy.license!t]"

    old "Page {}"
    new "Página {}"

    old "Automatic saves"
    new "Guardado automático"

    old "Quick saves"
    new "Guardados rápidos"

    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time} %A, %B %d %Y, %H:% M"

    old "empty slot"
    new "espacio vacío"

    old "{#auto_page}A"
    new "{#auto_page} A"

    old "{#quick_page}Q"
    new "{#quick_page} Q"

    old "[page]"
    new " [page]"

    old "Upload Sync"
    new "Sincronización de carga"

    old "Download Sync"
    new "Descargar sincronización"

    old "Unseen Text"
    new "Texto no visto"

    old "Test"
    new "Prueba"

    old "keyboard"
    new "teclado"

    old "Keyboard"
    new "Teclado"

    old "Mouse"
    new "Ratón"

    old "Gamepad"
    new "Gamepad"

    old "Enter"
    new "Ingresar"

    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    old "Space"
    new "Espacio"

    old "Advances dialogue without selecting choices."
    new "Avanza en el diálogo sin seleccionar opciones."

    old "Arrow Keys"
    new "Teclas de flecha"

    old "Navigate the interface."
    new "Navega por la interfaz."

    old "Escape"
    new "Escapar"

    old "Accesses the game menu."
    new "Accede al menú del juego."

    old "Ctrl"
    new "Control"

    old "Skips dialogue while held down."
    new "Omite los diálogos mientras se mantiene pulsado."

    old "Tab"
    new "Pestaña"

    old "Toggles dialogue skipping."
    new "Activa o desactiva la omisión de diálogos."

    old "Page Up"
    new "Página arriba"

    old "Rolls back to earlier dialogue."
    new "Vuelve al diálogo anterior."

    old "Page Down"
    new "Página abajo"

    old "Rolls forward to later dialogue."
    new "Avanza hasta un diálogo posterior."

    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Activa/desactiva la autovoz asistida {a=https://www.renpy.org/l/voicing}{/a} ."

    old "Shift+A"
    new "Mayús+A"

    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    old "Left Click"
    new "Clic izquierdo"

    old "Middle Click"
    new "Clic central"

    old "Right Click"
    new "Clic derecho"

    old "Mouse Wheel Up"
    new "Rueda del ratón hacia arriba"

    old "Mouse Wheel Down"
    new "Rueda del ratón hacia abajo"

    old "Right Trigger A/Bottom Button"
    new "Gatillo derecho\n Botón inferior"

    old "Left Trigger Left Shoulder"
    new "Gatillo izquierdo\n Hombro izquierdo"

    old "Right Shoulder"
    new "Hombro derecho"

    old "D-Pad, Sticks"
    new "Cruceta, joysticks"

    old "Start, Guide, B/Right Button"
    new "Inicio, Guía, Botón B/Derecho"

    old "Y/Top Button"
    new "Botón superior Y"

    old "Calibrate"
    new "Calibrar"

    old "[message!tq]"
    new " [message!tq]"

    old "Menu"
    new "Menú"

    old "say"
    new "decir"

    old "window"
    new "ventana"

    old "namebox"
    new "cuadro de nombres"

    old "input"
    new "aporte"

    old "quick"
    new "rápido"

    old "navigation"
    new "navegación"

    old "main_menu_frame"
    new "main_menu_frame"

    old "main_menu_vbox"
    new "main_menu_vbox"

    old "main_menu_title"
    new "main_menu_title"

    old "main_menu_version"
    new "main_menu_version"

    old "game_menu"
    new "game_menu"

    old "game_menu_outer_frame"
    new "game_menu_outer_frame"

    old "game_menu_navigation_frame"
    new "game_menu_navigation_frame"

    old "game_menu_content_frame"
    new "game_menu_content_frame"

    old "vertical"
    new "vertical"

    old "return_button"
    new "return_button"

    old "about"
    new "acerca de"

    old "page_label"
    new "page_label"

    old "page_label_text"
    new "page_label_text"

    old "slot"
    new "ranura"

    old "slot_time_text"
    new "slot_time_text"

    old "slot_name_text"
    new "slot_name_text"

    old "save_delete"
    new "save_delete"

    old "page"
    new "página"

    old "subtitle"
    new "subtitular"

    old "radio"
    new "radio"

    old "check"
    new "controlar"

    old "slider"
    new "deslizador"

    old "mute_all_button"
    new "mute_all_button"

    old "help"
    new "ayuda"

    old "confirm"
    new "confirmar"

    old "confirm_prompt"
    new "confirm_prompt"

    old "skip"
    new "saltar"

    old "notify"
    new "notificar"

    old "nvl_window"
    new "nvl_window"

    old "nvl_button"
    new "nvl_button"

    old "bubble"
    new "burbuja"

    old "bubble_namebox"
    new "bubble_namebox"

    old "who"
    new "OMS"

    old "what"
    new "qué"

    old "#000"
    new "#000"

    old "medium"
    new "medio"

    old "touch"
    new "tocar"

    old "small"
    new "pequeño"

    old "input_prompt"
    new "input_prompt"

    old "bottom_left"
    new "bottom_left"

    old "window_background"
    new "window_background"

    old "window_bottom_padding"
    new "window_bottom_padding"

    old "bottom_right"
    new "bottom_right"

    old "top_left"
    new "top_left"

    old "window_top_padding"
    new "window_top_padding"

    old "top_right"
    new "top_right"

    old "thought"
    new "pensamiento"

    old ", 55, 55, 55, 55) define -1 bubble.properties = { \"bottom_left\" : { \"window_background\" : Transform(bubble.frame, xzoom=1, yzoom=1), \"window_bottom_padding\" : 27, },"
    new ", 55, 55, 55, 55)\n\n define -1 bubble.properties = {\n 'bottom_left' : {\n 'window_background' : Transform(bubble.frame, xzoom=1, yzoom=1),\n 'window_bottom_padding' : 27,\n } zoom=1),\n 'window_bottom_padding' : 27,\n },"

    old ": { \"window_background\" : Transform(bubble.frame, xzoom=-1, yzoom=1), \"window_bottom_padding\" : 27, },"
    new ": {\n 'window_background' : Transform(bubble.frame, xzoom=-1, yzoom=1),\n 'window_bottom_padding' : 27,\n } >\n 'window_bottom_padding' : 27,\n },"

    old ": { \"window_background\" : Transform(bubble.frame, xzoom=1, yzoom=-1), \"window_top_padding\" : 27, },"
    new ": {\n 'window_background' : Transform(bubble.frame, xzoom=1, yzoom=-1),\n 'window_top_padding' : 27,\n } no'>\n 'window_top_padding' : 27,\n },"

    old ": { \"window_background\" : Transform(bubble.frame, xzoom=-1, yzoom=-1), \"window_top_padding\" : 27, },"
    new ": {\n 'window_background' : Transform(bubble.frame, xzoom=-1, yzoom=-1),\n 'window_top_padding' : 27,\n } no'>\n 'window_top_padding' : 27,\n },"

    old ": { \"window_background\" : bubble.thoughtframe, } } define -1 bubble.expand_area = {"
    new ": {\n 'window_background' : bubble.thoughtframe,\n } bble.thoughtframe,\n }\n }\n\n define -1 burbuja.expand_area = {"

    old "hyperlink"
    new "hiperenlace"

    old "interface"
    new "interfaz"

    old "button"
    new "botón"

    old "label"
    new "etiqueta"

    old "prompt"
    new "inmediato"

    old "name"
    new "nombre"

    old "dialogue"
    new "diálogo"

    old "choice_button"
    new "choice_button"

    old "auto-forward"
    new "avance automático"

    old "toggle"
    new "palanca"

    old "quick_menu"
    new "quick_menu"

    old "quick_button"
    new "quick_button"

    old "main_menu"
    new "main_menu"

    old "load"
    new "carga"

    old "preferences"
    new "preferencias"

    old "pc"
    new "ordenador personal"

    old "navigation_button"
    new "navigation_button"

    old "title"
    new "título"

    old "version"
    new "versión"

    old "viewport"
    new "ventana gráfica"

    old "vpgrid"
    new "vpgrid"

    old "save"
    new "ahorrar"

    old "page_button"
    new "page_button"

    old "slot_button"
    new "slot_button"

    old "web"
    new "web"

    old "display"
    new "mostrar"

    old "fullscreen"
    new "pantalla completa"

    old "after choices"
    new "después de las elecciones"

    old "transitions"
    new "transiciones"

    old "text speed"
    new "velocidad de texto"

    old "auto-forward time"
    new "avance automático del tiempo"

    old "music volume"
    new "volumen de la música"

    old "sound volume"
    new "volumen del sonido"

    old "sound"
    new "sonido"

    old "voice volume"
    new "volumen de voz"

    old "voice"
    new "voz"

    old "all mute"
    new "todos mudos"

    old "radio_button"
    new "radio_button"

    old "check_button"
    new "check_button"

    old "slider_button"
    new "slider_button"

    old "device"
    new "dispositivo"

    old "mouse"
    new "ratón"

    old "gamepad"
    new "mando"

    old "help_button"
    new "help_button"

    old "confirm_button"
    new "confirm_button"

    old "skip_triangle"
    new "skip_triangle"

    old "tex"
    new "Texas"

    old "This is an updated version of a game originaly made in 24h."
    new "Esta es una versión actualizada de un juego creado originalmente en 24h."

    old "Any resemblance to actual events, or persons is coincidental."
    new "Cualquier parecido con hechos o personas reales es pura coincidencia."

    old "Also remember, {atl=#,#,fade_in_text~2.0}{color=#9b1169}{i}stranger danger{/color=#9b1169}."
    new "Recuerda también, {atl=#,#,fade_in_text~2.0}{color=#9b1169}{i} peligro de extraños {/color=#9b1169} ."

    old "{b}{color=#ffffff}No."
    new "{b}{color=#ffffff}No."

    old "This one is taken :)"
    new "Este ya está ocupado :)"

    old "Omg hi ! Either you're Silas number 1 fan or someone sharing the same name."
    new "¡Dios mío, hola! O eres el fan número 1 de Silas o alguien que comparte el mismo nombre."

    old "Regardless have a fun time playing."
    new "En cualquier caso, diviértete jugando."

    old "If you are the Silas number one fan, quick note."
    new "Si eres el fan número uno de Silas, una nota rápida."

    old "Thank you for all your kind words, you motivated me to make this update."
    new "Gracias por todas vuestras amables palabras, me motivaron a realizar esta actualización."

    old "May it meet your expectation !"
    new "¡Espero que cumpla con tus expectativas!"

    old "Tons of love to you."
    new "Muchísimo amor para ti."

    old "Signed, dreamty :}"
    new "Firmado, soñador :}"

    old "Thank you."
    new "Gracias."

    old "Enjoy the game."
    new "Disfruta del juego."

    old "strawberry"
    new "fresa"

    old "chocolate"
    new "chocolate"

    old "vanilla"
    new "vainilla"

    old "Ending 1: {b}{color=f60808}Fear"
    new "Final 1: {b}{color=f60808} Miedo"

    old "Ending 2: {b}Escape"
    new "Final 2: {b} Escape"

    old "Ending 3: {b}Delusion"
    new "Final 3: {b} Delirio"

    old "A few months later..."
    new "Unos meses después..."

    old "{sc=1}The world blurs."
    new "{sc=1} El mundo se difumina."

    old "{sc=1}The sidewalk."
    new "{sc=1} La acera."

    old "{sc=1}The street noise."
    new "{sc=1} El ruido de la calle."

    old "{sc=1}The bookstore behind me."
    new "{sc=1} La librería que está detrás de mí."

    old "{sc=1}By the time my thoughts catch up, we’re already there."
    new "{sc=1} Para cuando mis pensamientos se ponen al día, ya estamos allí."

    old "{sc=1}The familiar neon sign was buzzing faintly overhead, and the pastel booths were washed in the soft glow of the evening."
    new "{sc=1} El familiar letrero de neón zumbaba débilmente sobre nuestras cabezas, y las cabinas de colores pastel estaban bañadas por el suave resplandor del atardecer."

    old "{sc=1}{color=#f60808}Silas doesn’t hesitate."
    new "{sc=1}{color=#f60808} Silas no duda."

    old "Hey..."
    new "Ey..."

    old "Silas... ?"
    new "Silas... ?"

    old "Yeah, it’s me."
    new "Sí, soy yo."

    old "You look just like your online model !"
    new "¡Te pareces muchísimo a tu modelo online!"

    old "You do too. {w}Uh, but you already knew that, right ?"
    new "Tú también. {w} Eh, pero ya lo sabías, ¿verdad?"

    old "Do you prefer if I call you by your name or by your pseudonym ?"
    new "¿Prefieres que te llame por tu nombre o por tu seudónimo?"

    old "You can use [name] ! You made the effort to take a plane ticket to visit me. It wouldn’t be right to keep calling me by my username."
    new "Puedes usar [name]. Te tomaste la molestia de comprar un billete de avión para visitarme. No estaría bien que siguieras llamándome por mi nombre de usuario."

    old "Yeah, you’re right..."
    new "Sí, tienes razón..."

    old "Hi [name] ! I’m really happy to see you !"
    new "¡Hola [name]! ¡Me alegra mucho verte!"

    old "Do you mind if I- uh..."
    new "¿Te importa si yo...?"

    old "Sorry, I’m... not great with hugs."
    new "Lo siento, no soy muy buena dando abrazos."

    old "No worries, I get that."
    new "No te preocupes, lo entiendo."

    old "You’re taller than I thought you’d be."
    new "Eres más alto de lo que pensaba."

    old "I get that a lot !"
    new "¡Me pasa mucho!"

    old "I should probably apologize in advance if I act a little weird. Long flight, weird sleep, adrenaline, nerves... all that."
    new "Probablemente debería disculparme de antemano si actúo un poco raro. Vuelo largo, sueño irregular, adrenalina, nervios... todo eso."

    old "It’s fine. Honestly, I’m just really glad you’re here."
    new "No pasa nada. Sinceramente, me alegra mucho que estés aquí."

    old "Wanna check out the store ? The inside looks like something out of a vampire movie."
    new "¿Quieres echar un vistazo a la tienda? El interior parece sacado de una película de vampiros."

    old "Hell yeah ! Seems cool, lead the way."
    new "¡Claro que sí! Parece genial, ¡adelante!"

    old "Hey, have you read this one ?"
    new "Oye, ¿has leído este?"

    old "Seriously ?"
    new "En serio ?"

    old "What ?"
    new "Qué ?"

    old "Silas, I made you put that on your to-read list, like, six months ago !"
    new "Silas, ¡te hice añadir eso a tu lista de lecturas pendientes hace como seis meses!"

    old "We had a whole conversation about it because I was obsessed and you said I was being dramatic."
    new "Tuvimos una larga conversación sobre eso porque yo estaba obsesionada y tú dijiste que estaba exagerando."

    old "Ohhh... So that’s why it looked familiar."
    new "Ohhh... Así que por eso me resultaba familiar."

    old "I suppose you forgot about it and never read it then ?"
    new "Supongo que lo olvidaste y nunca lo leíste, ¿verdad?"

    old "Euh... What if I didn’t ?"
    new "Eh... ¿Y si no lo hiciera?"

    old "I can’t believe you ! I’m never rambling about books with you again."
    new "¡No puedo creerlo! Nunca más volveré a hablar de libros contigo."

    old "Oh please do, I find it cute."
    new "Oh, por favor, hazlo, me parece lindo."

    old "Sweet talker..."
    new "Persuasivo..."

    old "Promise me you’ll read this one at least ? It’s really good."
    new "Prométeme que leerás al menos este. Es realmente bueno."

    old "Sure, I can even buy it now so I have an excuse to read it on my flight back."
    new "Claro, incluso puedo comprarlo ahora para tener una excusa para leerlo en mi vuelo de regreso."

    old "Alright, I'll take it. It’s still in good condition."
    new "De acuerdo, me lo quedo. Todavía está en buen estado."

    old "Yay ! I want a review when you’re done."
    new "¡Genial! Quiero una reseña cuando termines."

    old "I won’t forget about it, I promise [name] !"
    new "¡No lo olvidaré, te lo prometo [name]!"

    old "Though I have to ask. Are you sure you’ll have space for it ?"
    new "Aunque tengo que preguntar. ¿Estás seguro de que tendrás espacio para ello?"

    old "Huh ?"
    new "Eh ?"

    old "You showed me how tiny your suitcase was. Like, it’s criminally small for a trip this long."
    new "Me enseñaste lo pequeña que era tu maleta. Es ridículamente pequeña para un viaje tan largo."

    old "Okay, fair. It’s definitely a clown suitcase but in the worst case, I’ll keep the book in my hands for the flight back."
    new "Vale, de acuerdo. Sin duda es una maleta ridícula, pero en el peor de los casos, llevaré el libro conmigo en el vuelo de vuelta."

    old "That way I can pretend I'm so different from others, reading a book instead of always being on my phone like everyone else."
    new "De esa forma puedo fingir que soy muy diferente a los demás, leyendo un libro en lugar de estar siempre con el móvil como todo el mundo."

    old "You are always on your phone !"
    new "¡Siempre estás con el móvil!"

    old "Shhh l said pretend to be different, the people at the airport don’t have to know my real life !"
    new "¡Shhh!, dije, finge ser diferente, ¡la gente del aeropuerto no tiene por qué saber mi vida real!"

    old "It’s a nice souvenir to have of our time together anyway."
    new "De todos modos, es un bonito recuerdo de nuestro tiempo juntos."

    old "Then I hope you’ll like the book."
    new "Entonces espero que te guste el libro."

    old "Come on ! If you liked it I'm sure I will too."
    new "¡Vamos! Si a ti te gustó, seguro que a mí también."

    old "I trust your taste in books."
    new "Confío en tu criterio literario."

    old "Hey... it’s a bit early, but you wanna grab something to eat ?"
    new "Hola... es un poco temprano, pero ¿quieres comer algo?"

    old "I’m kinda starving."
    new "Tengo un poco de hambre."

    old "Yeah, sure. Any place in mind ?"
    new "Sí, claro. ¿Tienes algún sitio en mente?"

    old "What about milkshakes ?"
    new "¿Y los batidos?"

    old "Sure that sounds good."
    new "Claro, suena bien."

    old "Alrighty then, let’s go."
    new "Muy bien, entonces, vámonos."

    old "How do you even know where the shop is ? You haven’t checked your phone once."
    new "¿Cómo sabes siquiera dónde está la tienda? Ni siquiera has mirado el móvil una sola vez."

    old "I checked it out this morning actually. Kinda craved something sweet after the flight. So I looked up spots near the hotel while waiting for my room key."
    new "De hecho, lo revisé esta mañana. Después del vuelo, me apetecía algo dulce. Así que busqué sitios cerca del hotel mientras esperaba la llave de mi habitación."

    old "Lucky for us."
    new "Por suerte para nosotros."

    old "I see it was all a ploy, you just wanted to go grab milkshakes !"
    new "Ya veo que todo fue una estratagema, ¡solo querías ir a comprar batidos!"

    old "Mayhaps."
    new "Tal vez."

    old "You would be surprised to know how good I am at plotting stuff just for a treat."
    new "Te sorprendería saber lo buena que soy planeando cosas solo por capricho."

    old "Oh you evil man... Don’t get a cavity if you go get sweets too much."
    new "Oh, hombre malvado... No te saldrán caries si comes demasiados dulces."

    old "Everything looks so good, not that expensive either."
    new "Todo tiene muy buena pinta, y además no es tan caro."

    old "This is a nice place ! I Might have to add it to my list of spots for future hangouts."
    new "¡Este es un lugar agradable! Quizás lo añada a mi lista de sitios para futuras reuniones."

    old "You have great taste Silas !"
    new "¡Tienes muy buen gusto, Silas!"

    old "Uh... yeah..."
    new "Eh... sí..."

    old "Order whatever you want."
    new "Pide lo que quieras."

    old "You don’t have to—"
    new "No tienes que hacerlo—"

    old "I want to... Because it’s you."
    new "Quiero... Porque eres tú."

    old "That's sweet but I insist, please."
    new "Eso es muy amable, pero insisto, por favor."

    old "Hmm hmm ! I suggested the place, I’m paying. I’m not changing my mind, [name]."
    new "¡Hmm hmm! Yo sugerí el lugar, yo pago. No voy a cambiar de opinión, [name]."

    old "Silas..."
    new "Silas..."

    old "Get whatever you want !"
    new "¡Consigue lo que quieras!"

    old "So what would you like to order ?"
    new "¿Qué le gustaría pedir?"

    old "Strawberry for me please."
    new "Fresa para mí, por favor."

    old "Same."
    new "Mismo."

    old "Oh now you’re imitating me ?"
    new "¿Ahora me estás imitando?"

    old "I just said you have good taste Silas !"
    new "¡Acabo de decir que tienes buen gusto, Silas!"

    old "What can I say, you’ve got good taste too."
    new "¿Qué puedo decir? Tú también tienes buen gusto."

    old "And what if I just wanted a strawberry flavored milkshake ? Maybe I’m not a copycat, I just like pink."
    new "¿Y si solo quisiera un batido con sabor a fresa? Quizás no sea una imitadora, simplemente me gusta el rosa."

    old "I’m just surprised ! That's usually my thing !"
    new "¡Estoy sorprendida! ¡Eso suele ser lo mío!"

    old "Well maybe I wanna try to become your thing too."
    new "Bueno, tal vez yo también quiera intentar convertirme en lo tuyo."

    old "I’ll go with chocolate please."
    new "Me quedo con chocolate, por favor."

    old "Good call. Make it two."
    new "Buena idea. Que sean dos."

    old "Trying to match with me now ?"
    new "¿Intentando conectar conmigo ahora?"

    old "Figured if we’re hanging out, we might as well get matching drinks. Maybe they’ll give us special straws"
    new "Pensamos que, ya que vamos a pasar el rato juntos, podríamos pedir bebidas a juego. Quizás nos den pajitas especiales."

    old "You know, like cringy couples on a date."
    new "Ya sabes, como parejas incómodas en una cita."

    old "A-Ah a date ?!"
    new "¡¿Una cita?!"

    old "Oh I mean- we’re imitating people on a date ! Not that we..."
    new "Oh, quiero decir... ¡estamos imitando a personas en una cita! No es que..."

    old "..."
    new "..."

    old "Not that- We... Let’s change the... Euhm... The topic."
    new "No es que... Nosotros... Cambiemos el... Ehm... El tema."

    old "I think I’ll have vanilla please."
    new "Creo que tomaré vainilla, por favor."

    old "Didn’t you say vanilla was the most basic flavor on earth last week ?"
    new "¿No dijiste la semana pasada que la vainilla era el sabor más básico del planeta?"

    old "I did not–{w}Okay, maybe I did."
    new "No lo hice… {w} Bueno, tal vez sí."

    old "Guess I’ll be basic today. But you still like me~ Face it. You’re just as basic. {size=20}Deal with it."
    new "Supongo que hoy seré básica. Pero aún te gusto~ Acéptalo. Tú también eres básico. {size=20} Acéptalo."

    old "Oh wow. Middle school wants it’s material back- Silas that was tragic."
    new "Oh, vaya. La escuela secundaria quiere que le devuelvan su material. Silas, eso fue trágico."

    old "I’ll still give you A for the effort."
    new "Aun así, te doy una A por el esfuerzo."

    old "You can’t say that when I managed to make you laugh !"
    new "¡No puedes decir eso cuando logré hacerte reír!"

    old "No you didn’t !"
    new "¡No, no lo hiciste!"

    old "Yes I did !"
    new "¡Sí, lo hice!"

    old "Did not !"
    new "¡No lo hice!"

    old "So did !"
    new "¡Yo también!"

    old "You’re just saying lies !"
    new "¡Solo estás diciendo mentiras!"

    old "Says the basic vanilla liar."
    new "Lo dice el mentiroso básico de vainilla."

    old "Pfffff... you’re stupid !"
    new "Pfffff... ¡eres estúpido!"

    old "Here you go, this one is yours and this one is mine, although there isn’t really any difference... Hold on, I should get a ruler to check."
    new "Aquí tienes, este es tuyo y este es mío, aunque en realidad no hay ninguna diferencia... Espera, debería buscar una regla para comprobarlo."

    old "Uh- sorry, give me a second. I gotta take this."
    new "Eh, perdón, dame un segundo. Tengo que contestar."

    old "Hey."
    new "Ey."

    old "[name] !"
    new " [name]!"

    old "God..."
    new "Dios..."

    old "I, uh... sorry. I just thought you’d left the place."
    new "Yo, eh... lo siento. Pensé que te habías ido."

    old "Wha- why would I do that ? We’re hanging out."
    new "¿Qué? ¿Por qué haría yo eso? Estamos pasando el rato."

    old "I thought I made things awkward and you escaped by the back door..."
    new "Pensé que yo había creado una situación incómoda y que te escapaste por la puerta trasera..."

    old "No, I’m having a good time, don’t worry."
    new "No, me lo estoy pasando bien, no te preocupes."

    old "Okay, cool... Sorry, I... overthink sometimes."
    new "Vale, genial... Lo siento, a veces... pienso demasiado."

    old "Yeah, I know, sorry..."
    new "Sí, lo sé, lo siento..."

    old "Are you okay ?"
    new "Estás bien ?"

    old "Yeah, just... kinda bummed it’s getting late, I guess."
    new "Sí, es que... me da un poco de pena que se esté haciendo tarde, supongo."

    old "Yeah, I’d like that."
    new "Sí, me gustaría."

    old "C’mon."
    new "Vamos."

    old "What-"
    new "Qué-"

    old "We’re going."
    new "Nos vamos."

    old "Where ?"
    new "Dónde ?"

    old "Let’s walk back to the bookstore. It’s nice outside, we might as well take a stroll rather than just sitting here until they kick us out."
    new "Volvamos a la librería. Hace buen tiempo, mejor damos un paseo que quedarnos aquí sentados hasta que nos echen."

    old "Also I want to spend more time with you, come on [name]."
    new "También quiero pasar más tiempo contigo, vamos [name]."

    old "So, uh..."
    new "Entonces, eh..."

    old "Same place, same time tomorrow ?"
    new "¿Mismo lugar, misma hora mañana?"

    old "Wait-"
    new "Esperar-"

    old "I... I really liked spending the day with you."
    new "Yo... me gustó mucho pasar el día contigo."

    old "And not just today. All those days we talked online, the stupid late-night conversations, weird memes, random book rants—"
    new "Y no solo hoy. Todos esos días que hablamos en línea, las estúpidas conversaciones nocturnas, los memes raros, las diatribas aleatorias sobre libros..."

    old "I don’t know, it’s just... it felt like we had something. And today kind of made me realize I..."
    new "No sé, es que... sentía que teníamos algo. Y hoy me di cuenta de que..."

    old "I like you, Silas. I’ve liked you for a while now."
    new "Me gustas, Silas. Me gustas desde hace tiempo."

    old "I... really like you too."
    new "Yo... también me gustas mucho."

    old "Today’s been... one of the best days I’ve had in years."
    new "Hoy ha sido... uno de los mejores días que he tenido en años."

    old "I had... No, I'm still having so much fun with you !"
    new "Yo tenía... ¡No, todavía me estoy divirtiendo mucho contigo!"

    old "Do you wanna stay at my place tonight ?"
    new "¿Quieres quedarte en mi casa esta noche?"

    old "I mean—"
    new "Quiero decir-"

    old "Please come to my place tonight."
    new "Por favor, ven a mi casa esta noche."

    old "You know... I wasn’t sure you’d even show up today."
    new "¿Sabes?... No estaba seguro de que fueras a venir hoy."

    old "What ? Why ?"
    new "¿Qué? ¿Por qué?"

    old "I don’t know. I just... kept thinking maybe you’d decide it wasn’t worth it."
    new "No lo sé. Simplemente... seguía pensando que tal vez decidirías que no valía la pena."

    old "That meeting me in person would be disappointing, or weird, or..."
    new "Que conocerme en persona sería decepcionante, o raro, o..."

    old "I’ve been nervous about today for weeks. But it’s not because I didn’t want to meet you. I was scared you’d think I was weird, or unlikable, or something."
    new "He estado nerviosa por hoy durante semanas. Pero no es porque no quisiera conocerte. Tenía miedo de que pensaras que era rara, o antipática, o algo así."

    old "If you’re weird, then I don’t know what I am !"
    new "Si tú eres raro, ¡entonces no sé qué soy yo!"

    old "I’m glad I came. Really, really glad, [name]."
    new "Me alegro de haber venido. De verdad, de verdad me alegro, [name]."

    old "So... this is your place ?"
    new "Entonces... ¿este es tu lugar?"

    old "Yup, not that far from your hotel ! At least you can go back if you need something."
    new "Sí, no está muy lejos de tu hotel. Al menos puedes volver si necesitas algo."

    old "I hope I won’t have to go back."
    new "Espero no tener que volver."

    old "Don't mind the clothes everywhere, I didn’t expect you to come here tonight."
    new "No te preocupes por la ropa que hay por todas partes, no esperaba que vinieras esta noche."

    old "I would have cleaned though—"
    new "Aunque lo habría limpiado..."

    old "It’s alright, I’m pretty messy myself."
    new "No pasa nada, yo también soy bastante desordenada."

    old "Oh by the way, my cat might be hidden in my bedroom if you wanna see her !"
    new "Ah, por cierto, ¡mi gata podría estar escondida en mi habitación por si quieres verla!"

    old "Oh ! Can I check on her ?"
    new "¡Oh! ¿Puedo ver cómo está?"

    old "Sure ! Second door, after the bathroom."
    new "¡Claro! La segunda puerta, después del baño."

    old "She’s cute. I think she likes me."
    new "Es linda. Creo que le gusto."

    old "Something’s going on ?"
    new "¿Está pasando algo?"

    old "Uh, sorry, work mail just came in. Kinda ruined my mood."
    new "Eh, perdón, me acaba de llegar correo del trabajo. Me ha arruinado el humor."

    old "I should answer it now because it’s urgent. Do you mind ?"
    new "Debo responder ahora porque es urgente. ¿Te importa?"

    old "You can wait in the bedroom if you want."
    new "Puedes esperar en el dormitorio si quieres."

    old "Don’t get too distracted by work ! I’m still here !"
    new "¡No te distraigas demasiado con el trabajo! ¡Aquí sigo!"

    old "I just saw your messages. Why so many ? What’s going on ?"
    new "Acabo de ver tus mensajes. ¿Por qué tantos? ¿Qué está pasando?"

    old "Everything’s okay in there ?"
    new "¿Todo está bien ahí dentro?"

    old "Yeah ! Your cat’s adorable."
    new "¡Sí! Tu gato es adorable."

    old "No freak in sight today."
    new "Hoy no se ve ningún bicho raro."

    old "See [name] ? you're safe..."
    new "¿Ves [name]? Estás a salvo..."

    old "Hey [name] !"
    new "¡Hola [name]!"

    old "Wow. You’re stiff today. Didn’t think you’d freeze up like that. Like a deer !"
    new "Vaya. Estás muy rígido hoy. No pensé que te quedarías paralizado así. ¡Como un ciervo!"

    old "Didn’t expect to run into you here."
    new "No esperaba encontrarte aquí."

    old "Small world, right ?"
    new "¡Qué pequeño es el mundo, ¿verdad?!"

    old "What ? Cat got your tongue ?"
    new "¿Qué? ¿Te comió la lengua el gato?"

    old "You're so happy to see me !"
    new "¡Estás tan contento de verme!"

    old "Come on,"
    new "Vamos,"

    old "Don’t look at me like that. It’s just me."
    new "No me mires así. Solo soy yo."

    old "Your lack of reaction is starting to bore me [name]."
    new "Tu falta de reacción me está empezando a aburrir [name]."

    old "I once again ran into you by chance. Lucky, right ?"
    new "Me volví a encontrar contigo por casualidad. ¡Qué suerte, ¿verdad?!"

    old "Not that I’m complaining."
    new "No es que me queje."

    old "I... I swear-"
    new "Yo... lo juro-"

    old "If you don’t back off, I’ll scream so loud I won't even have to call the police for them to come."
    new "Si no te alejas, gritaré tan fuerte que ni siquiera tendré que llamar a la policía para que vengan."

    old "There’s the fire I remember !"
    new "¡Ahí está el fuego que recuerdo!"

    old "Aw, why didn't you do that last time, huh ?"
    new "Ay, ¿por qué no hiciste eso la última vez, eh?"

    old "Let’s not make a scene. Let's be civilized !"
    new "No armemos un escándalo. ¡Seamos civilizados!"

    old "You and I should talk. Preferably over a milkshake."
    new "Tú y yo deberíamos hablar. Preferiblemente tomando un batido."

    old "You still like strawberry, right ?"
    new "Todavía te gustan las fresas, ¿verdad?"

    old "You still like chocolate, right ?"
    new "Todavía te gusta el chocolate, ¿verdad?"

    old "You still like vanilla, right ?"
    new "Todavía te gusta la vainilla, ¿verdad?"

    old "What... what do you want ?"
    new "¿Qué... qué quieres?"

    old "Oh There you go ! See ? You can talk."
    new "¡Ahí lo tienes! ¿Ves? Puedes hablar."

    old "What do I want ?"
    new "¿Qué quiero?"

    old "Plenty of things. But nothing scary, promise, I pinky promise, I'll be nice."
    new "Muchas cosas. Pero nada que dé miedo, lo prometo, te lo prometo con el meñique, seré amable."

    old "Let’s chat. Catch up. Clear the air."
    new "Hablemos. Pongámonos al día. Aclaremos las cosas."

    old "Preferably over a milkshake. You loved that place, remember ?"
    new "Preferiblemente con un batido. Te encantaba ese sitio, ¿te acuerdas?"

    old "{sc=1}Do I have a choice-"
    new "{sc=1} ¿Tengo opción?"

    old "Don’t be an idiot, of course not. Come on."
    new "No seas idiota, por supuesto que no. Vamos."

    old "Oh ! Hi again, sweetie, back so soon ? Want your usual ?"
    new "¡Oh! Hola de nuevo, cariño, ¿tan pronto de vuelta? ¿Quieres lo de siempre?"

    old "Oh, Dolly, you know I come back to this place just for your perfect smile."
    new "Oh, Dolly, sabes que vuelvo a este lugar solo por tu sonrisa perfecta."

    old "I’m trying something new today."
    new "Hoy voy a probar algo nuevo."

    old "I’ll take some water. And they’ll have a smoothie. Mango flavored."
    new "Yo tomaré un poco de agua. Y ellos tomarán un batido. De mango."

    old "Coming right up !"
    new "¡Enseguida!"

    old "What the hell is wrong with you ?"
    new "¿Qué demonios te pasa?"

    old "This isn’t the weirdest thing you’ve done, but also- Why mango ?"
    new "Esto no es lo más raro que has hecho, pero también... ¿Por qué mango?"

    old "Mango smoothie sucks here, I don't like it, so I hope you'll hate it."
    new "El batido de mango aquí es horrible, no me gusta, así que espero que a ti también te disguste."

    old "You’re a fucking freak."
    new "Eres un maldito bicho raro."

    old "Why are we here ?"
    new "¿Por qué estamos aquí?"

    old "Because this is where we had fun last time."
    new "Porque aquí es donde nos divertimos la última vez."

    old "{i}And you [name], are very good company."
    new "{i} Y tú [name], eres muy buena compañía."

    old "You shoved me against a wall and broke my front door. I do not share the same feeling."
    new "Me empujaste contra la pared y rompiste la puerta de entrada. No siento lo mismo."

    old "I couldn't find how you escaped and it made me so paranoid I had to move apartments. I do not share the feeling."
    new "No pude averiguar cómo escapaste y me dio tanta paranoia que tuve que mudarme de apartamento. No comparto ese sentimiento."

    old "I couldn't live in my apartment with the fear that you could one day come back and attack me. I do not share the feeling."
    new "No podría vivir en mi apartamento con el temor de que algún día volvieras y me atacaras. No comparto ese sentimiento."

    old "Oh, so you thought of me ? That's touching."
    new "Oh, ¿así que pensaste en mí? Eso es conmovedor."

    old "If you intend to make fun of me all evening, I would rather go."
    new "Si tienes intención de burlarte de mí toda la noche, prefiero irme."

    old "I want to talk."
    new "Quiero hablar."

    old "Oh, sure, let me just pull up my recorder, I know people who would love to hear from you... {sc=2}THE COPS WHO ARE WORKING ON YOUR CASE {/sc}!!"
    new "Oh, claro, déjame sacar mi grabadora, conozco gente a la que le encantaría saber de ti... {sc=2} LOS POLICÍAS QUE ESTÁN TRABAJANDO EN TU CASO {/sc} !!"

    old "And why do you look like that !? You look ridiculous with blue hair."
    new "¿Y por qué te ves así? ¡Te ves ridículo con el pelo azul!"

    old "You think I look hot."
    new "Crees que estoy guapísima."

    old "What- the fuck ? I didn't say that, Silas."
    new "¿Qué carajo? Yo no dije eso, Silas."

    old "That's not even your real name, I shouldn't call you that..."
    new "Ese ni siquiera es tu nombre real, no debería llamarte así..."

    old "Man, I feel bad for the guy you mistook me for. Who named their kid Silas ? That's a wack ass name."
    new "Hombre, me da pena por el tipo con el que me confundiste. ¿Quién le puso Silas a su hijo? ¡Qué nombre tan ridículo!"

    old "Hey, don't talk about him that way !"
    new "¡Oye, no hables así de él!"

    old "Oh, sorry, I made fun of your pretty boyfriend. That’s soooo mean."
    new "Oh, perdón, me burlé de tu guapo novio. Eso es taaaan cruel."

    old "Don't tell me you guys broke up ?"
    new "¿No me digas que rompieron?"

    old "Let me guess... Even he didn't like you ? Doesn't surprise me, but it's funny nonetheless."
    new "Déjame adivinar... ¿Ni siquiera a él le caías bien? No me sorprende, pero aun así es gracioso."

    old "We were never together to begin with..."
    new "Nunca estuvimos juntos desde el principio..."

    old "Oh, you just made my day ! You know what, you get a prize for being so hilarious."
    new "¡Oh, me has alegrado el día! ¿Sabes qué? Te mereces un premio por ser tan gracioso."

    old "My name is Damien"
    new "Mi nombre es Damien."

    old "My name is Sylvain."
    new "Mi nombre es Sylvain."

    old "My name is Felix."
    new "Me llamo Félix."

    old "My name is Hugo."
    new "Me llamo Hugo."

    old "My name is Mathéo."
    new "Mi nombre es Mathéo."

    old "The name doesn't suit you."
    new "El nombre no te sienta bien."

    old "Hey, don’t insult my mother’s choice, she does love me."
    new "Oye, no insultes la decisión de mi madre, ella me quiere."

    old "I’m sure that’s not even your name."
    new "Estoy seguro de que ese ni siquiera es tu nombre."

    old "I won’t ever talk to you again after today."
    new "No volveré a hablarte nunca más después de hoy."

    old "My gift, as a thank you for the fun."
    new "Mi regalo, como agradecimiento por la diversión."

    old "So if you have questions, you should start asking them instead of wasting time."
    new "Así que, si tienes preguntas, deberías empezar a hacerlas en lugar de perder el tiempo."

    old "Why would I believe anything you say ?"
    new "¿Por qué iba a creer algo de lo que dices?"

    old "Oh, you shouldn’t."
    new "Oh, no deberías."

    old "But you will."
    new "Pero lo harás."

    old "Because you hate not knowing. Because uncertainty gnaws at you worse than fear ever did."
    new "Porque odias no saber. Porque la incertidumbre te corroe más que el miedo."

    old "You’ve been replaying that night for months. Trying to find the moment where everything went wrong."
    new "Llevas meses reviviendo esa noche. Intentando encontrar el momento en que todo salió mal."

    old "Trying to figure out how someone like me slipped past you."
    new "Trato de averiguar cómo alguien como yo pudo pasar desapercibido para ti."

    old "{sc=1}How didn't I see it coming ? Why would someone do that? Who was it ? Will I be able to sleep tonight ?"
    new "{sc=1} ¿Cómo no lo vi venir? ¿Por qué alguien haría eso? ¿Quién fue? ¿Podré dormir esta noche?"

    old "I’m just offering you closure."
    new "Solo te estoy ofreciendo una solución."

    old "That’s generous, don’t you think ?"
    new "Eso es generoso, ¿no crees?"

    old "Why now ?"
    new "¿Por qué ahora?"

    old "Because I ran into you... Also because you looked like you’d finally convinced yourself you were safe."
    new "Porque me topé contigo... También porque parecías haberte convencido finalmente de que estabas a salvo."

    old "You rebuilt yourself."
    new "Te reconstruiste a ti mismo."

    old "You did it, you moved on. A whole life that didn’t include me."
    new "Lo hiciste, seguiste adelante. Toda una vida que no me incluía."

    old "I find that lame."
    new "Me parece una tontería."

    old "What are you ?"
    new "Qué vas a ?"

    old "That’s a big one question ! You sure you don’t want to start smaller ?"
    new "¡Esa es una pregunta importante! ¿Seguro que no quieres empezar con algo más pequeño?"

    old "Like how I knew where you lived ? How long have I been reading your messages before you ever noticed me ?"
    new "¿Cómo supe dónde vivías? ¿Cuánto tiempo llevo leyendo tus mensajes antes de que te fijaras en mí?"

    old "Pick one question."
    new "Elige una pregunta."

    old "You earned that much."
    new "Te lo has ganado."

    old "Mango smoothie and water !"
    new "¡Batido de mango y agua!"

    old "Enjoy !"
    new "Disfrutar !"

    old "You should drink that. Before it melts."
    new "Deberías beberte eso. Antes de que se derrita."

    old "I’m not thirsty."
    new "No tengo sed."

    old "That wasn’t a suggestion."
    new "Eso no fue una sugerencia."

    old "Okay, drinks are done, time for the questions."
    new "Bien, las bebidas están listas, es hora de las preguntas."

    old "Suit yourself."
    new "Como quieras."

    old "Ugh... Still disgusting."
    new "Uf... Sigue siendo asqueroso."

    old "I actually hate smoothies."
    new "En realidad, odio los batidos."

    old "Drinking something this cold is completely unnecessary."
    new "Beber algo tan frío es completamente innecesario."

    old "If you don't intend to drink, then let's start with the questions."
    new "Si no tienes intención de beber, empecemos con las preguntas."

    old "Well ?"
    new "Bien ?"

    old "{i}Why me ?"
    new "{i} Por qué yo?"

    old "Ah, that one..."
    new "Ah, esa..."

    old "I was on my way to a friend’s place. Late, as usual. I wasn’t looking for anything, let alone planning anything."
    new "Iba de camino a casa de un amigo. Tarde, como siempre. No buscaba nada, y mucho menos planeaba nada."

    old "You were just there."
    new "Acabas de estar allí."

    old "I didn’t wake up thinking today I’ll ruin someone’s life."
    new "No me desperté pensando que hoy iba a arruinarle la vida a alguien."

    old "I did see you in the crowd. You looked distracted. Nervous. Like someone who lives a lot inside their own head."
    new "Te vi entre la multitud. Parecías distraído. Nervioso. Como alguien que vive muy metido en sus propios pensamientos."

    old "And then you approached me."
    new "Y entonces te acercaste a mí."

    old "So no, you’re not special."
    new "Así que no, no eres especial."

    old "Not even to you ?"
    new "¿Ni siquiera para ti?"

    old "No."
    new "No."

    old "You wanna know what I did that night ?"
    new "¿Quieres saber qué hice esa noche?"

    old "I went to a party, drank cheap beer, and made out with like four people. And then I moved on."
    new "Fui a una fiesta, bebí cerveza barata y me besé con unas cuatro personas. Y luego seguí adelante."

    old "You’re the only one who didn’t."
    new "Eres el único que no lo hizo."

    old "How did you lie to me all day ?"
    new "¿Cómo pudiste mentirme todo el día?"

    old "That’s barely a question. It’s easy !"
    new "Eso apenas es una pregunta. ¡Es fácil!"

    old "Easy ?"
    new "Fácil ?"

    old "Yes, you just say things. Confidently. People fill in the rest."
    new "Sí, tú solo di las cosas. Con seguridad. La gente completa el resto."

    old "Did you know about the meeting ?"
    new "¿Sabías de la reunión?"

    old "About Silas ? About me waiting there ?"
    new "¿Y Silas? ¿Y yo esperando allí?"

    old "No, not a clue."
    new "No, ni idea."

    old "I just threw out random answers. Half-truths. Vague reactions. You did all the work for me."
    new "Simplemente di respuestas al azar. Medias verdades. Reacciones vagas. Tú hiciste todo el trabajo por mí."

    old "You were so focused on how you felt that you never stopped to really look at me."
    new "Estabas tan concentrado en cómo te sentías que nunca te detuviste a mirarme de verdad."

    old "You kissed me !"
    new "¡Me besaste!"

    old "Like that’s hard ? It didn’t mean anything."
    new "¿Como si eso fuera difícil? No significaba nada."

    old "People kiss strangers all the time."
    new "La gente besa a desconocidos todo el tiempo."

    old "You confuse intimacy with significance."
    new "Confundes intimidad con importancia."

    old "But-"
    new "Pero-"

    old "That’s not my problem."
    new "Ese no es mi problema."

    old "Why did you do it ?"
    new "¿Por qué lo hiciste?"

    old "Poor impulse control, that’s what they call it."
    new "Falta de autocontrol, así lo llaman."

    old "Specialists, plural. Apparently, I’m missing chunks of empathy."
    new "Especialistas, en plural. Al parecer, me falta empatía."

    old "When the opportunity showed up, I took it. No deeper reason than that."
    new "Cuando se presentó la oportunidad, la aproveché. No hay otra razón más profunda que esa."

    old "It was fun."
    new "Fue divertido."

    old "So that's what I was? Just fun ?!"
    new "¿Así que eso era lo que era? ¿Solo diversión?"

    old "I wanted to see how long I could keep it up. How far I could go before you noticed."
    new "Quería ver cuánto tiempo podía mantenerlo. Hasta dónde podía llegar antes de que te dieras cuenta."

    old "And when it kept working ? When you trusted me more, and more ? It became hilarious !"
    new "¿Y cuando seguía funcionando? ¿Cuando confiabas en mí cada vez más y más? ¡Se volvió divertidísimo!"

    old "I just waited for the moment you’d finally catch on."
    new "Simplemente esperé el momento en que finalmente lo entendieras."

    old "That being said, it wasn't my favorite moment, kinda lame ending, I'll admit."
    new "Dicho esto, no fue mi momento favorito, el final fue un poco decepcionante, lo admito."

    old "Did I... plan to hurt you ? That night ?"
    new "¿Acaso... planeé lastimarte? ¿Esa noche?"

    old "No, ew."
    new "No, qué asco."

    old "That doesn’t interest me."
    new "Eso no me interesa."

    old "I wasn’t there to hurt you, I was there to see how far the situation could go. That’s different."
    new "No estaba allí para hacerte daño, estaba allí para ver hasta dónde podía llegar la situación. Eso es diferente."

    old "That being said, I half-expected you to make a move. You boldly invited me to stay. I thought you wanted to sleep with me."
    new "Dicho esto, en cierto modo esperaba que dieras el primer paso. Me invitaste a quedarme sin rodeos. Pensé que querías acostarte conmigo."

    old "Would you have ?"
    new "¿Lo habrías hecho?"

    old "And-"
    new "Y-"

    old "I probably would’ve called you by another name halfway through."
    new "Probablemente te habría llamado por otro nombre a mitad de la conversación."

    old "Just to see your face,"
    new "Solo para ver tu cara,"

    old "That moment when everything breaks. That’s the part I enjoy."
    new "Ese momento en que todo se rompe. Esa es la parte que disfruto."

    old "And that was the only thing I was after."
    new "Y eso era lo único que me interesaba."

    old "Anyway."
    new "De todos modos."

    old "I’m getting hungry. I’ll probably do some grocery shopping for tonight."
    new "Tengo hambre. Probablemente haré la compra para esta noche."

    old "Tell Dolly to put the drinks on my tab, okay ?"
    new "Dile a Dolly que ponga las bebidas en mi cuenta, ¿de acuerdo?"

    old "Oh, my name’s {color=#f60808}Mark{/color} here, by the way."
    new "Ah, por cierto, mi nombre es {color=#f60808} Mark {/color} ."

    old "Also, I’m moving out next week."
    new "Además, me mudo la semana que viene."

    old "New place, new area, I'll block everyone from my contacts here."
    new "Nuevo lugar, nueva zona, voy a bloquear a todos de mis contactos aquí."

    old "I meant what I said earlier. This was the last conversation we’ll ever have."
    new "Lo que dije antes lo decía en serio. Esta fue la última conversación que tendremos."

    old "You can say one last thing if you want. Else I'm just leaving."
    new "Puedes decir una última cosa si quieres. Si no, me voy."

    old "Right..."
    new "Bien..."

    old "Figures."
    new "Figuras."

    old "I hate you."
    new "Te odio."

    old "I fucking hate you."
    new "Te odio, joder."

    old "You psycho! Go fuck yourself."
    new "¡Psicópata! Vete a la mierda."

    old "I’d be disappointed if you didn’t."
    new "Me decepcionaría si no lo hicieras."

    old "Take care of yourself."
    new "Cuídate."

    old "Just.... Please remember me."
    new "Solo... Por favor, acuérdate de mí."

    old "I won’t do that."
    new "No haré eso."

    old "But I know you’ll remember me. That’s usually how it goes."
    new "Pero sé que te acordarás de mí. Así suele ser."

    old "Thank you for leaving me alone."
    new "Gracias por dejarme en paz."

    old "Girl, where is your spine ?! That's pathetic."
    new "¡Chica, ¿dónde está tu columna vertebral?! ¡Qué patético!"

    old "You’ll be fine even if I were around. Get some self-respect."
    new "Estarás bien aunque yo esté cerca. Ten un poco de amor propio."

    old "I'm going home..."
    new "Me voy a casa..."

    old "He smiles, a little awkwardly, but it’s a smile that makes my chest tighten in a way I wasn’t prepared for."
    new "Él sonríe, un poco torpemente, pero es una sonrisa que me oprime el pecho de una manera para la que no estaba preparado."

    old "He looks exactly like I imagined."
    new "Se ve exactamente como lo imaginaba."

    old "Don’t hug"
    new "No te abraces"

    old "His smile softens at that. And for a second, it feels perfect. Like this was always meant to happen."
    new "Su sonrisa se suaviza al oír eso. Y por un instante, todo parece perfecto. Como si esto estuviera destinado a suceder."

    old "Since the moment I spot him in the crowd, it’s been a whirlwind of emotions I can hardly keep up with."
    new "Desde el momento en que lo vi entre la multitud, ha sido un torbellino de emociones que apenas puedo asimilar."

    old "He flashes me a hopeful grin."
    new "Me dedica una sonrisa esperanzadora."

    old "Let it go"
    new "Déjalo ir"

    old "When I glance up, I catch Silas staring."
    new "Cuando levanto la vista, veo a Silas mirándome fijamente."

    old "The second our gazes meet, his cheek flushes, startled by the fact that I caught him in the act."
    new "En el instante en que nuestras miradas se cruzan, sus mejillas se enrojecen, sobresaltado por el hecho de que lo haya sorprendido con las manos en la masa."

    old "Then, his phone vibrates against the table."
    new "Entonces, su teléfono vibra contra la mesa."

    old "As Silas’ gaze drops to the screen, a frown appears instantly on his face. He stands up, scraping the chair loudly against the floor."
    new "Cuando Silas baja la mirada hacia la pantalla, un ceño fruncido aparece instantáneamente en su rostro. Se levanta, arrastrando ruidosamente la silla contra el suelo."

    old "It’s okay. We can still hang out tomorrow if you want."
    new "No pasa nada. Podemos quedar mañana si quieres."

    old "I step forward quickly, catching his hands in mine before I can talk myself out of it."
    new "Doy un paso adelante rápidamente y le agarro las manos antes de poder arrepentirme."

    old "His expression softens instantly."
    new "Su expresión se suaviza al instante."

    old "There’s something in his voice that makes my throat tighten."
    new "Hay algo en su voz que me hace sentir un nudo en la garganta."

    old "{sc=3}{color=#f60808}Get out and call the cops"
    new "{sc=3}{color=#f60808} Sal y llama a la policía"

    old "\"I had a great time today.\""
    new "'Hoy lo he pasado genial.'"

    old "\"But please, don’t bring strangers home :)\""
    new "'Pero por favor, no traigas extraños a casa :)'"

    old "My mouth opens, but nothing comes out."
    new "Abro la boca, pero no sale nada."

    old "My stomach turns."
    new "Se me revuelve el estómago."

    old "Ask him what he wants"
    new "Pregúntale qué quiere."

    old "I don’t move at first."
    new "Al principio no me muevo."

    old "{color=#f60808}Run away."
    new "{color=#f60808} Huye."

    old "My voice cracks between anger and fear."
    new "Mi voz se quiebra entre la ira y el miedo."

    old "He doesn’t flinch."
    new "No se inmuta."

    old "He blinks."
    new "Parpadea."

    old "Then he laughs."
    new "Entonces se ríe."

    old "Then he laughs quietly."
    new "Entonces ríe en voz baja."

    old "How did you lie the entire day ?"
    new "¿Cómo pudiste estar mintiendo todo el día?"

    old "Why did you do that ?"
    new "¿Por qué hiciste eso?"

    old "Did you intend to hurt me in my apartment ?"
    new "¿Tenías intención de hacerme daño en mi apartamento?"

    old "Tell him you hate him."
    new "Dile que lo odias."

    old "Ask him to remember you."
    new "Pídele que se acuerde de ti."

    old "Thank him for leaving."
    new "Dale las gracias por irse."

    old "I take a long breath that doesn’t quite steady my heart and start walking toward him, feeling the distance between us shrink with every step I make."
    new "Respiro hondo, aunque eso no logra calmar del todo mi corazón, y empiezo a caminar hacia él, sintiendo cómo la distancia entre nosotros se reduce con cada paso que doy."

    old "He turns, and our eyes meet."
    new "Él se gira y nuestras miradas se encuentran."

    old "What do I do ?"
    new "Qué debo hacer ?"

    old "It shouldn’t make me this flustered, but it does. I glance down, fiddling with the strap of my bag once again."
    new "No debería ponerme tan nerviosa, pero lo hace. Bajo la mirada y vuelvo a jugar con la correa de mi bolso."

    old "By the time we step back out onto the street, the late afternoon glow has slightly cooled down."
    new "Para cuando volvemos a salir a la calle, el resplandor del atardecer se ha atenuado un poco."

    old "I blinked, surprised to see him start walking without checking his phone."
    new "Parpadeé, sorprendida de verlo empezar a caminar sin mirar el teléfono."

    old "I'll take...."
    new "Tomaré..."

    old "The milkshakes arrived faster than I expected. A tall glass, thick and pastel pink, with a generous swirl of whipped cream."
    new "Los batidos llegaron antes de lo que esperaba. Un vaso alto, espeso y de color rosa pastel, con un generoso remolino de nata montada."

    old "The milkshakes arrived faster than I expected. A tall glass, brown with cherries on top."
    new "Los batidos llegaron antes de lo que esperaba. Un vaso alto, marrón con cerezas encima."

    old "The milkshakes arrived faster than I expected. A tall glass, white and with a generous swirl of whipped cream."
    new "Los batidos llegaron antes de lo que esperaba. Un vaso alto, blanco y con un generoso remolino de nata montada."

    old "He’s already moving before I can say anything."
    new "Ya se está moviendo antes de que pueda decir nada."

    old "We head back to the table together."
    new "Regresamos juntos a la mesa."

    old "I grab my stuff, and together we slip back out into the fading evening light."
    new "Recojo mis cosas y juntos salimos sigilosamente a la luz menguante del atardecer."

    old "The streets settle into a hush, bustle of the day settling into something quieter."
    new "Las calles se sumen en un silencio, el bullicio del día da paso a algo más tranquilo."

    old "We made it back to the bookstore, but the place feels completely different now."
    new "Conseguimos regresar a la librería, pero el lugar ahora se siente completamente diferente."

    old "Then he steps in."
    new "Entonces él entra."

    old "We keep back on walking, slower now."
    new "Seguimos caminando, ahora más despacio."

    old "When we reach my place we both hesitate at the bottom of the steps."
    new "Cuando llegamos a mi casa, ambos dudamos al pie de las escaleras."

    old "As I push the door open, I wave toward the mess scattered around."
    new "Al abrir la puerta, saludo con la mano hacia el desorden que hay esparcido por todas partes."

    old "Another message pops up, then another. All from Silas."
    new "Aparece otro mensaje, y luego otro. Todos de Silas."

    old "Almost instantly, a notification pops up."
    new "Casi al instante, aparece una notificación."

    old "{color=#d3239b}{b}Silas{/b}: {fi=13-1.1-40}{color=#d3239b}{i}I’m trying to get a flight tomorrow."
    new "{color=#d3239b}{b} Silas {/b} : {fi=13-1.1-40}{color=#d3239b}{i} Estoy intentando conseguir un vuelo mañana."

    old "{color=#d3239b}{b}Silas{/b}: {fi=13-1.1-40}{color=#d3239b}{i}Sorry if I made you worry."
    new "{color=#d3239b}{b} Silas {/b} : {fi=13-1.1-40}{color=#d3239b}{i} Lo siento si te preocupé."

    old "The door creaked open."
    new "La puerta se abrió con un crujido."

    old "But when he looked up at me..."
    new "Pero cuando me miró..."

    old "Never in my life had I seen someone shift so completely, so instantly."
    new "Jamás en mi vida había visto a alguien cambiar tan completamente, tan instantáneamente."

    old "I just remember that when I went back up with the cops, my cat was still there."
    new "Recuerdo que cuando volví con la policía, mi gato seguía allí."

    old "I stood up, smoothing out my clothes like I was about to have a normal night, and walked to the bedroom door."
    new "Me levanté, alisándome la ropa como si fuera a tener una noche normal, y me dirigí a la puerta del dormitorio."

    old "That night, we watched a movie."
    new "Esa noche vimos una película."

    old "The street feels different now."
    new "La calle se siente diferente ahora."

    old "The hug feels like a thousand slaps."
    new "El abrazo se siente como mil bofetadas."

    old "My body locks up instantly."
    new "Mi cuerpo se paraliza al instante."

    old "He pulls back, hands moving to grip my shoulders as if he owns the gesture."
    new "Se echa hacia atrás, y sus manos se mueven para sujetar mis hombros como si el gesto le perteneciera."

    old "Another step closer."
    new "Un paso más cerca."

    old "He beams."
    new "Él sonríe radiante."

    old "His eyes shine with something that feels too close to excitement."
    new "Sus ojos brillan con algo que se asemeja demasiado a la emoción."

    old "He lights up instantly, smiling bright and painfully familiar."
    new "Se ilumina al instante, sonriendo con una alegría radiante y dolorosamente familiar."

    old "{sc=1}I start to sprint, and the terrifying sound of someone following me makes me fear for my life."
    new "{sc=1} Empiezo a correr y el aterrador sonido de alguien que me sigue me hace temer por mi vida."

    old "The waitress nods cheerfully, jotting it down."
    new "La camarera asiente alegremente y lo anota."

    old "The waitress retuns then, her presence jarring and painfully normal."
    new "La camarera regresa entonces, su presencia resulta chocante y dolorosamente normal."

    old "The mango smoothie sits between us, bright, artificial, painfully cheerful."
    new "El batido de mango reposa entre nosotros, brillante, artificial, dolorosamente alegre."

    old "For a moment, he just stares at me."
    new "Por un momento, se queda mirándome fijamente."

    old "He reaches across the table, fingers closing around the glass, and pulls it toward him."
    new "Se inclina sobre la mesa, agarra el vaso con los dedos y lo acerca hacia sí."

    old "He doesn’t linger."
    new "No se demora."

    old "He turns and walks away, unbothered, the bell above the door chiming once as he leaves."
    new "Se da la vuelta y se marcha, imperturbable, mientras la campanilla de la puerta suena una sola vez al salir."

    old "He turns away, steps outside, and lets the door close behind him."
    new "Se da la vuelta, sale al exterior y deja que la puerta se cierre tras él."

    old "Then he walks out, unhurried, like this was always just another errand on his list."
    new "Luego sale, sin prisa, como si esto siempre hubiera sido un recado más en su lista."

    old "I stand by the bookstore, fidgeting with the strap of my bag."
    new "Estoy de pie junto a la librería, jugueteando con la correa de mi bolso."

    old "People blur past me, some in pairs, others alone, faces half-lit by the glow of their phones."
    new "La gente pasa a toda velocidad a mi lado, algunos en parejas, otros solos, con los rostros iluminados a media luz por el brillo de sus teléfonos."

    old "The last message from this morning stares back at me."
    new "El último mensaje de esta mañana me mira fijamente."

    old "My stomach flips."
    new "Se me revuelve el estómago."

    old "The same Silas who sends me dumb memes at night, complains about his job and listens when I spiral about my own crap."
    new "El mismo Silas que me manda memes tontos por la noche, se queja de su trabajo y me escucha cuando me desahogo sobre mis propias tonterías."

    old "I knew what his hair looked like, though."
    new "Sin embargo, sí sabía cómo era su cabello."

    old "He also told me how I could spot him."
    new "También me explicó cómo podía reconocerlo."

    old "I take my eyes off of my screen to scan the crowd again, my fingers twitching against my phone."
    new "Aparto la vista de la pantalla para volver a observar a la multitud, mientras mis dedos tiemblan contra el teléfono."

    old "I thought it would be fine. Simple. Just two people meeting after talking online for so long."
    new "Pensé que todo estaría bien. Sencillo. Solo dos personas que se reencuentran después de hablar en línea durante tanto tiempo."

    old "Would I be able to find him ? And if I don’t, would he recognize me ?"
    new "¿Podría encontrarlo? Y si no lo encuentro, ¿me reconocería?"

    old "A figure standing a little apart from the others, looking slightly lost, like he's searching for something... or in that case someone."
    new "Una figura que se mantenía un poco apartada de las demás, con aspecto ligeramente perdido, como si estuviera buscando algo... o en ese caso a alguien."

    old "He still doesn’t notice me until I’m nearly right in front of him."
    new "Todavía no se da cuenta de mi presencia hasta que estoy prácticamente justo delante de él."

    old "I freeze for a moment, searching his expression anxiously for any sign of the guy I had spent so long talking to online."
    new "Me quedo paralizada un instante, buscando ansiosamente en su expresión cualquier señal del chico con el que había estado hablando tanto tiempo en línea."

    old "I feel an odd sense of relief, but at the same time, something else flickers in my gut."
    new "Siento una extraña sensación de alivio, pero al mismo tiempo, algo más se agita en mi interior."

    old "Maybe it’s the years of seeing him as an anime profile, but his face almost doesn't fit, not that I’m unhappy."
    new "Quizás sea por los años de verlo como un perfil de anime, pero su cara casi no encaja, no es que me disguste."

    old "He shifts on his feet, then glances around, as if unsure where to start."
    new "Se remueve sobre sus pies y luego mira a su alrededor, como si no supiera por dónde empezar."

    old "A simple, tentative gesture. Like he’s not sure if it’s okay"
    new "Un gesto simple y vacilante. Como si no estuviera seguro de si está bien."

    old "I step in, wrapping my arms around him before I can overthink it."
    new "Me acerco y lo abrazo antes de poder pensarlo demasiado."

    old "He lets out a tiny breath, almost a laugh, as his arms close around me. Not too tight, just enough to make me feel great."
    new "Deja escapar un pequeño suspiro, casi una risita, mientras me abraza. No demasiado fuerte, lo justo para hacerme sentir genial."

    old "I could stay like this forever. Or at least, longer than what’s probably socially acceptable for a first meeting."
    new "Podría quedarme así para siempre. O al menos, más tiempo del que probablemente sea socialmente aceptable para un primer encuentro."

    old "I clear my throat, desperate to cover up how warm my face feels."
    new "Me aclaro la garganta, desesperada por disimular el calor que siento en la cara."

    old "God, I really want to hug him, I really do. But the knot of nerves in my stomach wins out."
    new "Dios, de verdad quiero abrazarlo, de verdad que sí. Pero el nudo de nervios en mi estómago me vence."

    old "It didn’t seem like he was hurt by my answer, it was a more surprised expression. But it was gone in an instant, replaced by an easy, understanding grin."
    new "No parecía que mi respuesta le hubiera dolido, sino que su expresión era más bien de sorpresa. Pero desapareció al instante, reemplazada por una sonrisa comprensiva y relajada."

    old "I glance toward the bookstore window, catching the reflection of us standing together in the glass."
    new "Miro hacia el escaparate de la librería y veo nuestro reflejo juntos en el cristal."

    old "The two of us have been quietly sifting through the shelves, peeking at those retail overstock copies with half-torn stickers and faded covers, trying to spot anything decent for cheap."
    new "Los dos hemos estado rebuscando discretamente entre los estantes, echando un vistazo a esos ejemplares sobrantes de las tiendas, con pegatinas medio rotas y portadas descoloridas, intentando encontrar algo decente a buen precio."

    old "His eyes brighten a little as he holds it up."
    new "Sus ojos se iluminan un poco al levantarlo."

    old "I’m still grinning like an idiot because... God, he’s actually here hanging out at the bookstore with me !"
    new "Sigo sonriendo como una idiota porque... ¡Dios mío, está aquí conmigo en la librería!"

    old "Maybe I should take it as a sign and finally gather all my courage to tell him how I feel..."
    new "Tal vez debería tomarlo como una señal y finalmente reunir todo mi valor para decirle lo que siento..."

    old "Silas has the book tucked under one arm, his fingers tapping absently against the cover as he glances over at me."
    new "Silas lleva el libro bajo el brazo, tamborileando distraídamente con los dedos sobre la portada mientras me mira de reojo."

    old "Silas has never been here, how would he know which way to go ? Even I didn’t know where the store was."
    new "Silas nunca había estado aquí, ¿cómo iba a saber por dónde ir? Ni siquiera yo sabía dónde estaba la tienda."

    old "My chest tightens as I slip my hand into his. His fingers are warm, calloused in a way I didn’t expect."
    new "Siento una opresión en el pecho al deslizar mi mano en la suya. Sus dedos están cálidos, callosos de una manera que no esperaba."

    old "Careful, considerate. It’s subtle, but it makes my stomach do that stupid little flutter thing again, and neither of us says anything about it as we head down the street."
    new "Cuidado, considerado. Es sutil, pero hace que mi estómago vuelva a sentir ese pequeño y estúpido cosquilleo, y ninguno de los dos dice nada al respecto mientras caminamos por la calle."

    old "Neon signs buzz softly above pastel-colored booths, and sunlight spills lazily across the floor through the big front windows."
    new "Los letreros de neón zumban suavemente sobre las cabinas de colores pastel, y la luz del sol se derrama perezosamente por el suelo a través de los grandes ventanales frontales."

    old "His head tilted ever so slightly, eyes softening in a way I couldn’t have been prepared for."
    new "Inclinó la cabeza levemente y su mirada se suavizó de una manera para la que no estaba preparado."

    old "He quickly looks away while rubbing his neck like it could erase the heat."
    new "Aparta la mirada rápidamente mientras se frota el cuello como si eso pudiera disipar el calor."

    old "The waitress comes to our table."
    new "La camarera se acerca a nuestra mesa."

    old "A Chocolate Milkshake"
    new "Un batido de chocolate"

    old "Maybe I actually have a chance ?"
    new "¿Tal vez sí tenga una oportunidad?"

    old "A Vanilla Milkshake"
    new "Un batido de vainilla"

    old "A few minutes slips by as we let quiet linger, trading sparse and weightless words."
    new "Transcurren unos minutos mientras dejamos que el silencio se prolongue, intercambiando palabras escasas y sin peso."

    old "Seizing the moment when I’m sure he can no longer see me, I quickly get up from my seat."
    new "Aprovechando el momento en que estoy segura de que ya no puede verme, me levanto rápidamente de mi asiento."

    old "As I pocket the receipt, I notice him turn around."
    new "Mientras guardaba el recibo en el bolsillo, lo vi darse la vuelta."

    old "His whole posture stiffens, shoulders rigid, jaw clenched."
    new "Toda su postura se tensa, los hombros rígidos, la mandíbula apretada."

    old "I hurry toward him and reach out to tap his shoulder."
    new "Me apresuro hacia él y extiendo la mano para tocarle el hombro."

    old "The milkshakes have gone a little soft but it still tasted sweet when I finally took a sip."
    new "Los batidos se habían ablandado un poco, pero aún así sabían dulces cuando finalmente les di un sorbo."

    old "I glance at Silas."
    new "Miro a Silas."

    old "I let out a slow breath."
    new "Solté un suspiro lento."

    old "The kind of hour where everything feels a little softer, a little easier to say."
    new "Ese tipo de hora en la que todo se siente un poco más suave, un poco más fácil de decir."

    old "Not yet."
    new "Aún no."

    old "The glow of the streetlamps washes the storefront in a tired, yellow light."
    new "El resplandor de las farolas baña la fachada de la tienda con una luz amarilla y apagada."

    old "I linger there awkwardly, wishing I could rewind the day, do it over and stretch it out a little longer."
    new "Me quedo allí un rato, incómodo, deseando poder retroceder en el tiempo, volver a empezar y alargarlo un poco más."

    old "A hollow feeling settles in my chest at the sight. I don’t want this to be it."
    new "Una sensación de vacío se instala en mi pecho al verlo. No quiero que esto sea el final."

    old "And something in me just... snaps."
    new "Y algo dentro de mí simplemente... se rompe."

    old "My fingers grip his a little too tight, but I’m too nervous to care."
    new "Aprieto sus dedos con demasiada fuerza, pero estoy demasiado nerviosa como para que me importe."

    old "And kisses me."
    new "Y me besa."

    old "Everything else falls away."
    new "Todo lo demás desaparece."

    old "I hear the faint creak of the bedroom door, followed by a curious meow."
    new "Oigo el leve crujido de la puerta del dormitorio, seguido de un maullido curioso."

    old "I hadn’t checked it all day, so I move over to open it."
    new "No lo había revisado en todo el día, así que me acerqué para abrirlo."

    old "My heart skips a beat."
    new "Mi corazón da un vuelco."

    old "{color=#d3239b}{b}Silas{/b}: {i}Hey, where are you ? I’m getting worried."
    new "{color=#d3239b}{b} Silas {/b} : {i} Oye, ¿dónde estás? Me estoy preocupando."

    old "The messages shift from lighthearted to urgent. Something strange."
    new "Los mensajes pasan de ser desenfadados a urgentes. Algo extraño."

    old "{color=#d3239b}{b}Silas{/b}: {i}Please, tell me you’re alright."
    new "{color=#d3239b}{b} Silas {/b} : {i} Por favor, dime que estás bien."

    old "{color=#d3239b}{b}Silas{/b}: {i}I don’t have much wifi, but message me soon."
    new "{color=#d3239b}{b} Silas {/b} : {i} No tengo mucho wifi, pero envíame un mensaje pronto."

    old "A weird, uneasy feeling twists in my stomach."
    new "Una extraña y desagradable sensación me revuelve el estómago."

    old "I hear the bedroom door open again."
    new "Oigo que la puerta del dormitorio se abre de nuevo."

    old "The moment the bedroom door clicks shut, I waste no time opening the laptop."
    new "En cuanto la puerta del dormitorio se cierra con un clic, no pierdo el tiempo y abro el portátil."

    old "I read the message over and over. It doesn’t make sense."
    new "Leí el mensaje una y otra vez. No tiene sentido."

    old "Then who was with me—"
    new "Entonces, ¿quién estaba conmigo?"

    old "The bedroom door creaks open again, slower this time."
    new "La puerta del dormitorio se abre de nuevo con un crujido, esta vez más despacio."

    old "A calm, deep hum follows."
    new "Le sigue un zumbido tranquilo y profundo."

    old "{sc=2}There is a stranger in my house."
    new "{sc=2} Hay un extraño en mi casa."

    old "{sc=6}{b}{color=#f60808}WHO IS THAT ?!"
    new "{sc=6}{b}{color=#f60808} ¡¿QUIÉN ES ESE?!"

    old "{sc=1}It’s too calm. Too normal. It feels wrong."
    new "{sc=1} Es demasiado tranquilo. Demasiado normal. Se siente mal."

    old "I can hear the man, whoever he is cooing at my cat, making her purr even louder."
    new "Puedo oír al hombre, sea quien sea, hablándole con dulzura a mi gata, haciendo que ronronee aún más fuerte."

    old "My body won’t obey me. My legs feel as if they’re chained to the couch."
    new "Mi cuerpo no me obedece. Siento las piernas como si estuvieran encadenadas al sofá."

    old "My phone buzzes on the coffee table, but I don’t dare look away from the bedroom door. Not yet. Afraid to even blink."
    new "Mi teléfono vibra sobre la mesa de centro, pero no me atrevo a apartar la vista de la puerta del dormitorio. Todavía no. Me da miedo incluso parpadear."

    old "The laptop screen is still open in front of me, the message from the real Silas who seemingly went offline."
    new "La pantalla del portátil sigue abierta frente a mí, con el mensaje del verdadero Silas, que aparentemente se desconectó."

    old "My fingertips graze it, but I hesitate. The weight of the decision is suffocating, and my mind spins in circles."
    new "Mis dedos lo rozan, pero dudo. El peso de la decisión me asfixia y mi mente da vueltas sin control."

    old "Or maybe it was a death wish disguised as courage."
    new "O tal vez se trataba de un deseo de muerte disfrazado de valentía."

    old "My hand hovered over the handle, shaking."
    new "Mi mano se cernía sobre el asa, temblando."

    old "And yet... I turned the knob."
    new "Y sin embargo... giré la perilla."

    old "He was crouched on the floor, scratching my cat behind her ears, a gentle smile on his lips."
    new "Estaba agachado en el suelo, rascándole a mi gata detrás de las orejas, con una suave sonrisa en los labios."

    old "Everything changed."
    new "Todo cambió."

    old "The warmth was gone."
    new "El calor había desaparecido."

    old "It was like watching someone drop a mask."
    new "Fue como ver a alguien quitarse una máscara."

    old "Suddenly, you’re staring at something that’s known you just enough to make your skin crawl."
    new "De repente, te encuentras mirando algo que te conoce lo suficiente como para ponerte los pelos de punta."

    old "I don’t know who he was."
    new "No sé quién era."

    old "For a split second, neither of us moved."
    new "Durante una fracción de segundo, ninguno de los dos se movió."

    old "{sc=1}Not the smile from the café, or when we talked about books."
    new "{sc=1} No la sonrisa del café, ni cuando hablábamos de libros."

    old "{sc=1}Something else."
    new "{sc=1} Otra cosa."

    old "Move. NOW!"
    new "¡Muévete! ¡AHORA!"

    old "I didn’t even think about the charger still plugged in or the shoes abandoned near the door."
    new "Ni siquiera pensé en el cargador que seguía enchufado ni en los zapatos abandonados cerca de la puerta."

    old "I bolted to the front door, my heartbeat a deafening drum in my ears."
    new "Salí disparado hacia la puerta principal, con los latidos de mi corazón resonando como un tambor ensordecedor en mis oídos."

    old "I needed to get out."
    new "Necesitaba salir."

    old "I sprinted down the corridor, dialing emergency services with shaking hands."
    new "Corrí a toda velocidad por el pasillo, marcando el número de emergencias con manos temblorosas."

    old "Smiling."
    new "Sonriente."

    old "The phone connected to the police, my voice cracking as I gave my address."
    new "El teléfono se conectó con la policía, y mi voz se quebró al dar mi dirección."

    old "I don’t remember when the officers arrived, nor what I did while waiting for them."
    new "No recuerdo cuándo llegaron los agentes, ni qué hice mientras los esperaba."

    old "With a note left on top of my open laptop."
    new "Con una nota dejada encima de mi portátil abierta."

    old "Maybe it was the terror."
    new "Quizás fue el terror."

    old "Maybe I just wanted this to not be true."
    new "Quizás simplemente quería que esto no fuera cierto."

    old "It was probably just a prank."
    new "Probablemente solo fue una broma."

    old "Maybe someone stole his phone..."
    new "Quizás alguien le robó el teléfono..."

    old "I laughed, a brittle, hollow sound."
    new "Me reí, con un sonido frágil y hueco."

    old "What kind of monster would do that ?"
    new "¿Qué clase de monstruo haría eso?"

    old "We laughed."
    new "Nos reímos."

    old "I ignored the cold way his eyes would sometimes linger on me, like he was waiting for me to catch on."
    new "Ignoré la mirada fría con la que a veces se detenía en mí, como si esperara a que me diera cuenta."

    old "We didn’t sleep together."
    new "No dormimos juntos."

    old "Quieter."
    new "Más silencioso."

    old "Late morning sunlight filters over the bookstore’s awning, brushing the pavement with a warm gold."
    new "La luz del sol de la mañana se filtra por encima del toldo de la librería, bañando el pavimento con un cálido tono dorado."

    old "I guess muscle memory takes time to heal."
    new "Supongo que la memoria muscular tarda en recuperarse."

    old "Every time I gathered the courage to pass here again, some part of me twisted, half-expecting to catch a familiar blond head leaning against the wall, mocking me."
    new "Cada vez que reunía el valor para pasar por aquí de nuevo, una parte de mí se retorcía, esperando casi ver una cabeza rubia familiar apoyada contra la pared, burlándose de mí."

    old "I pull my phone from my pocket at the thought."
    new "Saco el teléfono del bolsillo al pensarlo."

    old "Silas is gone."
    new "Silas se ha ido."

    old "We talked a little, right after everything. He was kind about it, but understandably got freaked out that I didn't realize it wasn't him."
    new "Hablamos un poco justo después de todo. Fue amable al respecto, pero comprensiblemente se asustó porque no me di cuenta de que no era él."

    old "A month later, he told me he’d met someone. Someone real. Someone who wasn't me."
    new "Un mes después, me dijo que había conocido a alguien. Alguien de verdad. Alguien que no era yo."

    old "Real Silas left my life, and fake Silas was never found by the cops."
    new "El verdadero Silas desapareció de mi vida, y al falso Silas nunca lo encontró la policía."

    old "Instead, all I felt was stupid."
    new "En cambio, lo único que sentí fue estupidez."

    old "It haunted me for so long."
    new "Me atormentó durante mucho tiempo."

    old "Life, stubborn as ever, kept going."
    new "La vida, tan obstinada como siempre, siguió su curso."

    old "I breathe out slowly, finally ready to get over my fear."
    new "Respiro hondo, finalmente lista para superar mi miedo."

    old "I turn away from the bookstore and start walking again, letting the familiar rhythm of the street pull me forward."
    new "Me alejo de la librería y empiezo a caminar de nuevo, dejándome llevar por el ritmo familiar de la calle."

    old "{sc=2}{color=#f60808}This is a nightmare-"
    new "{sc=2}{color=#f60808} Esto es una pesadilla-"

    old "{color=#FCD4D4}Someone I should’ve passed on the street without a second glance."
    new "{color=#FCD4D4} Alguien a quien debería haber pasado por la calle sin siquiera mirarlo dos veces."

    old "It's warm, firm, and completely wrong."
    new "Es cálido, firme y completamente erróneo."

    old "I can’t move."
    new "No puedo moverme."

    old "It’s the same laugh."
    new "Es la misma risa."

    old "He's delighted."
    new "Está encantado."

    old "I'm terrified by his eyes."
    new "Me aterra su mirada."

    old "Emotionless, glassy, flat."
    new "Sin emociones, inexpresiva, plana."

    old "The same ones I still see in nightmares."
    new "Las mismas que sigo viendo en mis pesadillas."

    old "He leans in slightly, head tilted, smile curling with almost childlike delight."
    new "Se inclina ligeramente, con la cabeza ladeada y una sonrisa que denota una alegría casi infantil."

    old "I can’t tell if he’s closing on me on purpose or if he’s simply incapable of respecting personal space."
    new "No sé si se me acerca a propósito o si simplemente es incapaz de respetar el espacio personal."

    old "He’s still smiling."
    new "Sigue sonriendo."

    old "And I realize I have to say something, ANYTHING before my fear swallows me whole."
    new "Y me doy cuenta de que tengo que decir algo, CUALQUIER COSA, antes de que el miedo me consuma por completo."

    old "He fucking beams."
    new "Él está radiante."

    old "He leans back just slightly, giving me a sliver of space. Not because he’s scared, but because he’s 'indulging' me."
    new "Se inclina ligeramente hacia atrás, dejándome un pequeño resquicio de espacio. No porque tenga miedo, sino porque me está 'consintiendo'."

    old "But he waits."
    new "Pero él espera."

    old "{sc=1}I didn't manage to go very far before I feel hands gripping my shoulders."
    new "{sc=1} No logré ir muy lejos antes de sentir unas manos agarrándome los hombros."

    old "{sc=1}Eventually, with his hands on my shoulder, Silas walks me to the milkshake shop."
    new "{sc=1} Finalmente, con sus manos sobre mi hombro, Silas me acompaña hasta la tienda de batidos."

    old "The one nearly hidden behind a partition wall, half in shadow."
    new "La que está casi oculta tras un tabique, medio en la sombra."

    old "He slides into the seat across from me like this is a perfectly ordinary outing."
    new "Se desliza en el asiento frente a mí como si se tratara de una salida de lo más normal."

    old "For a moment, it’s just the hum of the neon sign and the faint clatter of the kitchen."
    new "Por un instante, solo se oye el zumbido del letrero de neón y el leve ruido de la cocina."

    old "She brightens the second she sees him."
    new "Su rostro se ilumina en el instante en que lo ve."

    old "Oh gosh, I want to kill myself right now."
    new "¡Ay, Dios mío, quiero suicidarme ahora mismo!"

    old "The second she’s out of earshot, my breath finally rips free."
    new "En el instante en que ella queda fuera del alcance del oído, finalmente puedo contener la respiración."

    old "He doesn’t stop smiling."
    new "No deja de sonreír."

    old "He rests his elbows on the table, leaning forward just a little."
    new "Apoya los codos en la mesa, inclinándose ligeramente hacia adelante."

    old "It’s a real laugh, bright, sharp, delighted, as if I’ve just said something incredibly entertaining."
    new "Es una risa genuina, brillante, aguda, alegre, como si acabara de decir algo increíblemente divertido."

    old "She slides the drinks onto the table with a smile that doesn’t belong at this moment."
    new "Desliza las bebidas sobre la mesa con una sonrisa que no corresponde a ese momento."

    old "He glances at the glass in front of me, then back at my face."
    new "Él mira de reojo el vaso que tengo delante, y luego vuelve a mirarme a la cara."

    old "It’s colder than I expected. My fingers stiffen around it."
    new "Hace más frío de lo que esperaba. Se me entumecen los dedos al agarrarlo."

    old "The sweetness floods my mouth, thick and cloying, turning my stomach."
    new "El dulzor me inunda la boca, denso y empalagoso, revolviéndome el estómago."

    old "My throat tightens as I swallow."
    new "Siento un nudo en la garganta al tragar."

    old "He takes a long sip."
    new "Da un largo sorbo."

    old "Just long enough to look... mildly surprised ?"
    new "¿El tiempo justo para mirar... ligeramente sorprendido?"

    old "Then laughs."
    new "Luego se ríe."

    old "Not cruel."
    new "No es cruel."

    old "He studies me instead, fingers tapping idly against the table."
    new "En cambio, me observa, tamborileando con los dedos distraídamente sobre la mesa."

    old "What the hell ?"
    new "Qué demonios ?"

    old "Actually frown."
    new "De hecho, frunce el ceño."

    old "I swallow, my mouth dry."
    new "Trago saliva, tengo la boca seca."

    old "I just stare at him, hands curled tight in my lap, chest rising and falling too fast."
    new "Me quedo mirándolo fijamente, con las manos apretadas en mi regazo, el pecho subiendo y bajando demasiado rápido."

    old "Disappointment."
    new "Decepción."

    old "He turns, slips his hands into his pockets, and walks toward the exit without another glance."
    new "Se da la vuelta, mete las manos en los bolsillos y camina hacia la salida sin mirar atrás."

    old "Then he smiles."
    new "Entonces sonríe."

    old "The door shuts."
    new "La puerta se cierra."

    old "Really pauses this time."
    new "Esta vez sí que hay pausas."

    old "The bell rings."
    new "Suena la campana."

    old "He’s gone."
    new "Se ha ido."

    old "I sit there for a long moment, staring at the space across from me."
    new "Me quedo sentada allí un buen rato, mirando fijamente el espacio que tengo enfrente."

    old "You need a name."
    new "Necesitas un nombre."

    old "The street was busy today. Too busy."
    new "La calle estaba muy concurrida hoy. Demasiado concurrida."

    old "Late afternoon light spills across the pavement, catching on metal railings and shop windows."
    new "La luz del atardecer se derrama sobre la acera, reflejándose en las barandillas metálicas y los escaparates de las tiendas."

    old "I check mine for the fourth time in a minute... maybe fifth ?"
    new "Reviso el mío por cuarta vez en un minuto... ¿quizás quinta?"

    old "{color=#d3239b}{b}Silas{/b}: {i}See you at 5 ! Can’t wait."
    new "{color=#d3239b}{b} Silas {/b} : {i} Nos vemos a las 5! No puedo esperar."

    old "I shouldn’t be this nervous. It’s just Silas."
    new "No debería estar tan nerviosa. Es solo Silas."

    old "The one who confessed, not too long ago, that he hated how he looked in photos, and how he never showed his face online because of it."
    new "El mismo que confesó, no hace mucho, que odiaba cómo se veía en las fotos y que por eso nunca mostraba su rostro en internet."

    old "They were freshly dyed in pale blond, he sent me a picture of it last week, his face hidden behind his phone."
    new "Se las había teñido recientemente de rubio platino; me envió una foto la semana pasada, con la cara oculta tras el móvil."

    old "He was supposed to wear an oversized purple hoodie and didn’t forget to joke about how it made him look like a giant eggplant."
    new "Se suponía que debía usar una sudadera morada extragrande y no olvidó bromear sobre cómo lo hacía parecer una berenjena gigante."

    old "We’d agreed to meet in front of the bookstore near his hotel."
    new "Habíamos quedado en encontrarnos frente a la librería cerca de su hotel."

    old "But now, standing here, I’m not so sure anymore."
    new "Pero ahora, aquí de pie, ya no estoy tan seguro."

    old "And as if my thoughts were perfectly timed, I spot him in the crowd."
    new "Y como si mis pensamientos hubieran coincidido a la perfección, lo divisé entre la multitud."

    old "A jolt of recognition hits me. I can’t see his face yet, but his blond hair... That must be him."
    new "De repente, lo reconozco. Todavía no puedo ver su rostro, pero su cabello rubio... Debe ser él."

    old "He laughs softly, almost nervously."
    new "Se ríe suavemente, casi con nerviosismo."

    old "It’s probably just the nerves of meeting someone you used to chat with online, in real life for the first time."
    new "Probablemente se trate simplemente de los nervios de conocer en persona, por primera vez, a alguien con quien solías chatear en línea."

    old "He looks down for a second, almost bashful."
    new "Baja la mirada por un segundo, casi avergonzado."

    old "I laugh awkwardly. It all feels surreal."
    new "Me río nerviosamente. Todo parece surrealista."

    old "It was shallow to be reassured by his face, but I know that I would have loved him anyway."
    new "Fue superficial dejarme tranquilizar por su rostro, pero sé que lo habría amado de todos modos."

    old "He hesitates for a second, then opens his arms to invite me into a hug."
    new "Duda un segundo, luego abre los brazos para invitarme a un abrazo."

    old "Hug him"
    new "Abrázalo"

    old "My heart stutters in my chest. God, I’ve pictured this moment so many times, how it might feel to actually hold him, to feel his real warmth instead of cold pixels."
    new "Mi corazón late con fuerza en mi pecho. Dios, he imaginado este momento tantas veces, cómo sería poder abrazarlo, sentir su verdadero calor en lugar de fríos píxeles."

    old "He smells like cheap fabric softener and airport coffee. His hoodie is soft, swallowing him whole like he said it would."
    new "Huele a suavizante barato y a café de aeropuerto. Su sudadera es suave, lo envuelve por completo tal como había dicho."

    old "The kind of hug you fall into."
    new "El tipo de abrazo en el que te dejas caer."

    old "When we pull apart, I notice a flush on his cheeks."
    new "Cuando nos separamos, noto que se le ruborizan las mejillas."

    old "My heart skips, catching somewhere between my ribs."
    new "Siento un vuelco en el corazón, como si se me hubiera detenido entre las costillas."

    old "I offer a sheepish smile instead, tucking my hands into the pockets of my jacket."
    new "En lugar de eso, ofrezco una sonrisa tímida, metiendo las manos en los bolsillos de mi chaqueta."

    old "His arms drop immediately, and for a second something flickers across his face."
    new "Sus brazos caen inmediatamente, y por un segundo algo cruza fugazmente por su rostro."

    old "He laughs, a sound so much better in person than it ever was through voice messages."
    new "Se ríe, y su risa suena mucho mejor en persona que a través de mensajes de voz."

    old "He shifts his weight, glancing around, then back at me."
    new "Cambia de postura, mira a su alrededor y luego vuelve a mirarme."

    old "His face lights up."
    new "Su rostro se ilumina."

    old "We’re already deep in the narrow aisles of the bookstore, the dusty scent of old pages thick in the air."
    new "Ya estamos adentrados en los estrechos pasillos de la librería, con el olor a polvo de las páginas viejas impregnando el aire."

    old "Silas crouches down by the lower shelf to pull out a paperback with a creased spine and a slightly battered cover."
    new "Silas se agacha junto al estante inferior para sacar un libro de bolsillo con el lomo arrugado y la portada ligeramente desgastada."

    old "I glance over and immediately laugh."
    new "Miro de reojo y enseguida me río."

    old "He blinks, then grins, a little sheepishly."
    new "Parpadea y luego sonríe, un poco avergonzado."

    old "I watch him flip it over to check the back."
    new "Lo observo darle la vuelta para revisar la parte de atrás."

    old "I was still having a hard time acknowledging that it was real."
    new "Todavía me costaba aceptar que fuera real."

    old "I decide to tease, nudging him lightly with my shoulder."
    new "Decido bromear con él, dándole un ligero codazo con el hombro."

    old "He snorts a laugh, closing the book and holding it up like a prize."
    new "Suelta una risita, cierra el libro y lo alza como si fuera un trofeo."

    old "He looks at me, his grin softening just a little."
    new "Me mira, y su sonrisa se suaviza un poco."

    old "And just like that, my stomach flutters again."
    new "Y así, de repente, siento otro cosquilleo en el estómago."

    old "He hums low in his throat, squinting up the street like he’s weighing his options."
    new "Tararea en voz baja, entrecerrando los ojos mientras mira hacia la calle como si estuviera sopesando sus opciones."

    old "Ask how he knows"
    new "Pregúntale cómo lo sabe"

    old "I decided not to ask. Instead, I fall into step beside him, the sound of our shoes scraping the pavement in unison, mingling with the faint chatter of the street."
    new "Decidí no preguntar. En cambio, me puse a caminar a su lado, el sonido de nuestros zapatos raspando el pavimento al unísono, mezclándose con el leve murmullo de la calle."

    old "Silas glances down, then without saying a word, he casually holds his hand out, palm up between us, like it’s the most natural thing in the world."
    new "Silas baja la mirada y, sin decir palabra, extiende la mano con la palma hacia arriba entre nosotros, como si fuera lo más natural del mundo."

    old "His hand gently squeezes mine. His eyes stay fixed straight ahead, never meeting my gaze, but the faint smile curling at the corner of his mouth spoke on his behalf."
    new "Su mano aprieta suavemente la mía. Sus ojos permanecen fijos al frente, sin cruzarse con mi mirada, pero la leve sonrisa que se dibuja en la comisura de sus labios habla por él."

    old "I notice he’s walking a little slower than before. Not lagging, just... matching my pace."
    new "Me doy cuenta de que camina un poco más despacio que antes. No es que se quede atrás, simplemente... va a mi ritmo."

    old "The milkshake shop is small and bright, the kind of place that smells like syrup and sugar the second you step inside."
    new "La heladería es pequeña y luminosa, del tipo de sitio que huele a sirope y azúcar nada más entrar."

    old "I slip off my jacket and bag, then settle myself into the booth across from Silas."
    new "Me quito la chaqueta y la bolsa, y me acomodo en la cabina frente a Silas."

    old "I bite back a laugh and let him win this time around."
    new "Contengo la risa y dejo que gane esta vez."

    old "A Strawberry Milkshake"
    new "Un batido de fresa"

    old "His tone is playful, clearly teasing me, but the warmth in his gaze makes my heart skip a beat."
    new "Su tono es juguetón, claramente me está tomando el pelo, pero la calidez de su mirada hace que mi corazón dé un vuelco."

    old "It’s so dumb but so sweet at the same time. It makes my chest bloom in the best way."
    new "Es tan tonto pero a la vez tan dulce. Me hace sentir una emoción indescriptible."

    old "Silas hesitates, only to end up ordering the same flavor as mine."
    new "Silas duda, pero al final termina pidiendo el mismo sabor que yo."

    old "I chuckle, shaking my head."
    new "Me río entre dientes, negando con la cabeza."

    old "And damn if that doesn’t make me melt a little."
    new "Y maldita sea, eso me derrite un poco."

    old "I chuckle and thank him, fiddling with the straw."
    new "Me río entre dientes y le doy las gracias, mientras jugueteo con la pajita."

    old "I head over to the counter and ask to pay for both drinks in advance."
    new "Me dirijo al mostrador y pido pagar las dos bebidas por adelantado."

    old "His face drops."
    new "Su rostro se ensombrece."

    old "It takes him barely a second to scan the cafe, eyes darting from table to table."
    new "Le basta un segundo para recorrer la cafetería con la mirada, pasando rápidamente de mesa en mesa."

    old "Seeing him getting this anxious made me feel a stab of guilt."
    new "Verlo tan ansioso me produjo una punzada de culpa."

    old "He flinches slightly, then his expression breaks, all that tension unraveling like it never existed."
    new "Se estremece ligeramente, luego su expresión se quiebra, toda esa tensión se deshace como si nunca hubiera existido."

    old "He lets out a breathy laugh."
    new "Suelta una risa entrecortada."

    old "I blink, surprised, then let out a nervous laugh."
    new "Parpadeo, sorprendida, y luego suelto una risa nerviosa."

    old "The conversation picks up again, lighter this time."
    new "La conversación se retoma, esta vez con un tono más ligero."

    old "The cafe starts to empty out. Outside, the daylight is finally dimming."
    new "La cafetería comienza a vaciarse. Afuera, la luz del día finalmente empieza a menguar."

    old "I hesitate, then shrug, trying to play it casual."
    new "Dudo un momento, luego me encojo de hombros, tratando de parecer despreocupado."

    old "His expression softens immediately."
    new "Su expresión se suaviza de inmediato."

    old "He slightly leans forward, resting his elbows on the table."
    new "Se inclina ligeramente hacia adelante, apoyando los codos sobre la mesa."

    old "I force a smile."
    new "Fuerzo una sonrisa."

    old "Silas watches me for a second, then stands up, stretching."
    new "Silas me observa por un segundo, luego se levanta y se estira."

    old "I laugh, the knot in my chest loosening a little."
    new "Me río, y el nudo que tengo en el pecho se va aflojando un poco."

    old "Not that I’ll actually say it."
    new "No es que vaya a decirlo en realidad."

    old "But I’ll walk beside him in silence for a little while longer."
    new "Pero caminaré a su lado en silencio un poco más."

    old "The big display window is dark, a handwritten closed sign hung slightly crooked against the glass."
    new "El gran escaparate está oscuro, y un cartel de 'cerrado' escrito a mano cuelga ligeramente torcido contra el cristal."

    old "Silas seems to hesitate too, glancing at the store like he’s waiting for something, but there’s nothing left to wait for."
    new "Silas también parece dudar, mirando hacia la tienda como si esperara algo, pero ya no hay nada que esperar."

    old "Not after everything. Not when the weight of the day feels like it’s still hanging in the air between us."
    new "No después de todo. No cuando el peso del día parece seguir flotando en el aire entre nosotros."

    old "He tries to sound casual, but there’s a stiffness to his voice."
    new "Intenta sonar natural, pero su voz denota rigidez."

    old "I laugh awkwardly."
    new "Me río con incomodidad."

    old "Silas blinks at me, stunned."
    new "Silas me mira parpadeando, atónito."

    old "It’s soft at first, a little hesitant, but then his hand lifts to cup my cheek."
    new "Al principio es suave, un poco vacilante, pero luego levanta la mano para acariciar mi mejilla."

    old "When we pull apart, Silas’s face is a little pink, his smile lopsided."
    new "Cuando nos separamos, el rostro de Silas está un poco sonrojado y su sonrisa es torcida."

    old "For a while there, I forgot about everything. I didn’t think I’d get to have something like this again."
    new "Durante un tiempo, me olvidé de todo. No pensé que volvería a tener algo así."

    old "We stayed there for a second longer, just standing in the quiet glow of the streetlights, hands still tangled."
    new "Nos quedamos allí un segundo más, simplemente de pie bajo el tenue resplandor de las farolas, con las manos aún entrelazadas."

    old "I trail off."
    new "Me quedo en silencio."

    old "He laughs softly."
    new "Él ríe suavemente."

    old "I take off my jacket by the door."
    new "Me quito la chaqueta junto a la puerta."

    old "Silas heads toward the bedroom while I step into the living room."
    new "Silas se dirige hacia el dormitorio mientras yo entro en la sala de estar."

    old "Making sure nothing’s lying around, I spot my laptop on the coffee table."
    new "Tras asegurarme de que no hay nada tirado por ahí, localizo mi portátil en la mesa de centro."

    old "A flood of notifications hit me — almost forty unread messages, all from Silas."
    new "Me llegó una avalancha de notificaciones: casi cuarenta mensajes sin leer, todos de Silas."

    old "I quickly click on the first one."
    new "Hago clic rápidamente en el primero."

    old "{color=#d3239b}{b}Silas{/b}: {i}Why aren’t you responding ? I’m starting to think something’s wrong."
    new "{color=#d3239b}{b} Silas {/b} : {i} ¿Por qué no respondes? Empiezo a pensar que algo anda mal."

    old "{color=#d3239b}{b}Silas{/b}: {i}I’m sorry my flight got canceled. I hope you didn’t wait long."
    new "{color=#d3239b}{b} Silas {/b} : {i} Lamento que mi vuelo haya sido cancelado. Espero que no hayas esperado mucho."

    old "{color=#d3239b}{b}Silas{/b}: {i}[name] ?"
    new "{color=#d3239b}{b} Silas {/b} : {i} [name]?"

    old "Why would he have sent me so many messages ?"
    new "¿Por qué me habría enviado tantos mensajes?"

    old "I stare at my laptop, the last message from Silas on the screen."
    new "Miro fijamente mi portátil; el último mensaje de Silas aparece en la pantalla."

    old "I quickly shut the laptop."
    new "Cerré rápidamente el portátil."

    old "Silas looks a little puzzled but nods, carrying the cat back."
    new "Silas parece un poco desconcertado, pero asiente con la cabeza y lleva al gato de vuelta."

    old "I scrutinize him as he walks away."
    new "Lo observo con atención mientras se aleja."

    old "My hands trembling, I type a message to Silas."
    new "Con las manos temblorosas, escribo un mensaje a Silas."

    old "{color=#d3239b}{b}Silas{/b}: {fi=13-1.1-40}{color=#d3239b}{i}Sorry, I wasn’t there to answer you."
    new "{color=#d3239b}{b} Silas {/b} : {fi=13-1.1-40}{color=#d3239b}{i} Lo siento, no estaba allí para responderte."

    old "He wasn’t here. He couldn’t have been."
    new "Él no estaba aquí. No podía haber estado."

    old "I freeze."
    new "Me quedo paralizado."

    old "A low meow breaks the silence."
    new "Un maullido bajo rompe el silencio."

    old "Dread twists in my chest."
    new "Un nudo de pavor me oprime el pecho."

    old "{sc=3}Hell, a stranger has been lying to me all day."
    new "{sc=3} Diablos, un desconocido me ha estado mintiendo todo el día."

    old "{sc=3}The soft sound of the cat purring sends a chill through me."
    new "{sc=3} El suave sonido del gato ronroneando me produce un escalofrío."

    old "My body tenses, and anxiety shoots through me like a wave."
    new "Mi cuerpo se tensa y la ansiedad me recorre como una ola."

    old "But I can’t seem to make myself move."
    new "Pero no consigo moverme."

    old "My pulse thrums in my ear, but all I can do is sit here."
    new "Siento el pulso retumbando en mi oído, pero lo único que puedo hacer es quedarme aquí sentada."

    old "My mind is racing through every possible scenario."
    new "Mi mente está repasando todos los escenarios posibles."

    old "Then, as if in a trance, I feel my hand slowly reach for my phone on the coffee table."
    new "Entonces, como en un trance, siento que mi mano se extiende lentamente hacia mi teléfono que está en la mesa de centro."

    old "{sc=1}What do I do-"
    new "{sc=1} ¿Qué hago?"

    old "{sc=2}{color=#f60808}Confront the man"
    new "{sc=2}{color=#f60808} Enfrenta al hombre"

    old "{sc=2}{color=#f60808}Play along"
    new "{sc=2}{color=#f60808} Juega conmigo"

    old "Maybe it was adrenaline."
    new "Quizás fue la adrenalina."

    old "Either way, I stood up."
    new "De cualquier manera, me puse de pie."

    old "My legs felt like they were made of glass, each step toward the bedroom door sharp and fragile."
    new "Sentía las piernas como si fueran de cristal; cada paso hacia la puerta del dormitorio era afilado y frágil."

    old "The air felt heavier near the threshold, like it was thick with something I wasn’t supposed to breathe."
    new "El aire se sentía más denso cerca del umbral, como si estuviera impregnado de algo que no debía respirar."

    old "When our eyes met..."
    new "Cuando nuestras miradas se cruzaron..."

    old "The easy laughter, the harmless nervousness from earlier... gone. Vanished like a breath on a mirror."
    new "La risa espontánea, el nerviosismo inofensivo de antes... desaparecieron. Se esfumaron como un vaho en un espejo."

    old "It didn’t just fall it shattered against you."
    new "No solo cayó, sino que se hizo añicos contra ti."

    old "What replaced it wasn’t even human."
    new "Lo que lo reemplazó ni siquiera era humano."

    old "But I know he didn’t intend for me to find out."
    new "Pero sé que no era su intención que yo lo descubriera."

    old "{sc=1}Then he smiled."
    new "{sc=1} Entonces sonrió."

    old "{sc=1}Not the one he had when he told me he loved me too."
    new "{sc=1} No es la que tenía cuando me dijo que él también me amaba."

    old "{sc=1}Something sinister and deprived of any ounce of humanity."
    new "{sc=1} Algo siniestro y desprovisto de cualquier pizca de humanidad."

    old "The logical part of my brain clawed its way back to the surface."
    new "La parte lógica de mi cerebro volvió a aflorar."

    old "My fingers wrapped around my phone, clumsy and cold."
    new "Mis dedos se aferraban al teléfono, torpes y fríos."

    old "My body just moved, driven by pure survival."
    new "Mi cuerpo simplemente se movió, impulsado por la pura supervivencia."

    old "I didn’t care if he heard. I didn’t care if he followed."
    new "Me daba igual si me oía. Me daba igual si me seguía."

    old "I flung the door open, almost tripping over the threshold, the hallway beyond stretching out like a lifeline."
    new "Abrí la puerta de golpe, casi tropezando con el umbral, y el pasillo se extendía más allá como un salvavidas."

    old "I kept looking back over my shoulder, my breath choked by the anxiety flooding every part of my body, half-expecting to see him standing there."
    new "No dejaba de mirar hacia atrás por encima del hombro, con la respiración entrecortada por la ansiedad que inundaba cada parte de mi cuerpo, esperando casi verlo allí de pie."

    old "But the door to my apartment remained closed."
    new "Pero la puerta de mi apartamento permaneció cerrada."

    old "I didn’t stop until I was out on the street, lungs burning, the night air cutting into my skin."
    new "No paré hasta que estuve en la calle, con los pulmones ardiendo y el aire nocturno calándome hasta los huesos."

    old "I don’t remember what I said."
    new "No recuerdo lo que dije."

    old "I don’t know what broke inside me, but something did."
    new "No sé qué se rompió dentro de mí, pero algo se rompió."

    old "Maybe it was the exhaustion."
    new "Quizás fue el cansancio."

    old "I closed my eyes, sucking in a shaky breath, and pushed the laptop screen shut."
    new "Cerré los ojos, respiré hondo con dificultad y cerré la pantalla del portátil."

    old "Or a misunderstanding."
    new "O un malentendido."

    old "Yeah. People do that."
    new "Sí. La gente hace eso."

    old "This was Silas."
    new "Este era Silas."

    old "I mean, look at him... He was playing with my cat."
    new "O sea, mírenlo... Estaba jugando con mi gato."

    old "We ordered food."
    new "Pedimos comida."

    old "I never asked who he was."
    new "Nunca pregunté quién era."

    old "But by the morning, he was gone."
    new "Pero por la mañana, ya se había marchado."

    old "Or maybe it’s just me who’s finally changed."
    new "O tal vez solo soy yo quien finalmente ha cambiado."

    old "I slow my steps without thinking, like my body still isn’t used to walking past this place without bracing for... Something."
    new "Disminuyo el ritmo de mis pasos sin pensarlo, como si mi cuerpo aún no estuviera acostumbrado a pasar por este lugar sin prepararse para... algo."

    old "For months, I avoided this street entirely."
    new "Durante meses, evité por completo esta calle."

    old "But the corner stayed empty. Just as empty as my inbox, where Silas’s old conversations used to sit."
    new "Pero la esquina permaneció vacía. Tan vacía como mi bandeja de entrada, donde solían estar las viejas conversaciones de Silas."

    old "No new messages, of course."
    new "Por supuesto, no hay mensajes nuevos."

    old "Not gone gone- Just gone from my life."
    new "No se ha ido del todo, simplemente se ha ido de mi vida."

    old "I felt so ashamed, so shallow..."
    new "Me sentí tan avergonzado, tan superficial..."

    old "And that was that."
    new "Y eso fue todo."

    old "I should have felt heartbroken."
    new "Debería haberme sentido desconsolado."

    old "So stupid that I let myself get so wrapped up in an idea of someone that I missed the warning signs flashing right in front of me."
    new "Qué estúpido fui al dejarme llevar tanto por la idea que tenía de alguien que no vi las señales de advertencia que tenía justo delante."

    old "Days turned into weeks, the fear turned into caution, and then eventually into something tolerable."
    new "Los días se convirtieron en semanas, el miedo en precaución y, finalmente, en algo tolerable."

    old "And somehow, I managed to catch up."
    new "Y de alguna manera, logré ponerme al día."

    old "I was gonna walk this road, head high."
    new "Iba a recorrer este camino con la cabeza bien alta."

    old "A small victory, but a victory nonetheless."
    new "Una pequeña victoria, pero una victoria al fin y al cabo."

    old "My thoughts drift, unfurling into something softer, something almost peaceful-"
    new "Mis pensamientos divagan, desplegándose en algo más suave, algo casi pacífico."

    old "I stop."
    new "Me detengo."

    old "{color=#f60808}For a heartbeat, my mind refuses to make sense of what I’m seeing."
    new "{color=#f60808} Por un instante, mi mente se niega a comprender lo que estoy viendo."

    old "{color=#FC8B8B}A man I’ve never met is walking toward me-"
    new "{color=#FC8B8B} Un hombre que nunca he visto está caminando hacia mí-"

    old "But the moment he smiles, something inside me sinks into a sinister and cold feeling."
    new "Pero en el momento en que sonríe, algo dentro de mí se sumerge en una sensación siniestra y fría."

    old "Before I can step back, before I can even raise a hand in protest, he closes the distance and wraps his arms around me."
    new "Antes de que pudiera retroceder, antes incluso de que pudiera levantar una mano en señal de protesta, él acortó la distancia y me rodeó con sus brazos."

    old "Before I can step back, before I can even raise a hand in protest, he closes the distance and, with a quick hand, plays with my hair."
    new "Antes de que pueda retroceder, antes incluso de que pueda levantar una mano en señal de protesta, acorta la distancia y, con un movimiento rápido de la mano, juega con mi cabello."

    old "I can’t breathe."
    new "No puedo respirar."

    old "The sound crawls straight down my spine."
    new "El sonido me recorre la columna vertebral."

    old "The same voice."
    new "La misma voz."

    old "Despite all his effort in acting warm, his eyes are the same."
    new "A pesar de todos sus esfuerzos por mostrarse amable, sus ojos siguen siendo los mismos."

    old "The same eyes I saw in my doorway."
    new "Los mismos ojos que vi en la puerta de mi casa."

    old "I try to take a step back, but he matches it effortlessly, gliding forward like he’s moving with me rather than after me."
    new "Intento dar un paso atrás, pero él lo iguala sin esfuerzo, deslizándose hacia adelante como si se moviera conmigo en lugar de detrás de mí."

    old "My hands are shaking so violently I’m afraid he’ll notice."
    new "Me tiemblan tanto las manos que temo que se dé cuenta."

    old "My pulse thunders so loudly, I’m not sure if he can hear it."
    new "Mi pulso late tan fuerte que no estoy segura de si él puede oírlo."

    old "Still standing too close."
    new "Todavía estamos demasiado cerca."

    old "Tell him to back off, or you’ll scream"
    new "Dile que se aleje o gritarás."

    old "I manage, my voice barely holding together,"
    new "Lo consigo, mi voz apenas se mantiene firme,"

    old "He's happy as if I’ve just handed him his favorite toy."
    new "Está tan contento como si le acabara de dar su juguete favorito."

    old "His smile widens."
    new "Su sonrisa se ensancha."

    old "My voice comes out small, breathless."
    new "Mi voz sale débil, sin aliento."

    old "He taps a finger against his chin, pretending to think."
    new "Se lleva un dedo a la barbilla, fingiendo pensar."

    old "He grins wider, like we’re sharing an inside joke."
    new "Él sonríe aún más, como si compartiéramos una broma interna."

    old "A chill slides down my spine."
    new "Un escalofrío me recorre la espalda."

    old "{color=#f60808}Follow him"
    new "{color=#f60808} Síguelo"

    old "{sc=1}Desperately, I try to get away, but he's stronger."
    new "{sc=1} Desesperadamente, intento escapar, pero él es más fuerte."

    old "He walks right past the tables near the entrance and chooses a booth tucked far in the back."
    new "Pasa de largo las mesas cerca de la entrada y elige una cabina escondida al fondo."

    old "Out of sight."
    new "Fuera de la vista."

    old "I sit slowly, every muscle tight, the vinyl booth cold under my palms."
    new "Me siento lentamente, con todos los músculos tensos, la cabina de vinilo fría bajo mis palmas."

    old "Then the waitress arrives."
    new "Entonces llega la camarera."

    old "He leans his cheek into his hand, voice softening mischievously."
    new "Apoya la mejilla en la mano, y su voz se suaviza con un tono travieso."

    old "She giggles- Actually giggles like an idiot."
    new "Ella se ríe, literalmente se ríe como una idiota."

    old "He glances at me with a sly, amused glint."
    new "Me mira con una mirada pícara y divertida."

    old "She leaves with a bounce in her step."
    new "Se marcha con paso ligero y alegre."

    old "If anything, the question seems to please him."
    new "En todo caso, la pregunta parece complacerle."

    old "He says gently, as if explaining something to a child."
    new "Lo dice con suavidad, como si le explicara algo a un niño."

    old "Say nothing."
    new "No digas nada."

    old "Be honest."
    new "Sé honesto."

    old "That probably not his real name..."
    new "Probablemente ese no sea su nombre real..."

    old "He lifts the glass to his lips and takes a slow sip, as if he hasn’t just said something that makes my pulse spike painfully in my ears."
    new "Se lleva el vaso a los labios y da un sorbo lento, como si no acabara de decir algo que me acelera el pulso dolorosamente en los oídos."

    old "His gaze drifts over my face, lingering in a way that feels invasive, like he’s cataloguing every reaction."
    new "Su mirada recorre mi rostro, deteniéndose de una manera que resulta invasiva, como si estuviera catalogando cada una de mis reacciones."

    old "My hands tighten under the table, digging my nails into my palms, grounding myself in the sting."
    new "Aprieto las manos bajo la mesa, clavando las uñas en las palmas, anclándome en el escozor."

    old "He leans forward a little, lowering his voice-not enough that someone wouldn’t be able to hear us, but enough that it feels like he’s pulling me into something private."
    new "Se inclina un poco hacia adelante, bajando la voz; no lo suficiente como para que alguien no pueda oírnos, pero sí lo suficiente como para que sienta que me está llevando a algo privado."

    old "My throat tightens."
    new "Siento un nudo en la garganta."

    old "He continues, leaning back again, stretching his arms along the back of the booth like he owns the space."
    new "Continúa, recostándose de nuevo y estirando los brazos a lo largo del respaldo de la cabina como si fuera el dueño del lugar."

    old "He lets out a quiet, amused breath."
    new "Deja escapar un suspiro tranquilo y divertido."

    old "My heart pounds violently as I struggle to find my voice."
    new "Mi corazón late con fuerza mientras lucho por encontrar mi voz."

    old "The question slips out before I can stop it, heavy and fragile all at once."
    new "La pregunta se me escapa antes de poder detenerla, pesada y frágil a la vez."

    old "He leans forward again, elbows resting on the table now, his voice dropping into something dangerously calm."
    new "Se inclina hacia adelante de nuevo, apoyando los codos en la mesa, y su voz se torna peligrosamente tranquila."

    old "She beams at him."
    new "Ella le sonríe radiante."

    old "And she leaves again."
    new "Y se va de nuevo."

    old "My stomach churns."
    new "Tengo el estómago revuelto."

    old "Drink the smoothie"
    new "Bebe el batido"

    old "My hand shakes as I reach for the glass."
    new "Me tiembla la mano al intentar coger el vaso."

    old "I bring the straw to my lips and take a sip."
    new "Acerco la pajita a mis labios y doy un sorbo."

    old "He watches closely."
    new "Él observa atentamente."

    old "He doesn’t look away until I lower the glass."
    new "No aparta la mirada hasta que bajo el vaso."

    old "Refuse to take the smoothie"
    new "Rechazar el batido"

    old "I shake my head."
    new "Niego con la cabeza."

    old "His face twists immediately."
    new "Su rostro se contrae inmediatamente."

    old "He sets it down with a soft clink."
    new "Lo deja sobre la mesa con un suave tintineo."

    old "He wipes his mouth with the back of his hand."
    new "Se limpia la boca con el dorso de la mano."

    old "He looks back at me."
    new "Él me mira."

    old "Why me ?"
    new "¿Por qué yo?"

    old "The words leave my mouth before I can soften them."
    new "Las palabras salen de mi boca antes de que pueda suavizarlas."

    old "He pauses."
    new "Hace una pausa."

    old "He leans back in the booth, crossing his arms loosely, eyes drifting toward the ceiling as if he’s replaying an unremarkable memory."
    new "Se recuesta en la cabina, cruza los brazos con desgana y la mirada se dirige hacia el techo como si estuviera reviviendo un recuerdo insignificante."

    old "His gaze comes back to me."
    new "Su mirada vuelve a posarse en mí."

    old "The words hit harder than I expected."
    new "Las palabras me impactaron más de lo que esperaba."

    old "He tilts his head."
    new "Él inclina la cabeza."

    old "I swallow."
    new "Trago."

    old "I hate how this is the first thing I dared to say."
    new "Odio que esto sea lo primero que me atreví a decir."

    old "He takes a sip of his water."
    new "Toma un sorbo de agua."

    old "He watches my reaction closely."
    new "Él observa mi reacción con atención."

    old "The question burns on my tongue."
    new "La pregunta me quema la lengua."

    old "He stares at me for a second."
    new "Me mira fijamente por un segundo."

    old "Not loud."
    new "No es ruidoso."

    old "Genuinely amused."
    new "Me ha resultado muy divertido."

    old "My fingers dig into the edge of the table."
    new "Mis dedos se clavan en el borde de la mesa."

    old "He leans forward, eyes bright with something sharp."
    new "Se inclina hacia adelante, con los ojos brillantes de una mirada penetrante."

    old "My voice shakes."
    new "Me tiembla la voz."

    old "This time, he doesn’t smile right away."
    new "Esta vez, no sonríe de inmediato."

    old "My breath catches."
    new "Se me corta la respiración."

    old "He says it the way someone might talk about a vitamin deficiency."
    new "Lo dice como si hablara de una deficiencia vitamínica."

    old "His mouth curves into something resembling a grin."
    new "Su boca se curva formando algo parecido a una sonrisa."

    old "The word lands like a slap."
    new "La palabra cae como una bofetada."

    old "He chuckles."
    new "Él se ríe entre dientes."

    old "The question comes out trembling."
    new "La pregunta sale temblando."

    old "He frowns."
    new "Él frunce el ceño."

    old "There’s something almost like disappointment in his eyes."
    new "Hay algo parecido a la decepción en sus ojos."

    old "I stare at him, confused."
    new "Lo miro fijamente, confundida."

    old "His gaze drifts briefly, thoughtful."
    new "Su mirada se desvía brevemente, pensativa."

    old "My skin crawls."
    new "Se me eriza la piel."

    old "His lack of hesitation is shameless."
    new "Su falta de vacilación es descarada."

    old "My breath stutters."
    new "Mi respiración se entrecorta."

    old "He glances at his phone."
    new "Él echa un vistazo a su teléfono."

    old "He stands up smoothly, the vinyl seat creaking softly as he slides out of the booth."
    new "Se levanta con suavidad, y el asiento de vinilo cruje levemente al deslizarse fuera de la cabina."

    old "He pauses, then looks back at me."
    new "Hace una pausa y luego me mira."

    old "He turns fully now, waiting."
    new "Ahora se gira completamente, esperando."

    old "He stands there, waiting."
    new "Se queda allí, esperando."

    old "I don’t say a word."
    new "No digo ni una palabra."

    old "For a moment, something flickers across his face."
    new "Por un instante, algo cruza fugazmente su rostro."

    old "He nods once, more to himself than to me."
    new "Él asiente una vez, más para sí mismo que para mí."

    old "The bell above the door chimes softly as it closes behind him."
    new "La campanilla que hay sobre la puerta suena suavemente al cerrarse tras él."

    old "The words tear out of me before I can soften them."
    new "Las palabras me arrancan antes de que pueda suavizarlas."

    old "Satisfied."
    new "Satisfecho."

    old "He gives a small nod, like I’ve met an expectation."
    new "Él asiente levemente, como si yo hubiera cumplido con sus expectativas."

    old "My voice shakes despite my effort to keep it steady."
    new "Mi voz tiembla a pesar de mis esfuerzos por mantenerla firme."

    old "Slowly, he takes a step back toward me, studying my face with something quieter in his expression."
    new "Lentamente, da un paso atrás hacia mí, estudiando mi rostro con una expresión más serena."

    old "I lift my chin, forcing the words past the tight knot in my throat."
    new "Levanto la barbilla, forzando las palabras a salir del nudo que tengo en la garganta."

    old "He exhales through his nose, concerned."
    new "Exhala por la nariz, preocupado."

    old "He straightens, adjusting his jacket."
    new "Se endereza, ajustándose la chaqueta."

    old "And just like that-"
    new "Y así, de repente..."

    old "He doesn’t look back when he walks out of view."
    new "No mira hacia atrás cuando desaparece de la vista."

    old "A moment passes before I actually dare to get up."
    new "Transcurre un instante antes de que me atreva a levantarme."

    old "Choose your character's name"
    new "Elige el nombre de tu personaje"

    old "63018a"
    new "63018a"

    old "8A011E"
    new "8A011E"

    old "FC83D6"
    new "FC83D6"

    old "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"
    new "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"

    old "Silas"
    new "Silas"

    old "Sillas"
    new "Sillas"

    old "Shuna"
    new "Shuna"

    old "applepi59"
    new "applepi59"

    old "es"
    new "es"

