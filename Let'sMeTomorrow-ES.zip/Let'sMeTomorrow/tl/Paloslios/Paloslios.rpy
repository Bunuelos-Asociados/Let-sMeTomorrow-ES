


    ####
    ##                                      ##
    ##  F95Zone Paloslios Renpy Translator  ##
    ##     https://ko-fi.com/paloslios      ##
    ##                                      ##
    ####



# game/atl_text_tag.rpy:1
translate Paloslios def8b2da:

    # "ATL Text Tags Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"
    "Etiquetas de texto ATL Módulo Ren'Py 2021 Daniel Westfall <SoDaRa2595@gmail.com>"

# game/atl_text_tag.rpy:1
translate Paloslios bcfb2ad4:

    # "http://twitter.com/sodara9 I'd appreciate being given credit if you do end up using it! :D Would really make my day to know I helped some people out! Really hope this can help the community create some really neat ways to spice up their dialogue! http://opensource.org/licenses/mit-license.php Forum Post: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags"
    "http://twitter.com/sodara9 ¡Apreciaría que me den crédito si terminas usándolo! :D ¡Realmente me alegraría el día saber que ayudé a algunas personas! ¡Realmente espero que esto pueda ayudar a la comunidad a crear formas realmente interesantes de darle vida a su diálogo! http://opensource.org/licenses/mit-license.php Publicación en el foro: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags"

# game/kinetic_text_tags.rpy:1
translate Paloslios 6c0c3176:

    # "Kinetic Text Tags Ren'Py Module 2021 Daniel Westfall <SoDaRa2595@gmail.com>"
    "Etiquetas de texto cinético Módulo Ren'Py 2021 Daniel Westfall <SoDaRa2595@gmail.com>"

# game/kinetic_text_tags.rpy:1
translate Paloslios 8689f4cd:

    # "http://twitter.com/sodara9 I'd appreciate being given credit if you do end up using it! :D Would really make my day to know I helped some people out! Really hope this can help the community create some really neat ways to spice up their dialogue! http://opensource.org/licenses/mit-license.php Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags Forum Post: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b"
    "http://twitter.com/sodara9 ¡Apreciaría que me den crédito si terminas usándolo! :D ¡Realmente me alegraría el día saber que ayudé a algunas personas! ¡Realmente espero que esto pueda ayudar a la comunidad a crear formas realmente interesantes de darle vida a su diálogo! http://opensource.org/licenses/mit-license.php Github: https://github.com/SoDaRa/Kinetic-Text-Tags itch.io: https://wattson.itch.io/kinetic-text-tags Publicación en el foro: https://lemmasoft.renai.us/forums/viewtopic.php?f=51&t=60527&sid=75b4eb1aa5212a33cbfe9b0354e5376b"

# game/script.rpy:41
translate Paloslios start_e70c10d5:

    # centered "This is an updated version of a game originaly made in 24h."
    centered "Esta es una versión actualizada de un juego creado originalmente en 24 horas."

# game/script.rpy:42
translate Paloslios start_8f094f22:

    # centered "Any resemblance to actual events, or persons is coincidental."
    centered "Cualquier parecido con hechos o personas reales es coincidencia."

# game/script.rpy:43
translate Paloslios start_cf1f1000:

    # centered "Also remember, {atl=#,#,fade_in_text~2.0}{color=#9b1169}{i}stranger danger{/color=#9b1169}."
    centered "Recuerde también, {atl=#,#,fade_in_text~2.0}{color=#9b1169}{i}peligro extraño{/color=#9b1169}."

# game/script.rpy:53
translate Paloslios name_132d27f9:

    # "You need a name."
    "Necesitas un nombre."

# game/script.rpy:56
translate Paloslios name_5e43bd88:

    # centered "{b}{color=#ffffff}No."
    centered "{b}{color=#ffffff}No."

# game/script.rpy:57
translate Paloslios name_17c2d4b0:

    # centered "This one is taken :)"
    centered "Éste está tomado :)"

# game/script.rpy:61
translate Paloslios name_d41e454a:

    # centered "Omg hi ! Either you're Silas number 1 fan or someone sharing the same name."
    centered "¡Dios mío, hola! O eres el fan número uno de Silas o alguien que comparte el mismo nombre."

# game/script.rpy:62
translate Paloslios name_ad9d7725:

    # centered "Regardless have a fun time playing."
    centered "Independientemente, diviértete jugando."

# game/script.rpy:63
translate Paloslios name_c35a5ba3:

    # centered "If you are the Silas number one fan, quick note."
    centered "Si eres el fanático número uno de Silas, nota rápida."

# game/script.rpy:64
translate Paloslios name_277ed89a:

    # centered "Thank you for all your kind words, you motivated me to make this update."
    centered "Gracias por todas tus amables palabras, me motivaste a realizar esta actualización."

# game/script.rpy:65
translate Paloslios name_6a4bfc50:

    # centered "May it meet your expectation !"
    centered "¡Que cumpla con sus expectativas!"

# game/script.rpy:66
translate Paloslios name_6dcf988e:

    # centered "Tons of love to you."
    centered "Toneladas de amor para ti."

# game/script.rpy:67
translate Paloslios name_b24b6350:

    # centered "Signed, dreamty :}"
    centered "Firmado, soñador :}"

# game/script.rpy:70
translate Paloslios name_22ed9814:

    # centered "Thank you."
    centered "Gracias."

# game/script.rpy:71
translate Paloslios name_d0c19b0d:

    # centered "Enjoy the game."
    centered "Disfruta el juego."

# game/script.rpy:77
translate Paloslios eha_d10a21b4:

    # "The street was busy today. Too busy."
    "La calle estaba ocupada hoy. Demasiado ocupado."

# game/script.rpy:78
translate Paloslios eha_1240ca52:

    # "I stand by the bookstore, fidgeting with the strap of my bag."
    "Estoy junto a la librería, jugueteando con la correa de mi bolso."

# game/script.rpy:79
translate Paloslios eha_5e7d6681:

    # "Late afternoon light spills across the pavement, catching on metal railings and shop windows."
    "La luz del final de la tarde se derrama sobre la acera, incidiendo en las barandillas de metal y los escaparates."

# game/script.rpy:80
translate Paloslios eha_df95483b:

    # "People blur past me, some in pairs, others alone, faces half-lit by the glow of their phones."
    "La gente pasa a mi lado, algunos en parejas, otros solos, con los rostros medio iluminados por el brillo de sus teléfonos."

# game/script.rpy:81
translate Paloslios eha_825dc2d2:

    # "I check mine for the fourth time in a minute... maybe fifth ?"
    "Reviso el mío por cuarta vez en un minuto... ¿tal vez la quinta?"

# game/script.rpy:82
translate Paloslios eha_2277bc9f:

    # "The last message from this morning stares back at me."
    "El último mensaje de esta mañana me devuelve la mirada."

# game/script.rpy:83
translate Paloslios eha_c058dbbd:

    # "{color=#d3239b}{b}Silas{/b}: {i}See you at 5 ! Can’t wait."
    "{color=#d3239b}{b}Silas{/b}: {i}¡Nos vemos a las 5! No puedo esperar."

# game/script.rpy:84
translate Paloslios eha_926dfaec:

    # "My stomach flips."
    "Mi estómago da un vuelco."

# game/script.rpy:85
translate Paloslios eha_05e0e4ee:

    # "I shouldn’t be this nervous. It’s just Silas."
    "No debería estar tan nervioso. Es sólo Silas."

# game/script.rpy:86
translate Paloslios eha_c9170268:

    # "The same Silas who sends me dumb memes at night, complains about his job and listens when I spiral about my own crap."
    "El mismo Silas que me envía memes tontos por las noches, se queja de su trabajo y escucha cuando hablo de mis propias tonterías."

# game/script.rpy:87
translate Paloslios eha_d539b3de:

    # "The one who confessed, not too long ago, that he hated how he looked in photos, and how he never showed his face online because of it."
    "El que confesó, no hace mucho, que odiaba cómo se veía en las fotos y que nunca mostraba su rostro en línea por eso."

# game/script.rpy:88
translate Paloslios eha_64beb952:

    # "I knew what his hair looked like, though."
    "Aunque sabía cómo era su cabello."

# game/script.rpy:89
translate Paloslios eha_c2a0bc0e:

    # "They were freshly dyed in pale blond, he sent me a picture of it last week, his face hidden behind his phone."
    "Estaban recién teñidos de rubio pálido, me envió una foto la semana pasada, con el rostro escondido detrás de su teléfono."

# game/script.rpy:90
translate Paloslios eha_0924dbc3:

    # "He also told me how I could spot him."
    "También me dijo cómo podía localizarlo."

# game/script.rpy:91
translate Paloslios eha_5c04d2ce:

    # "He was supposed to wear an oversized purple hoodie and didn’t forget to joke about how it made him look like a giant eggplant."
    "Se suponía que debía usar una sudadera con capucha violeta de gran tamaño y no se olvidó de bromear acerca de cómo lo hacía parecer una berenjena gigante."

# game/script.rpy:93
translate Paloslios eha_e862dfa5:

    # "I take my eyes off of my screen to scan the crowd again, my fingers twitching against my phone."
    "Aparto los ojos de la pantalla para escanear a la multitud nuevamente, mis dedos se mueven contra mi teléfono."

# game/script.rpy:94
translate Paloslios eha_6b6475d6:

    # "We’d agreed to meet in front of the bookstore near his hotel."
    "Habíamos acordado encontrarnos frente a la librería cerca de su hotel."

# game/script.rpy:95
translate Paloslios eha_95ba365c:

    # "I thought it would be fine. Simple. Just two people meeting after talking online for so long."
    "Pensé que estaría bien. Simple. Solo dos personas que se encuentran después de hablar en línea durante tanto tiempo."

# game/script.rpy:96
translate Paloslios eha_e542eef2:

    # "But now, standing here, I’m not so sure anymore."
    "Pero ahora, aquí parada, ya no estoy tan segura."

# game/script.rpy:97
translate Paloslios eha_8742e945:

    # "Would I be able to find him ? And if I don’t, would he recognize me ?"
    "¿Podré encontrarlo? Y si no lo hago, ¿me reconocería?"

# game/script.rpy:99
translate Paloslios eha_ea6a324a:

    # "And as if my thoughts were perfectly timed, I spot him in the crowd."
    "Y como si mis pensamientos estuvieran perfectamente sincronizados, lo veo entre la multitud."

# game/script.rpy:100
translate Paloslios eha_81727ad4:

    # "A figure standing a little apart from the others, looking slightly lost, like he's searching for something... or in that case someone."
    "Una figura parada un poco separada de los demás, luciendo un poco perdida, como si estuviera buscando algo... o en ese caso alguien."

# game/script.rpy:101
translate Paloslios eha_421d35ee:

    # "A jolt of recognition hits me. I can’t see his face yet, but his blond hair... That must be him."
    "Me golpea una sacudida de reconocimiento. No puedo ver su rostro todavía, pero su cabello rubio... Debe ser él."

# game/script.rpy:103
translate Paloslios eha_f4e97bea:

    # "I take a long breath that doesn’t quite steady my heart and start walking toward him, feeling the distance between us shrink with every step I make."
    "Respiro profundamente y mi corazón no se estabiliza del todo y empiezo a caminar hacia él, sintiendo que la distancia entre nosotros se reduce con cada paso que doy."

# game/script.rpy:104
translate Paloslios eha_44619d86:

    # "He still doesn’t notice me until I’m nearly right in front of him."
    "Todavía no me nota hasta que estoy casi frente a él."

# game/script.rpy:106
translate Paloslios eha_a15d334c:

    # mc "Hey..."
    mc "Oye..."

# game/script.rpy:109
translate Paloslios eha_b36c6cb1:

    # "He turns, and our eyes meet."
    "Se gira y nuestras miradas se encuentran."

# game/script.rpy:110
translate Paloslios eha_5a068b6e:

    # "I freeze for a moment, searching his expression anxiously for any sign of the guy I had spent so long talking to online."
    "Me congelo por un momento, buscando ansiosamente en su expresión cualquier señal del chico con el que había pasado tanto tiempo hablando en línea."

# game/script.rpy:113
translate Paloslios eha_e3d4b685:

    # "He smiles, a little awkwardly, but it’s a smile that makes my chest tighten in a way I wasn’t prepared for."
    "Él sonríe, un poco torpemente, pero es una sonrisa que hace que mi pecho se apriete de una manera para la que no estaba preparada."

# game/script.rpy:115
translate Paloslios eha_8083b594:

    # mc "Silas... ?"
    mc "¿Silas...?"

# game/script.rpy:118
translate Paloslios eha_69885189:

    # voice silas_v1
    # s "Yeah, it’s me."
    voice silas_v1
    s "Sí, soy yo."

# game/script.rpy:121
translate Paloslios eha_1e31fd62:

    # "He laughs softly, almost nervously."
    "Se ríe suavemente, casi nerviosamente."

# game/script.rpy:122
translate Paloslios eha_40e581d2:

    # "I feel an odd sense of relief, but at the same time, something else flickers in my gut."
    "Siento una extraña sensación de alivio, pero al mismo tiempo, algo más parpadea en mis entrañas."

# game/script.rpy:123
translate Paloslios eha_0c5b6ead:

    # "It’s probably just the nerves of meeting someone you used to chat with online, in real life for the first time."
    "Probablemente sean solo los nervios de conocer por primera vez a alguien con quien solías chatear en línea, en la vida real."

# game/script.rpy:125
translate Paloslios eha_51651ad2:

    # mc "You look just like your online model !"
    mc "¡Te pareces a tu modelo en línea!"

# game/script.rpy:127
translate Paloslios eha_93bea9df:

    # "He looks down for a second, almost bashful."
    "Él mira hacia abajo por un segundo, casi tímido."

# game/script.rpy:131
translate Paloslios eha_2d4d440a:

    # voice silas_v2
    # s "You do too. {w}Uh, but you already knew that, right ?"
    voice silas_v2
    s "Tú también. {w}Uh, pero eso ya lo sabías, ¿verdad?"

# game/script.rpy:134
translate Paloslios eha_0beec58c:

    # "I laugh awkwardly. It all feels surreal."
    "Me río torpemente. Todo parece surrealista."

# game/script.rpy:135
translate Paloslios eha_55401d84:

    # "Maybe it’s the years of seeing him as an anime profile, but his face almost doesn't fit, not that I’m unhappy."
    "Tal vez sean los años de verlo como un perfil de anime, pero su cara casi no encaja, no es que esté infeliz."

# game/script.rpy:138
translate Paloslios eha_f4860d17:

    # "It was shallow to be reassured by his face, but I know that I would have loved him anyway."
    "Fue superficial sentirme tranquilizado por su rostro, pero sé que lo habría amado de todos modos."

# game/script.rpy:140
translate Paloslios eha_0a68422e:

    # "He shifts on his feet, then glances around, as if unsure where to start."
    "Se pone de pie y luego mira a su alrededor, como si no supiera por dónde empezar."

# game/script.rpy:143
translate Paloslios eha_3d5eba32:

    # voice silas_v3
    # s "Do you prefer if I call you by your name or by your pseudonym ?"
    voice silas_v3
    s "¿Prefieres que te llame por tu nombre o por tu seudónimo?"

# game/script.rpy:146
translate Paloslios eha_82d89fab:

    # mc "You can use [name] ! You made the effort to take a plane ticket to visit me. It wouldn’t be right to keep calling me by my username."
    mc "¡Puedes usar [name]! Hiciste el esfuerzo de tomar un boleto de avión para visitarme. No sería correcto seguir llamándome por mi nombre de usuario."

# game/script.rpy:150
translate Paloslios eha_8edecdd8:

    # voice silas_v4
    # s "Yeah, you’re right..."
    voice silas_v4
    s "Sí, tienes razón..."

# game/script.rpy:154
translate Paloslios eha_2fdcfdf4:

    # voice silas_v5
    # s "Hi [name] ! I’m really happy to see you !"
    voice silas_v5
    s "Hola [name]! ¡Estoy muy feliz de verte!"

# game/script.rpy:159
translate Paloslios eha_499b8b06:

    # voice silas_v6
    # s "Do you mind if I- uh..."
    voice silas_v6
    s "¿Te importa si yo... eh...?"

# game/script.rpy:161
translate Paloslios eha_eb23f81d:

    # "He hesitates for a second, then opens his arms to invite me into a hug."
    "Duda un segundo y luego abre los brazos para invitarme a abrazarme."

# game/script.rpy:162
translate Paloslios eha_b92a9de7:

    # "A simple, tentative gesture. Like he’s not sure if it’s okay"
    "Un gesto simple y vacilante. Como si no estuviera seguro de si está bien"

# game/script.rpy:165
translate Paloslios eha_2a4e55b7:

    # "What do I do ?"
    "¿Qué hago?"

# game/script.rpy:175
translate Paloslios hug_scene_d21df7d3:

    # "My heart stutters in my chest. God, I’ve pictured this moment so many times, how it might feel to actually hold him, to feel his real warmth instead of cold pixels."
    "Mi corazón tartamudea en mi pecho. Dios, me he imaginado este momento tantas veces, cómo se sentiría abrazarlo, sentir su calidez real en lugar de píxeles fríos."

# game/script.rpy:176
translate Paloslios hug_scene_e5ae6b06:

    # "I step in, wrapping my arms around him before I can overthink it."
    "Entro y lo rodeo con mis brazos antes de que pueda pensar demasiado en ello."

# game/script.rpy:177
translate Paloslios hug_scene_2c0913ea:

    # "He smells like cheap fabric softener and airport coffee. His hoodie is soft, swallowing him whole like he said it would."
    "Huele a suavizante barato y a café de aeropuerto. Su sudadera con capucha es suave y lo traga entero como dijo que lo haría."

# game/script.rpy:179
translate Paloslios hug_scene_63305204:

    # "He lets out a tiny breath, almost a laugh, as his arms close around me. Not too tight, just enough to make me feel great."
    "Deja escapar un pequeño suspiro, casi una risa, mientras sus brazos se cierran alrededor de mí. No demasiado apretado, sólo lo suficiente para hacerme sentir genial."

# game/script.rpy:180
translate Paloslios hug_scene_54bab2e0:

    # "The kind of hug you fall into."
    "El tipo de abrazo en el que caes."

# game/script.rpy:182
translate Paloslios hug_scene_1cddb806:

    # "I could stay like this forever. Or at least, longer than what’s probably socially acceptable for a first meeting."
    "Podría quedarme así para siempre. O al menos, más tiempo del que probablemente sea socialmente aceptable para una primera reunión."

# game/script.rpy:183
translate Paloslios hug_scene_86ec154b:

    # "When we pull apart, I notice a flush on his cheeks."
    "Cuando nos separamos, noto un sonrojo en sus mejillas."

# game/script.rpy:184
translate Paloslios hug_scene_1d0e2e68:

    # "I clear my throat, desperate to cover up how warm my face feels."
    "Me aclaro la garganta, desesperada por ocultar el calor que siento en la cara."

# game/script.rpy:190
translate Paloslios no_hug_scene_b0e1cadc:

    # "My heart skips, catching somewhere between my ribs."
    "Mi corazón da un vuelco y se queda atrapado en algún lugar entre mis costillas."

# game/script.rpy:191
translate Paloslios no_hug_scene_8001f785:

    # "God, I really want to hug him, I really do. But the knot of nerves in my stomach wins out."
    "Dios, tengo muchas ganas de abrazarlo, de verdad. Pero el nudo de nervios en mi estómago gana."

# game/script.rpy:192
translate Paloslios no_hug_scene_d04f93de:

    # "I offer a sheepish smile instead, tucking my hands into the pockets of my jacket."
    "En cambio, ofrezco una sonrisa tímida y meto las manos en los bolsillos de mi chaqueta."

# game/script.rpy:194
translate Paloslios no_hug_scene_73a795b3:

    # mc "Sorry, I’m... not great with hugs."
    mc "Lo siento, no soy... bueno con los abrazos."

# game/script.rpy:196
translate Paloslios no_hug_scene_9e0747dc:

    # "His arms drop immediately, and for a second something flickers across his face."
    "Sus brazos caen inmediatamente y por un segundo algo parpadea en su rostro."

# game/script.rpy:197
translate Paloslios no_hug_scene_eec41130:

    # "It didn’t seem like he was hurt by my answer, it was a more surprised expression. But it was gone in an instant, replaced by an easy, understanding grin."
    "No parecía que mi respuesta lo lastimara, era una expresión más de sorpresa. Pero desapareció en un instante, reemplazada por una sonrisa fácil y comprensiva."

# game/script.rpy:200
translate Paloslios no_hug_scene_e7881355:

    # voice silas_v7
    # s "No worries, I get that."
    voice silas_v7
    s "No te preocupes, lo entiendo."

# game/script.rpy:203
translate Paloslios no_hug_scene_5dda23d9:

    # "It shouldn’t make me this flustered, but it does. I glance down, fiddling with the strap of my bag once again."
    "No debería ponerme tan nervioso, pero lo hace. Miro hacia abajo, jugueteando una vez más con la correa de mi bolso."

# game/script.rpy:209
translate Paloslios bookstore_smalltalk_a1ea0fc1:

    # mc "You’re taller than I thought you’d be."
    mc "Eres más alto de lo que pensé que serías."

# game/script.rpy:210
translate Paloslios bookstore_smalltalk_20978746:

    # "He laughs, a sound so much better in person than it ever was through voice messages."
    "Se ríe, un sonido mucho mejor en persona que a través de mensajes de voz."

# game/script.rpy:212
translate Paloslios bookstore_smalltalk_fdf25121:

    # voice silas_v8
    # s "I get that a lot !"
    voice silas_v8
    s "¡Lo entiendo mucho!"

# game/script.rpy:215
translate Paloslios bookstore_smalltalk_5112d928:

    # "He shifts his weight, glancing around, then back at me."
    "Cambia su peso, mira a su alrededor y luego vuelve a mirarme."

# game/script.rpy:219
translate Paloslios bookstore_smalltalk_38e39444:

    # voice silas_v9
    # s "I should probably apologize in advance if I act a little weird. Long flight, weird sleep, adrenaline, nerves... all that."
    voice silas_v9
    s "Probablemente debería disculparme de antemano si actúo un poco raro. Largo vuelo, sueño raro, adrenalina, nervios... todo eso."

# game/script.rpy:222
translate Paloslios bookstore_smalltalk_da90ef6d:

    # mc "It’s fine. Honestly, I’m just really glad you’re here."
    mc "Está bien. Sinceramente, me alegro mucho de que estés aquí."

# game/script.rpy:226
translate Paloslios bookstore_smalltalk_a23ce65b:

    # "His smile softens at that. And for a second, it feels perfect. Like this was always meant to happen."
    "Su sonrisa se suaviza ante eso. Y por un segundo se siente perfecto. Como si esto siempre hubiera tenido que suceder."

# game/script.rpy:227
translate Paloslios bookstore_smalltalk_9a4594a2:

    # "I glance toward the bookstore window, catching the reflection of us standing together in the glass."
    "Miro hacia el escaparate de la librería y veo el reflejo de nosotros parados juntos en el cristal."

# game/script.rpy:229
translate Paloslios bookstore_smalltalk_c1ec5640:

    # mc "Wanna check out the store ? The inside looks like something out of a vampire movie."
    mc "¿Quieres visitar la tienda? El interior parece sacado de una película de vampiros."

# game/script.rpy:231
translate Paloslios bookstore_smalltalk_6f8b30f2:

    # "His face lights up."
    "Su rostro se ilumina."

# game/script.rpy:234
translate Paloslios bookstore_smalltalk_aaf69470:

    # voice silas_v10
    # s "Hell yeah ! Seems cool, lead the way."
    voice silas_v10
    s "¡Diablos, sí! Parece genial, abre el camino."

# game/script.rpy:241
translate Paloslios bookstore_smalltalk_14435271:

    # "We’re already deep in the narrow aisles of the bookstore, the dusty scent of old pages thick in the air."
    "Ya estamos en lo profundo de los estrechos pasillos de la librería, el olor polvoriento de páginas viejas flota en el aire."

# game/script.rpy:242
translate Paloslios bookstore_smalltalk_de5fdcb0:

    # "The two of us have been quietly sifting through the shelves, peeking at those retail overstock copies with half-torn stickers and faded covers, trying to spot anything decent for cheap."
    "Los dos hemos estado revisando silenciosamente los estantes, echando un vistazo a esas copias excedentes con pegatinas medio rotas y cubiertas descoloridas, tratando de encontrar algo decente y barato."

# game/script.rpy:244
translate Paloslios bookstore_smalltalk_5b5e8020:

    # "Silas crouches down by the lower shelf to pull out a paperback with a creased spine and a slightly battered cover."
    "Silas se agacha junto al estante inferior para sacar un libro de bolsillo con el lomo arrugado y la cubierta ligeramente estropeada."

# game/script.rpy:245
translate Paloslios bookstore_smalltalk_36554d57:

    # "His eyes brighten a little as he holds it up."
    "Sus ojos se iluminan un poco mientras lo sostiene en alto."

# game/script.rpy:248
translate Paloslios bookstore_smalltalk_6dc0ab6f:

    # voice silas_v11
    # s "Hey, have you read this one ?"
    voice silas_v11
    s "Oye, ¿has leído este?"

# game/script.rpy:251
translate Paloslios bookstore_smalltalk_18dc23c8:

    # "I glance over and immediately laugh."
    "Miro e inmediatamente me río."

# game/script.rpy:253
translate Paloslios bookstore_smalltalk_86bc2cc4:

    # mc "Seriously ?"
    mc "En serio ?"

# game/script.rpy:257
translate Paloslios bookstore_smalltalk_68cd4114:

    # voice silas_v12
    # s "What ?"
    voice silas_v12
    s "Qué ?"

# game/script.rpy:260
translate Paloslios bookstore_smalltalk_6bc8799d:

    # mc "Silas, I made you put that on your to-read list, like, six months ago !"
    mc "Silas, ¡te obligué a poner eso en tu lista de lecturas pendientes hace como seis meses!"

# game/script.rpy:261
translate Paloslios bookstore_smalltalk_a8ec60aa:

    # mc "We had a whole conversation about it because I was obsessed and you said I was being dramatic."
    mc "Tuvimos toda una conversación al respecto porque estaba obsesionado y dijiste que estaba siendo dramático."

# game/script.rpy:263
translate Paloslios bookstore_smalltalk_8a0c0b87:

    # "He blinks, then grins, a little sheepishly."
    "Parpadea y luego sonríe, un poco tímidamente."

# game/script.rpy:267
translate Paloslios bookstore_smalltalk_f584319c:

    # voice silas_v13
    # s "Ohhh... So that’s why it looked familiar."
    voice silas_v13
    s "Ohhh... Entonces por eso me parecía familiar."

# game/script.rpy:270
translate Paloslios bookstore_smalltalk_c2d9cef1:

    # mc "I suppose you forgot about it and never read it then ?"
    mc "¿Supongo que lo olvidaste y nunca lo leíste?"

# game/script.rpy:274
translate Paloslios bookstore_smalltalk_bc80c3b1:

    # voice silas_v14
    # s "Euh... What if I didn’t ?"
    voice silas_v14
    s "Eh... ¿Y si no lo hiciera?"

# game/script.rpy:277
translate Paloslios bookstore_smalltalk_e09365f8:

    # mc "I can’t believe you ! I’m never rambling about books with you again."
    mc "¡No puedo creerte! Nunca volveré a divagar sobre libros contigo."

# game/script.rpy:281
translate Paloslios bookstore_smalltalk_c0b784d3:

    # voice silas_v15
    # s "Oh please do, I find it cute."
    voice silas_v15
    s "Oh, por favor, lo encuentro lindo."

# game/script.rpy:284
translate Paloslios bookstore_smalltalk_803c4ece:

    # mc "Sweet talker..."
    mc "Dulce conversador..."

# game/script.rpy:285
translate Paloslios bookstore_smalltalk_501b2b69:

    # mc "Promise me you’ll read this one at least ? It’s really good."
    mc "¿Prométeme que leerás este al menos? Es realmente bueno."

# game/script.rpy:289
translate Paloslios bookstore_smalltalk_e4b6e53a:

    # voice silas_v16
    # s "Sure, I can even buy it now so I have an excuse to read it on my flight back."
    voice silas_v16
    s "Claro, incluso puedo comprarlo ahora para tener una excusa para leerlo en mi vuelo de regreso."

# game/script.rpy:292
translate Paloslios bookstore_smalltalk_739b7c96:

    # "I watch him flip it over to check the back."
    "Lo veo darle la vuelta para revisar la parte de atrás."

# game/script.rpy:293
translate Paloslios bookstore_smalltalk_44a312e1:

    # "I’m still grinning like an idiot because... God, he’s actually here hanging out at the bookstore with me !"
    "Todavía estoy sonriendo como un idiota porque… ¡Dios, en realidad está aquí en la librería conmigo!"

# game/script.rpy:294
translate Paloslios bookstore_smalltalk_18030c57:

    # "I was still having a hard time acknowledging that it was real."
    "Todavía me costaba reconocer que era real."

# game/script.rpy:298
translate Paloslios bookstore_smalltalk_74c05161:

    # voice silas_v22
    # s "Alright, I'll take it. It’s still in good condition."
    voice silas_v22
    s "Muy bien, lo aceptaré. Todavía está en buenas condiciones."

# game/script.rpy:301
translate Paloslios bookstore_smalltalk_dedd218d:

    # mc "Yay ! I want a review when you’re done."
    mc "Hurra ! Quiero una reseña cuando hayas terminado."

# game/script.rpy:303
translate Paloslios bookstore_smalltalk_107b5d4a:

    # voice silas_v23
    # s "I won’t forget about it, I promise [name] !"
    voice silas_v23
    s "¡No lo olvidaré, lo prometo [name]!"

# game/script.rpy:306
translate Paloslios bookstore_smalltalk_6d72e4b4:

    # "I decide to tease, nudging him lightly with my shoulder."
    "Decido bromear, empujándolo ligeramente con mi hombro."

# game/script.rpy:308
translate Paloslios bookstore_smalltalk_71c64360:

    # mc "Though I have to ask. Are you sure you’ll have space for it ?"
    mc "Aunque tengo que preguntar. ¿Estás seguro de que tendrás espacio para ello?"

# game/script.rpy:312
translate Paloslios bookstore_smalltalk_44658c5c:

    # voice silas_uh
    # s "Huh ?"
    voice silas_uh
    s "Eh ?"

# game/script.rpy:315
translate Paloslios bookstore_smalltalk_0da9a2eb:

    # mc "You showed me how tiny your suitcase was. Like, it’s criminally small for a trip this long."
    mc "Me mostraste lo pequeña que era tu maleta. Es criminalmente pequeño para un viaje tan largo."

# game/script.rpy:317
translate Paloslios bookstore_smalltalk_b7febb20:

    # "He snorts a laugh, closing the book and holding it up like a prize."
    "Él suelta una carcajada, cierra el libro y lo sostiene como un premio."

# game/script.rpy:321
translate Paloslios bookstore_smalltalk_7515af95:

    # voice silas_v17
    # s "Okay, fair. It’s definitely a clown suitcase but in the worst case, I’ll keep the book in my hands for the flight back."
    voice silas_v17
    s "Vale, justo. Definitivamente es una maleta de payaso, pero en el peor de los casos, mantendré el libro en mis manos para el vuelo de regreso."

# game/script.rpy:323
translate Paloslios bookstore_smalltalk_5c86ac94:

    # voice silas_v18
    voice silas_v18

# game/script.rpy:326
translate Paloslios bookstore_smalltalk_851fa33a:

    # s "That way I can pretend I'm so different from others, reading a book instead of always being on my phone like everyone else."
    s "De esa manera puedo fingir que soy muy diferente a los demás, leyendo un libro en lugar de estar siempre en mi teléfono como todos los demás."

# game/script.rpy:329
translate Paloslios bookstore_smalltalk_b8585b79:

    # mc "You are always on your phone !"
    mc "¡Siempre estás en tu teléfono!"

# game/script.rpy:330
translate Paloslios bookstore_smalltalk_ebcedc81:

    # voice silas_v20
    voice silas_v20

# game/script.rpy:333
translate Paloslios bookstore_smalltalk_d14bbadd:

    # s "Shhh l said pretend to be different, the people at the airport don’t have to know my real life !"
    s "Shhh, dije finge ser diferente, ¡la gente en el aeropuerto no tiene por qué conocer mi vida real!"

# game/script.rpy:336
translate Paloslios bookstore_smalltalk_cef4dbdc:

    # "He looks at me, his grin softening just a little."
    "Me mira y su sonrisa se suaviza un poco."

# game/script.rpy:340
translate Paloslios bookstore_smalltalk_82c10a54:

    # voice silas_v19
    # s "It’s a nice souvenir to have of our time together anyway."
    voice silas_v19
    s "De todos modos, es un bonito recuerdo de nuestro tiempo juntos."

# game/script.rpy:343
translate Paloslios bookstore_smalltalk_08d18fe9:

    # "And just like that, my stomach flutters again."
    "Y así, mi estómago se revuelve de nuevo."

# game/script.rpy:347
translate Paloslios bookstore_smalltalk_19e2f5e1:

    # "Since the moment I spot him in the crowd, it’s been a whirlwind of emotions I can hardly keep up with."
    "Desde el momento en que lo vi entre la multitud, ha sido un torbellino de emociones que apenas puedo seguir."

# game/script.rpy:349
translate Paloslios bookstore_smalltalk_21de10fc:

    # "Maybe I should take it as a sign and finally gather all my courage to tell him how I feel..."
    "Tal vez debería tomarlo como una señal y finalmente reunir todo mi coraje para decirle lo que siento..."

# game/script.rpy:351
translate Paloslios bookstore_smalltalk_f9e91aed:

    # mc "Then I hope you’ll like the book."
    mc "Entonces espero que te guste el libro."

# game/script.rpy:355
translate Paloslios bookstore_smalltalk_9ca48c86:

    # voice silas_v24
    # s "Come on ! If you liked it I'm sure I will too."
    voice silas_v24
    s "Vamos ! Si te ha gustado seguro que a mí también."

# game/script.rpy:358
translate Paloslios bookstore_smalltalk_86f9f30e:

    # voice silas_v21
    # s "I trust your taste in books."
    voice silas_v21
    s "Confío en tu gusto por los libros."

# game/script.rpy:364
translate Paloslios bookstore_smalltalk_d34c79a0:

    # "By the time we step back out onto the street, the late afternoon glow has slightly cooled down."
    "Cuando volvemos a salir a la calle, el resplandor del atardecer se ha enfriado ligeramente."

# game/script.rpy:366
translate Paloslios bookstore_smalltalk_29de40fc:

    # "Silas has the book tucked under one arm, his fingers tapping absently against the cover as he glances over at me."
    "Silas tiene el libro bajo el brazo y sus dedos tamborilean distraídamente contra la cubierta mientras me mira."

# game/script.rpy:370
translate Paloslios bookstore_smalltalk_6b6d3134:

    # voice silas_v25
    # s "Hey... it’s a bit early, but you wanna grab something to eat ?"
    voice silas_v25
    s "Oye... es un poco temprano, pero ¿quieres comer algo?"

# game/script.rpy:373
translate Paloslios bookstore_smalltalk_4fb6fc6c:

    # mc "I’m kinda starving."
    mc "Estoy un poco hambriento."

# game/script.rpy:377
translate Paloslios bookstore_smalltalk_2c26a747:

    # "He flashes me a hopeful grin."
    "Me lanza una sonrisa esperanzada."

# game/script.rpy:379
translate Paloslios bookstore_smalltalk_aed06f6f:

    # mc "Yeah, sure. Any place in mind ?"
    mc "Sí, claro. ¿Algún lugar en mente?"

# game/script.rpy:381
translate Paloslios bookstore_smalltalk_e5ae9a47:

    # "He hums low in his throat, squinting up the street like he’s weighing his options."
    "Tararea por lo bajo, entrecerrando los ojos hacia la calle como si estuviera sopesando sus opciones."

# game/script.rpy:385
translate Paloslios bookstore_smalltalk_d21cd55b:

    # voice silas_v26
    # s "What about milkshakes ?"
    voice silas_v26
    s "¿Qué pasa con los batidos?"

# game/script.rpy:388
translate Paloslios bookstore_smalltalk_d472122b:

    # mc "Sure that sounds good."
    mc "Seguro que suena bien."

# game/script.rpy:392
translate Paloslios bookstore_smalltalk_10d9164e:

    # voice silas_v27
    # s "Alrighty then, let’s go."
    voice silas_v27
    s "Muy bien entonces, vámonos."

# game/script.rpy:396
translate Paloslios bookstore_smalltalk_66150869:

    # "I blinked, surprised to see him start walking without checking his phone."
    "Parpadeé, sorprendida al verlo comenzar a caminar sin revisar su teléfono."

# game/script.rpy:398
translate Paloslios bookstore_smalltalk_4c1836f4:

    # "Silas has never been here, how would he know which way to go ? Even I didn’t know where the store was."
    "Silas nunca ha estado aquí, ¿cómo sabría qué camino tomar? Ni siquiera yo sabía dónde estaba la tienda."

# game/script.rpy:409
translate Paloslios ask_how_he_knows_201e1755:

    # mc "How do you even know where the shop is ? You haven’t checked your phone once."
    mc "¿Cómo sabes dónde está la tienda? No has revisado tu teléfono ni una vez."

# game/script.rpy:412
translate Paloslios ask_how_he_knows_a6c62983:

    # voice silas_v28
    # s "I checked it out this morning actually. Kinda craved something sweet after the flight. So I looked up spots near the hotel while waiting for my room key."
    voice silas_v28
    s "De hecho, lo comprobé esta mañana. Me apetecía algo dulce después del vuelo. Así que busqué lugares cerca del hotel mientras esperaba la llave de mi habitación."

# game/script.rpy:415
translate Paloslios ask_how_he_knows_6747e543:

    # mc "Lucky for us."
    mc "Por suerte para nosotros."

# game/script.rpy:416
translate Paloslios ask_how_he_knows_b5ac7619:

    # mc "I see it was all a ploy, you just wanted to go grab milkshakes !"
    mc "Veo que todo fue una estratagema, ¡solo querías ir a tomar batidos!"

# game/script.rpy:419
translate Paloslios ask_how_he_knows_afd50a9e:

    # voice silas_v29
    # s "Mayhaps."
    voice silas_v29
    s "Quizás."

# game/script.rpy:423
translate Paloslios ask_how_he_knows_082d23e8:

    # voice silas_v30
    # s "You would be surprised to know how good I am at plotting stuff just for a treat."
    voice silas_v30
    s "Te sorprendería saber lo bueno que soy tramando cosas sólo por gusto."

# game/script.rpy:425
translate Paloslios ask_how_he_knows_3ffd94b2:

    # mc "Oh you evil man... Don’t get a cavity if you go get sweets too much."
    mc "Oh, hombre malvado... No te salga una caries si vas a comprar demasiados dulces."

# game/script.rpy:431
translate Paloslios let_it_go_98faa5b0:

    # "I decided not to ask. Instead, I fall into step beside him, the sound of our shoes scraping the pavement in unison, mingling with the faint chatter of the street."
    "Decidí no preguntar. En lugar de eso, me pongo a su lado, el sonido de nuestros zapatos raspando el pavimento al unísono, mezclándose con el débil parloteo de la calle."

# game/script.rpy:438
translate Paloslios continue_walk_6cfb43d9:

    # "Silas glances down, then without saying a word, he casually holds his hand out, palm up between us, like it’s the most natural thing in the world."
    "Silas mira hacia abajo y luego, sin decir una palabra, extiende su mano casualmente, con la palma hacia arriba entre nosotros, como si fuera la cosa más natural del mundo."

# game/script.rpy:440
translate Paloslios continue_walk_5bab791c:

    # "My chest tightens as I slip my hand into his. His fingers are warm, calloused in a way I didn’t expect."
    "Mi pecho se aprieta cuando deslizo mi mano en la suya. Sus dedos están cálidos, callosos de una manera que no esperaba."

# game/script.rpy:442
translate Paloslios continue_walk_6a66865e:

    # "His hand gently squeezes mine. His eyes stay fixed straight ahead, never meeting my gaze, but the faint smile curling at the corner of his mouth spoke on his behalf."
    "Su mano aprieta suavemente la mía. Sus ojos permanecen fijos al frente, sin encontrar nunca mi mirada, pero la leve sonrisa que se curva en la comisura de su boca habló en su nombre."

# game/script.rpy:446
translate Paloslios continue_walk_d536f4de:

    # "I notice he’s walking a little slower than before. Not lagging, just... matching my pace."
    "Noto que camina un poco más lento que antes. No retrasarme, sólo... seguir mi ritmo."

# game/script.rpy:448
translate Paloslios continue_walk_ea757549:

    # "Careful, considerate. It’s subtle, but it makes my stomach do that stupid little flutter thing again, and neither of us says anything about it as we head down the street."
    "Cuidadoso, considerado. Es sutil, pero hace que mi estómago vuelva a hacer ese estúpido aleteo, y ninguno de nosotros dice nada al respecto mientras caminamos por la calle."

# game/script.rpy:454
translate Paloslios continue_walk_4474cdc2:

    # "The milkshake shop is small and bright, the kind of place that smells like syrup and sugar the second you step inside."
    "La tienda de batidos es pequeña y luminosa, el tipo de lugar que huele a almíbar y azúcar en cuanto entras."

# game/script.rpy:456
translate Paloslios continue_walk_c1b14d79:

    # "Neon signs buzz softly above pastel-colored booths, and sunlight spills lazily across the floor through the big front windows."
    "Los letreros de neón zumban suavemente sobre las cabinas de colores pastel y la luz del sol se derrama perezosamente por el suelo a través de las grandes ventanas delanteras."

# game/script.rpy:458
translate Paloslios continue_walk_f2c1ea06:

    # "I slip off my jacket and bag, then settle myself into the booth across from Silas."
    "Me quito la chaqueta y el bolso y luego me instalo en el reservado frente a Silas."

# game/script.rpy:460
translate Paloslios continue_walk_c9d5f695:

    # mc "Everything looks so good, not that expensive either."
    mc "Todo tiene muy buena pinta y tampoco es tan caro."

# game/script.rpy:463
translate Paloslios continue_walk_03b6942a:

    # voice silas_v31
    # s "This is a nice place ! I Might have to add it to my list of spots for future hangouts."
    voice silas_v31
    s "¡Éste es un lindo lugar! Quizás tenga que agregarlo a mi lista de lugares para futuras reuniones."

# game/script.rpy:466
translate Paloslios continue_walk_ecb57dd4:

    # mc "You have great taste Silas !"
    mc "¡Tienes muy buen gusto, Silas!"

# game/script.rpy:470
translate Paloslios continue_walk_239252a4:

    # "When I glance up, I catch Silas staring."
    "Cuando levanto la vista, veo a Silas mirándome."

# game/script.rpy:472
translate Paloslios continue_walk_9aee6ac4:

    # "His head tilted ever so slightly, eyes softening in a way I couldn’t have been prepared for."
    "Su cabeza se inclinó ligeramente y sus ojos se suavizaron de una manera para la que no podría haber estado preparada."

# game/script.rpy:476
translate Paloslios continue_walk_34504005:

    # "The second our gazes meet, his cheek flushes, startled by the fact that I caught him in the act."
    "En el momento en que nuestras miradas se encuentran, su mejilla se sonroja, sorprendido por el hecho de que lo pillé en el acto."

# game/script.rpy:478
translate Paloslios continue_walk_c0549b76:

    # "He quickly looks away while rubbing his neck like it could erase the heat."
    "Rápidamente aparta la mirada mientras se frota el cuello como si pudiera borrar el calor."

# game/script.rpy:482
translate Paloslios continue_walk_e1c49d8c:

    # voice silas_v32
    # s "Uh... yeah..."
    voice silas_v32
    s "Eh... sí..."

# game/script.rpy:487
translate Paloslios continue_walk_ac409162:

    # voice silas_v33
    # s "Order whatever you want."
    voice silas_v33
    s "Ordena lo que quieras."

# game/script.rpy:490
translate Paloslios continue_walk_85d6618f:

    # mc "You don’t have to—"
    mc "No tienes que—"

# game/script.rpy:494
translate Paloslios continue_walk_968f9de2:

    # voice silas_v34
    # s "I want to... Because it’s you."
    voice silas_v34
    s "Quiero... Porque eres tú."

# game/script.rpy:497
translate Paloslios continue_walk_157e51fe:

    # mc "That's sweet but I insist, please."
    mc "Que lindo pero insisto, por favor."

# game/script.rpy:501
translate Paloslios continue_walk_da0fba3e:

    # voice silas_v35
    # s "Hmm hmm ! I suggested the place, I’m paying. I’m not changing my mind, [name]."
    voice silas_v35
    s "Mmmmmmm! Sugerí el lugar, estoy pagando. No voy a cambiar de opinión, [name]."

# game/script.rpy:504
translate Paloslios continue_walk_d45df91c:

    # mc "Silas..."
    mc "Sila..."

# game/script.rpy:507
translate Paloslios continue_walk_b7ea4248:

    # voice silas_v36
    # s "Get whatever you want !"
    voice silas_v36
    s "¡Consigue lo que quieras!"

# game/script.rpy:510
translate Paloslios continue_walk_250dea24:

    # "I bite back a laugh and let him win this time around."
    "Contengo una risa y le dejo ganar esta vez."

# game/script.rpy:512
translate Paloslios continue_walk_6333e9b3:

    # "The waitress comes to our table."
    "La camarera se acerca a nuestra mesa."

# game/script.rpy:514
translate Paloslios continue_walk_d4e07fc0:

    # eh "So what would you like to order ?"
    eh "Entonces, ¿qué te gustaría pedir?"

# game/script.rpy:516
translate Paloslios continue_walk_c96a252c:

    # "I'll take...."
    "tomaré...."

# game/script.rpy:522
translate Paloslios continue_walk_9e1f7628:

    # mc "Strawberry for me please."
    mc "Fresa para mí por favor."

# game/script.rpy:524
translate Paloslios continue_walk_046eb6c1:

    # voice silas_v37
    # s "Same."
    voice silas_v37
    s "Mismo."

# game/script.rpy:526
translate Paloslios continue_walk_3d96bbaa:

    # mc "Oh now you’re imitating me ?"
    mc "Oh, ¿ahora me estás imitando?"

# game/script.rpy:527
translate Paloslios continue_walk_80500400:

    # mc "I just said you have good taste Silas !"
    mc "¡Acabo de decir que tienes buen gusto, Silas!"

# game/script.rpy:530
translate Paloslios continue_walk_694115ad:

    # voice silas_v38
    # s "What can I say, you’ve got good taste too."
    voice silas_v38
    s "Qué puedo decir, tú también tienes buen gusto."

# game/script.rpy:534
translate Paloslios continue_walk_8f6e39b1:

    # voice silas_v39
    # s "And what if I just wanted a strawberry flavored milkshake ? Maybe I’m not a copycat, I just like pink."
    voice silas_v39
    s "¿Y si solo quisiera un batido con sabor a fresa? Quizás no soy un imitador, simplemente me gusta el rosa."

# game/script.rpy:536
translate Paloslios continue_walk_bab30b27:

    # mc "I’m just surprised ! That's usually my thing !"
    mc "¡Simplemente estoy sorprendido! ¡Eso suele ser lo mío!"

# game/script.rpy:539
translate Paloslios continue_walk_94065dd4:

    # voice silas_v40
    # s "Well maybe I wanna try to become your thing too."
    voice silas_v40
    s "Bueno, tal vez yo también quiera intentar convertirme en lo tuyo."

# game/script.rpy:542
translate Paloslios continue_walk_fafcebdd:

    # "His tone is playful, clearly teasing me, but the warmth in his gaze makes my heart skip a beat."
    "Su tono es juguetón, claramente burlándose de mí, pero la calidez en su mirada hace que mi corazón dé un vuelco."

# game/script.rpy:544
translate Paloslios continue_walk_26b7e160:

    # "The milkshakes arrived faster than I expected. A tall glass, thick and pastel pink, with a generous swirl of whipped cream."
    "Los batidos llegaron más rápido de lo que esperaba. Un vaso alto, grueso y de color rosa pastel, con un generoso remolino de crema batida."

# game/script.rpy:549
translate Paloslios continue_walk_22d84e3e:

    # mc "I’ll go with chocolate please."
    mc "Iré con chocolate por favor."

# game/script.rpy:551
translate Paloslios continue_walk_fbadc1fe:

    # voice silas_v42
    # s "Good call. Make it two."
    voice silas_v42
    s "Buena decisión. Que sean dos."

# game/script.rpy:553
translate Paloslios continue_walk_e54888c5:

    # mc "Trying to match with me now ?"
    mc "¿Estás intentando emparejarte conmigo ahora?"

# game/script.rpy:556
translate Paloslios continue_walk_00390074:

    # voice silas_v43
    # s "Figured if we’re hanging out, we might as well get matching drinks. Maybe they’ll give us special straws"
    voice silas_v43
    s "Pensé que si salíamos, también podríamos tomar bebidas a juego. Quizás nos den pajitas especiales."

# game/script.rpy:558
translate Paloslios continue_walk_e84e1311:

    # voice silas_v44
    voice silas_v44

# game/script.rpy:561
translate Paloslios continue_walk_fbd6446d:

    # s "You know, like cringy couples on a date."
    s "Ya sabes, como parejas llorosas en una cita."

# game/script.rpy:562
translate Paloslios continue_walk_2e63981a:

    # mc "A-Ah a date ?!"
    mc "A-Ah una cita?!"

# game/script.rpy:563
translate Paloslios continue_walk_f0c1ed0f:

    # voice silas_v45
    voice silas_v45

# game/script.rpy:566
translate Paloslios continue_walk_cdaa73fb:

    # s "Oh I mean- we’re imitating people on a date ! Not that we..."
    s "Oh, quiero decir, ¡estamos imitando a la gente en una cita! No es que nosotros..."

# game/script.rpy:567
translate Paloslios continue_walk_e1554201:

    # s "..."
    s "..."

# game/script.rpy:568
translate Paloslios continue_walk_a3ef3305:

    # voice silas_v46
    voice silas_v46

# game/script.rpy:571
translate Paloslios continue_walk_6ed3f8a8:

    # s "Not that- We... Let’s change the... Euhm... The topic."
    s "No es que- Nosotros... Cambiemos el... Euhm... El tema."

# game/script.rpy:572
translate Paloslios continue_walk_863bccd4:

    # "It’s so dumb but so sweet at the same time. It makes my chest bloom in the best way."
    "Es tan tonto pero tan dulce al mismo tiempo. Hace que mi pecho florezca de la mejor manera."

# game/script.rpy:573
translate Paloslios continue_walk_f4a9eecd:

    # "Maybe I actually have a chance ?"
    "¿Quizás realmente tenga una oportunidad?"

# game/script.rpy:576
translate Paloslios continue_walk_a10a3178:

    # "The milkshakes arrived faster than I expected. A tall glass, brown with cherries on top."
    "Los batidos llegaron más rápido de lo que esperaba. Un vaso alto, de color marrón y con cerezas encima."

# game/script.rpy:581
translate Paloslios continue_walk_da7f0726:

    # mc "I think I’ll have vanilla please."
    mc "Creo que tomaré vainilla, por favor."

# game/script.rpy:583
translate Paloslios continue_walk_e1554201_1:

    # s "..."
    s "..."

# game/script.rpy:584
translate Paloslios continue_walk_598bb7f9:

    # "Silas hesitates, only to end up ordering the same flavor as mine."
    "Silas duda y acaba pidiendo el mismo sabor que el mío."

# game/script.rpy:587
translate Paloslios continue_walk_fdb64a18:

    # mc "Didn’t you say vanilla was the most basic flavor on earth last week ?"
    mc "¿No dijiste la semana pasada que la vainilla era el sabor más básico del mundo?"

# game/script.rpy:590
translate Paloslios continue_walk_c5477aad:

    # voice silas_v47
    voice silas_v47

# game/script.rpy:593
translate Paloslios continue_walk_6edb1700:

    # s "I did not–{w}Okay, maybe I did."
    s "No lo hice–{w}Está bien, tal vez lo hice."

# game/script.rpy:594
translate Paloslios continue_walk_ed502200:

    # voice silas_v48
    voice silas_v48

# game/script.rpy:597
translate Paloslios continue_walk_a2096259:

    # s "Guess I’ll be basic today. But you still like me~ Face it. You’re just as basic. {size=20}Deal with it."
    s "Supongo que hoy seré básico. Pero todavía te gusto ~ Acéptalo. Eres igual de básico. {size=20}Ocúpate de ello."

# game/script.rpy:598
translate Paloslios continue_walk_f37cbf29:

    # mc "Oh wow. Middle school wants it’s material back- Silas that was tragic."
    mc "Oh, vaya. La escuela secundaria quiere recuperar su material. Silas, eso fue trágico."

# game/script.rpy:599
translate Paloslios continue_walk_168300f4:

    # mc "I’ll still give you A for the effort."
    mc "Aún así te daré una A por el esfuerzo."

# game/script.rpy:600
translate Paloslios continue_walk_c448b624:

    # "I chuckle, shaking my head."
    "Me río entre dientes y sacudo la cabeza."

# game/script.rpy:603
translate Paloslios continue_walk_bede7e92:

    # voice silas_v49
    # s "You can’t say that when I managed to make you laugh !"
    voice silas_v49
    s "¡No puedes decir eso cuando logré hacerte reír!"

# game/script.rpy:605
translate Paloslios continue_walk_ce84c241:

    # mc "No you didn’t !"
    mc "¡No, no lo hiciste!"

# game/script.rpy:606
translate Paloslios continue_walk_adf4fe2c:

    # voice silas_v50
    voice silas_v50

# game/script.rpy:609
translate Paloslios continue_walk_b674a67d:

    # s "Yes I did !"
    s "¡Sí, lo hice!"

# game/script.rpy:610
translate Paloslios continue_walk_10a42e8b:

    # mc "Did not !"
    mc "¡No lo hice!"

# game/script.rpy:611
translate Paloslios continue_walk_ef41ede8:

    # voice silas_v51
    voice silas_v51

# game/script.rpy:614
translate Paloslios continue_walk_b3851da1:

    # s "So did !"
    s "¡También!"

# game/script.rpy:615
translate Paloslios continue_walk_7ab1e30d:

    # mc "You’re just saying lies !"
    mc "¡Solo estás diciendo mentiras!"

# game/script.rpy:618
translate Paloslios continue_walk_9740a2ad:

    # voice silas_v52
    # s "Says the basic vanilla liar."
    voice silas_v52
    s "Dice el mentiroso básico de vainilla."

# game/script.rpy:620
translate Paloslios continue_walk_18c81b99:

    # mc "Pfffff... you’re stupid !"
    mc "Pffff... eres estúpido!"

# game/script.rpy:621
translate Paloslios continue_walk_e931b318:

    # "And damn if that doesn’t make me melt a little."
    "Y maldita sea si eso no me hace derretirme un poco."

# game/script.rpy:623
translate Paloslios continue_walk_087e96b5:

    # "The milkshakes arrived faster than I expected. A tall glass, white and with a generous swirl of whipped cream."
    "Los batidos llegaron más rápido de lo que esperaba. Un vaso alto, blanco y con un generoso remolino de nata montada."

# game/script.rpy:627
translate Paloslios continue_walk_a6624119:

    # voice silas_v41
    # s "Here you go, this one is yours and this one is mine, although there isn’t really any difference... Hold on, I should get a ruler to check."
    voice silas_v41
    s "Aquí tienes, este es tuyo y este es mío, aunque realmente no hay ninguna diferencia... Espera, debería conseguir una regla para comprobarlo."

# game/script.rpy:630
translate Paloslios continue_walk_e726c774:

    # "I chuckle and thank him, fiddling with the straw."
    "Me río entre dientes y le agradezco, jugueteando con la pajita."

# game/script.rpy:632
translate Paloslios continue_walk_5428e453:

    # "A few minutes slips by as we let quiet linger, trading sparse and weightless words."
    "Pasan unos minutos mientras dejamos que el silencio persista, intercambiando palabras escasas e ingrávidas."

# game/script.rpy:635
translate Paloslios continue_walk_34f31882:

    # "Then, his phone vibrates against the table."
    "Entonces, su teléfono vibra contra la mesa."

# game/script.rpy:638
translate Paloslios continue_walk_93f31908:

    # "As Silas’ gaze drops to the screen, a frown appears instantly on his face. He stands up, scraping the chair loudly against the floor."
    "Cuando la mirada de Silas cae hacia la pantalla, un ceño aparece instantáneamente en su rostro. Se levanta, raspando ruidosamente la silla contra el suelo."

# game/script.rpy:642
translate Paloslios continue_walk_ec2ce5f1:

    # voice silas_v53
    # s "Uh- sorry, give me a second. I gotta take this."
    voice silas_v53
    s "Uh- lo siento, dame un segundo. Debo tomar esto."

# game/script.rpy:645
translate Paloslios continue_walk_32c8869d:

    # "He’s already moving before I can say anything."
    "Ya se está moviendo antes de que pueda decir algo."

# game/script.rpy:647
translate Paloslios continue_walk_9b0fb9ca:

    # "Seizing the moment when I’m sure he can no longer see me, I quickly get up from my seat."
    "Aprovechando el momento en el que estoy seguro de que ya no puede verme, me levanto rápidamente de mi asiento."

# game/script.rpy:649
translate Paloslios continue_walk_0d8deff4:

    # "I head over to the counter and ask to pay for both drinks in advance."
    "Me dirijo al mostrador y pido pagar ambas bebidas por adelantado."

# game/script.rpy:651
translate Paloslios continue_walk_582e582e:

    # "As I pocket the receipt, I notice him turn around."
    "Mientras me guardo el recibo en el bolsillo, noto que se da vuelta."

# game/script.rpy:653
translate Paloslios continue_walk_c71e7f13:

    # "His face drops."
    "Su rostro cae."

# game/script.rpy:657
translate Paloslios continue_walk_ab9686b5:

    # "It takes him barely a second to scan the cafe, eyes darting from table to table."
    "Apenas le lleva un segundo explorar el café, con los ojos recorriendo de mesa en mesa."

# game/script.rpy:659
translate Paloslios continue_walk_21fd1d47:

    # "His whole posture stiffens, shoulders rigid, jaw clenched."
    "Toda su postura se pone rígida, los hombros rígidos y la mandíbula apretada."

# game/script.rpy:661
translate Paloslios continue_walk_fb9058d1:

    # "Seeing him getting this anxious made me feel a stab of guilt."
    "Verlo ponerse tan ansioso me hizo sentir una punzada de culpa."

# game/script.rpy:663
translate Paloslios continue_walk_393e716a:

    # "I hurry toward him and reach out to tap his shoulder."
    "Me apresuro hacia él y extiendo la mano para tocarle el hombro."

# game/script.rpy:665
translate Paloslios continue_walk_669664cb:

    # mc "Hey."
    mc "Ey."

# game/script.rpy:668
translate Paloslios continue_walk_695f6fdb:

    # voice silas_v54
    # s "[name] !"
    voice silas_v54
    s "[name] !"

# game/script.rpy:671
translate Paloslios continue_walk_f2bd846f:

    # "He flinches slightly, then his expression breaks, all that tension unraveling like it never existed."
    "Se estremece levemente, luego su expresión se rompe, toda esa tensión se deshace como si nunca hubiera existido."

# game/script.rpy:675
translate Paloslios continue_walk_26abe219:

    # voice silas_v55
    # s "God..."
    voice silas_v55
    s "Dios..."

# game/script.rpy:678
translate Paloslios continue_walk_5b315904:

    # "He lets out a breathy laugh."
    "Él deja escapar una risa entrecortada."

# game/script.rpy:682
translate Paloslios continue_walk_1d45e454:

    # voice silas_v56
    # s "I, uh... sorry. I just thought you’d left the place."
    voice silas_v56
    s "Yo... lo siento. Sólo pensé que habías abandonado el lugar."

# game/script.rpy:685
translate Paloslios continue_walk_42a46b89:

    # mc "Wha- why would I do that ? We’re hanging out."
    mc "¿Por qué haría eso? Estamos saliendo."

# game/script.rpy:686
translate Paloslios continue_walk_f9d63968:

    # voice silas_v57
    # s "I thought I made things awkward and you escaped by the back door..."
    voice silas_v57
    s "Pensé que había hecho las cosas incómodas y escapaste por la puerta trasera..."

# game/script.rpy:689
translate Paloslios continue_walk_ba62e91f:

    # "I blink, surprised, then let out a nervous laugh."
    "Parpadeo, sorprendida, y luego dejo escapar una risa nerviosa."

# game/script.rpy:691
translate Paloslios continue_walk_766ae3ee:

    # mc "No, I’m having a good time, don’t worry."
    mc "No, lo estoy pasando bien, no te preocupes."

# game/script.rpy:695
translate Paloslios continue_walk_c9b8ccdc:

    # voice silas_v58
    # s "Okay, cool... Sorry, I... overthink sometimes."
    voice silas_v58
    s "Vale, genial... Lo siento, a veces... pienso demasiado."

# game/script.rpy:698
translate Paloslios continue_walk_6c0dbe6a:

    # mc "Yeah, I know, sorry..."
    mc "Sí, lo sé, lo siento..."

# game/script.rpy:701
translate Paloslios continue_walk_d9e56e7b:

    # "We head back to the table together."
    "Regresamos juntos a la mesa."

# game/script.rpy:703
translate Paloslios continue_walk_b4d4283f:

    # "The milkshakes have gone a little soft but it still tasted sweet when I finally took a sip."
    "Los batidos se han vuelto un poco blandos, pero aún sabían dulces cuando finalmente tomé un sorbo."

# game/script.rpy:705
translate Paloslios continue_walk_3984e7a9:

    # "The conversation picks up again, lighter this time."
    "La conversación se reanuda, esta vez más ligera."

# game/script.rpy:708
translate Paloslios continue_walk_fe5899f9:

    # "The cafe starts to empty out. Outside, the daylight is finally dimming."
    "El café comienza a vaciarse. Afuera, la luz del día finalmente está amainando."

# game/script.rpy:710
translate Paloslios continue_walk_28a4093c:

    # "I glance at Silas."
    "Miro a Silas."

# game/script.rpy:713
translate Paloslios continue_walk_4582d03c:

    # voice silas_v59
    # s "Are you okay ?"
    voice silas_v59
    s "Estás bien ?"

# game/script.rpy:716
translate Paloslios continue_walk_d4b4a08e:

    # "I hesitate, then shrug, trying to play it casual."
    "Dudo, luego me encojo de hombros, tratando de parecer casual."

# game/script.rpy:718
translate Paloslios continue_walk_984b0e3d:

    # mc "Yeah, just... kinda bummed it’s getting late, I guess."
    mc "Sí, solo... supongo que me desanima un poco que se esté haciendo tarde."

# game/script.rpy:720
translate Paloslios continue_walk_47a7c808:

    # "His expression softens immediately."
    "Su expresión se suaviza inmediatamente."

# game/script.rpy:724
translate Paloslios continue_walk_182ffd82:

    # voice silas_v60
    # s "Hey..."
    voice silas_v60
    s "Oye..."

# game/script.rpy:727
translate Paloslios continue_walk_0c8db6f0:

    # "He slightly leans forward, resting his elbows on the table."
    "Se inclina ligeramente hacia adelante, apoyando los codos sobre la mesa."

# game/script.rpy:730
translate Paloslios continue_walk_0e7e77f2:

    # voice silas_v61
    voice silas_v61

# game/script.rpy:733
translate Paloslios continue_walk_36ac46b1:

    # "I force a smile."
    "Fuerzo una sonrisa."

# game/script.rpy:734
translate Paloslios continue_walk_556af8cc:

    # "I let out a slow breath."
    "Dejé escapar un suspiro lento."

# game/script.rpy:736
translate Paloslios continue_walk_fce3b2f7:

    # mc "Yeah, I’d like that."
    mc "Sí, me gustaría eso."

# game/script.rpy:738
translate Paloslios continue_walk_0337ace7:

    # "Silas watches me for a second, then stands up, stretching."
    "Silas me mira durante un segundo, luego se levanta y se estira."

# game/script.rpy:742
translate Paloslios continue_walk_e6774a6e:

    # voice silas_v62
    # s "C’mon."
    voice silas_v62
    s "Vamos."

# game/script.rpy:744
translate Paloslios continue_walk_3a1717eb:

    # mc "What-"
    mc "¿Qué?"

# game/script.rpy:745
translate Paloslios continue_walk_9e870353:

    # voice silas_v63
    # s "We’re going."
    voice silas_v63
    s "Nos vamos."

# game/script.rpy:748
translate Paloslios continue_walk_a53abdf1:

    # mc "Where ?"
    mc "Dónde ?"

# game/script.rpy:752
translate Paloslios continue_walk_7776c61b:

    # voice silas_v64
    # s "Let’s walk back to the bookstore. It’s nice outside, we might as well take a stroll rather than just sitting here until they kick us out."
    voice silas_v64
    s "Volvamos a la librería. Afuera está lindo, mejor dar un paseo que quedarnos sentados aquí hasta que nos echen."

# game/script.rpy:754
translate Paloslios continue_walk_294b071d:

    # voice silas_v65
    # s "Also I want to spend more time with you, come on [name]."
    voice silas_v65
    s "También quiero pasar más tiempo contigo, vamos [name]."

# game/script.rpy:756
translate Paloslios continue_walk_0afb693b:

    # "I laugh, the knot in my chest loosening a little."
    "Me río y el nudo en mi pecho se afloja un poco."

# game/script.rpy:760
translate Paloslios continue_walk_fb8aaaf9:

    # "I grab my stuff, and together we slip back out into the fading evening light."
    "Agarro mis cosas y juntos volvemos a salir a la luz del atardecer."

# game/script.rpy:764
translate Paloslios continue_walk_2affcfdb:

    # "The streets settle into a hush, bustle of the day settling into something quieter."
    "Las calles se vuelven silenciosas, el bullicio del día se convierte en algo más tranquilo."

# game/script.rpy:765
translate Paloslios continue_walk_269fdebe:

    # "The kind of hour where everything feels a little softer, a little easier to say."
    "El tipo de hora en la que todo se siente un poco más suave, un poco más fácil de decir."

# game/script.rpy:766
translate Paloslios continue_walk_3a64abfb:

    # "Not that I’ll actually say it."
    "No es que realmente lo vaya a decir."

# game/script.rpy:767
translate Paloslios continue_walk_0cb4820a:

    # "Not yet."
    "Aún no."

# game/script.rpy:768
translate Paloslios continue_walk_c8375ce4:

    # "But I’ll walk beside him in silence for a little while longer."
    "Pero caminaré junto a él en silencio un rato más."

# game/script.rpy:772
translate Paloslios continue_walk_6e5db8f6:

    # "We made it back to the bookstore, but the place feels completely different now."
    "Regresamos a la librería, pero ahora el lugar se siente completamente diferente."

# game/script.rpy:773
translate Paloslios continue_walk_4eba740b:

    # "The glow of the streetlamps washes the storefront in a tired, yellow light."
    "El resplandor de las farolas baña el escaparate con una luz amarilla y cansada."

# game/script.rpy:774
translate Paloslios continue_walk_3044126a:

    # "The big display window is dark, a handwritten closed sign hung slightly crooked against the glass."
    "El gran escaparate está oscuro y un cartel de cerrado escrito a mano cuelga ligeramente torcido contra el cristal."

# game/script.rpy:775
translate Paloslios continue_walk_97f194cd:

    # "I linger there awkwardly, wishing I could rewind the day, do it over and stretch it out a little longer."
    "Me quedo allí con torpeza, deseando poder rebobinar el día, hacerlo de nuevo y alargarlo un poco más."

# game/script.rpy:776
translate Paloslios continue_walk_79adeaad:

    # "Silas seems to hesitate too, glancing at the store like he’s waiting for something, but there’s nothing left to wait for."
    "Silas también parece dudar y mira la tienda como si estuviera esperando algo, pero ya no queda nada que esperar."

# game/script.rpy:777
translate Paloslios continue_walk_6b60dc5a:

    # "A hollow feeling settles in my chest at the sight. I don’t want this to be it."
    "Una sensación de vacío se instala en mi pecho ante la vista. No quiero que esto sea así."

# game/script.rpy:778
translate Paloslios continue_walk_1cdcb191:

    # "Not after everything. Not when the weight of the day feels like it’s still hanging in the air between us."
    "No después de todo. No cuando parece que el peso del día todavía flota en el aire entre nosotros."

# game/script.rpy:781
translate Paloslios continue_walk_07d47202:

    # voice silas_v66
    # s "So, uh..."
    voice silas_v66
    s "Entonces, eh..."

# game/script.rpy:785
translate Paloslios continue_walk_c0adacee:

    # voice silas_v67
    # s "Same place, same time tomorrow ?"
    voice silas_v67
    s "¿Mañana en el mismo lugar y a la misma hora?"

# game/script.rpy:788
translate Paloslios continue_walk_56a5b488:

    # "He tries to sound casual, but there’s a stiffness to his voice."
    "Intenta sonar casual, pero hay rigidez en su voz."

# game/script.rpy:789
translate Paloslios continue_walk_d677f102:

    # "And something in me just... snaps."
    "Y algo en mí simplemente... se rompe."

# game/script.rpy:792
translate Paloslios continue_walk_1ea9d8d5:

    # "I step forward quickly, catching his hands in mine before I can talk myself out of it."
    "Doy un paso adelante rápidamente, agarrando sus manos entre las mías antes de que pueda convencerme de no hacerlo."

# game/script.rpy:793
translate Paloslios continue_walk_37c0dea4:

    # "My fingers grip his a little too tight, but I’m too nervous to care."
    "Mis dedos agarran los suyos con demasiada fuerza, pero estoy demasiado nerviosa para preocuparme."

# game/script.rpy:796
translate Paloslios continue_walk_e5b8c54e:

    # mc "Wait-"
    mc "Espera-"

# game/script.rpy:797
translate Paloslios continue_walk_a9331de8:

    # mc "I... I really liked spending the day with you."
    mc "A mí... me gustó mucho pasar el día contigo."

# game/script.rpy:801
translate Paloslios continue_walk_bc7d9a40:

    # "His expression softens instantly."
    "Su expresión se suaviza al instante."

# game/script.rpy:803
translate Paloslios continue_walk_cbb0d050:

    # mc "And not just today. All those days we talked online, the stupid late-night conversations, weird memes, random book rants—"
    mc "Y no sólo hoy. Todos esos días que hablamos en línea, las estúpidas conversaciones nocturnas, los memes extraños, las peroratas aleatorias sobre libros..."

# game/script.rpy:805
translate Paloslios continue_walk_08ac16a7:

    # "I laugh awkwardly."
    "Me río torpemente."

# game/script.rpy:807
translate Paloslios continue_walk_dfd871a9:

    # mc "I don’t know, it’s just... it felt like we had something. And today kind of made me realize I..."
    mc "No lo sé, es solo que... sentimos como si tuviéramos algo. Y hoy me hizo darme cuenta de que..."

# game/script.rpy:808
translate Paloslios continue_walk_ec70ace3:

    # mc "I like you, Silas. I’ve liked you for a while now."
    mc "Me gustas, Silas. Me gustas desde hace un tiempo."

# game/script.rpy:810
translate Paloslios continue_walk_c9786825:

    # "Silas blinks at me, stunned."
    "Silas me mira parpadeando, aturdido."

# game/script.rpy:816
translate Paloslios continue_walk_14d1bd88:

    # "Then he steps in."
    "Luego interviene."

# game/script.rpy:818
translate Paloslios continue_walk_3ebb91ec:

    # "And kisses me."
    "Y me besa."

# game/script.rpy:820
translate Paloslios continue_walk_5776d048:

    # "It’s soft at first, a little hesitant, but then his hand lifts to cup my cheek."
    "Es suave al principio, un poco vacilante, pero luego su mano se levanta para acariciar mi mejilla."

# game/script.rpy:822
translate Paloslios continue_walk_2bd83d19:

    # "Everything else falls away."
    "Todo lo demás desaparece."

# game/script.rpy:824
translate Paloslios continue_walk_3864f8d7:

    # "When we pull apart, Silas’s face is a little pink, his smile lopsided."
    "Cuando nos separamos, la cara de Silas está un poco rosada y su sonrisa es torcida."

# game/script.rpy:827
translate Paloslios continue_walk_ba43cd63:

    # voice silas_v68
    # s "I... really like you too."
    voice silas_v68
    s "A mí... tú también me gustas mucho."

# game/script.rpy:829
translate Paloslios continue_walk_47d516a2:

    # voice silas_v69
    # s "Today’s been... one of the best days I’ve had in years."
    voice silas_v69
    s "Hoy ha sido... uno de los mejores días que he tenido en años."

# game/script.rpy:831
translate Paloslios continue_walk_0a8c37f1:

    # voice silas_v70
    # s "I had... No, I'm still having so much fun with you !"
    voice silas_v70
    s "Tuve... ¡No, todavía me estoy divirtiendo mucho contigo!"

# game/script.rpy:833
translate Paloslios continue_walk_10deeb84:

    # "For a while there, I forgot about everything. I didn’t think I’d get to have something like this again."
    "Por un tiempo me olvidé de todo. No pensé que volvería a tener algo como esto."

# game/script.rpy:836
translate Paloslios continue_walk_722dc3ff:

    # "There’s something in his voice that makes my throat tighten."
    "Hay algo en su voz que hace que se me haga un nudo en la garganta."

# game/script.rpy:838
translate Paloslios continue_walk_e02106f4:

    # mc "Do you wanna stay at my place tonight ?"
    mc "¿Quieres quedarte en mi casa esta noche?"

# game/script.rpy:841
translate Paloslios continue_walk_c1c95d6f:

    # mc "I mean—"
    mc "Quiero decir—"

# game/script.rpy:842
translate Paloslios continue_walk_f9a01c72:

    # mc "Please come to my place tonight."
    mc "Por favor, ven a mi casa esta noche."

# game/script.rpy:844
translate Paloslios continue_walk_e1554201_2:

    # s "..."
    s "..."

# game/script.rpy:847
translate Paloslios continue_walk_48cacc20:

    # voice silas_v71
    # s "Yeah, I’d like that."
    voice silas_v71
    s "Sí, me gustaría eso."

# game/script.rpy:850
translate Paloslios continue_walk_352f9f72:

    # "We stayed there for a second longer, just standing in the quiet glow of the streetlights, hands still tangled."
    "Nos quedamos allí un segundo más, de pie bajo el silencioso resplandor de las farolas, con las manos todavía enredadas."

# game/script.rpy:852
translate Paloslios continue_walk_1aaff109:

    # mc "You know... I wasn’t sure you’d even show up today."
    mc "Sabes... no estaba seguro de que aparecieras hoy."

# game/script.rpy:856
translate Paloslios continue_walk_7d3d267b:

    # voice silas_v72
    # s "What ? Why ?"
    voice silas_v72
    s "Qué ? Por qué ?"

# game/script.rpy:859
translate Paloslios continue_walk_182402ef:

    # mc "I don’t know. I just... kept thinking maybe you’d decide it wasn’t worth it."
    mc "No sé. Yo sólo... seguí pensando que tal vez decidirías que no valía la pena."

# game/script.rpy:862
translate Paloslios continue_walk_fda2d990:

    # mc "That meeting me in person would be disappointing, or weird, or..."
    mc "Que conocerme en persona sería decepcionante, o extraño, o..."

# game/script.rpy:864
translate Paloslios continue_walk_3f1413a0:

    # "I trail off."
    "Me detengo."

# game/script.rpy:866
translate Paloslios continue_walk_d9f6edce:

    # mc "I’ve been nervous about today for weeks. But it’s not because I didn’t want to meet you. I was scared you’d think I was weird, or unlikable, or something."
    mc "He estado nervioso por lo de hoy durante semanas. Pero no es porque no quisiera conocerte. Tenía miedo de que pensaras que era raro, desagradable o algo así."

# game/script.rpy:868
translate Paloslios continue_walk_e3947321:

    # "He laughs softly."
    "Él se ríe suavemente."

# game/script.rpy:872
translate Paloslios continue_walk_fad9d8f8:

    # voice silas_v73
    # s "If you’re weird, then I don’t know what I am !"
    voice silas_v73
    s "¡Si eres raro entonces no sé lo que soy!"

# game/script.rpy:876
translate Paloslios continue_walk_0aae560c:

    # voice silas_v74
    # s "I’m glad I came. Really, really glad, [name]."
    voice silas_v74
    s "Me alegro de haber venido. Realmente, muy feliz, [name]."

# game/script.rpy:880
translate Paloslios continue_walk_0ab307d6:

    # "We keep back on walking, slower now."
    "Seguimos caminando, ahora más despacio."

# game/script.rpy:884
translate Paloslios continue_walk_7bf73b6a:

    # "When we reach my place we both hesitate at the bottom of the steps."
    "Cuando llegamos a mi casa, ambos dudamos al final de las escaleras."

# game/script.rpy:887
translate Paloslios continue_walk_2e1e6ba8:

    # voice silas_v75
    # s "So... this is your place ?"
    voice silas_v75
    s "Entonces... ¿este es tu lugar?"

# game/script.rpy:890
translate Paloslios continue_walk_159aa505:

    # mc "Yup, not that far from your hotel ! At least you can go back if you need something."
    mc "Sí, ¡no tan lejos de tu hotel! Al menos puedes regresar si necesitas algo."

# game/script.rpy:894
translate Paloslios continue_walk_6a244058:

    # voice silas_v76
    # s "I hope I won’t have to go back."
    voice silas_v76
    s "Espero no tener que volver."

# game/script.rpy:899
translate Paloslios continue_walk_d13976cd:

    # "As I push the door open, I wave toward the mess scattered around."
    "Mientras abro la puerta, saludo con la mano el desorden esparcido por ahí."

# game/script.rpy:901
translate Paloslios continue_walk_39555937:

    # mc "Don't mind the clothes everywhere, I didn’t expect you to come here tonight."
    mc "No te preocupes por la ropa por todas partes, no esperaba que vinieras aquí esta noche."

# game/script.rpy:902
translate Paloslios continue_walk_dc886efd:

    # mc "I would have cleaned though—"
    mc "Aunque habría limpiado—"

# game/script.rpy:903
translate Paloslios continue_walk_801497e3:

    # voice silas_v77
    # s "It’s alright, I’m pretty messy myself."
    voice silas_v77
    s "Está bien, yo también estoy bastante desordenado."

# game/script.rpy:906
translate Paloslios continue_walk_cd85f389:

    # "I take off my jacket by the door."
    "Me quito la chaqueta junto a la puerta."

# game/script.rpy:908
translate Paloslios continue_walk_797cdd42:

    # mc "Oh by the way, my cat might be hidden in my bedroom if you wanna see her !"
    mc "¡Ah, por cierto, mi gato podría estar escondido en mi habitación si quieres verla!"

# game/script.rpy:909
translate Paloslios continue_walk_7393ee84:

    # voice silas_v78
    # s "Oh ! Can I check on her ?"
    voice silas_v78
    s "Oh ! ¿Puedo ver cómo está?"

# game/script.rpy:912
translate Paloslios continue_walk_cd25dcab:

    # mc "Sure ! Second door, after the bathroom."
    mc "Seguro ! Segunda puerta, después del baño."

# game/script.rpy:914
translate Paloslios continue_walk_4be1df15:

    # "Silas heads toward the bedroom while I step into the living room."
    "Silas se dirige al dormitorio mientras yo entro a la sala de estar."

# game/script.rpy:916
translate Paloslios continue_walk_87edafa3:

    # "I hear the faint creak of the bedroom door, followed by a curious meow."
    "Escucho el leve crujido de la puerta del dormitorio, seguido de un curioso maullido."

# game/script.rpy:918
translate Paloslios continue_walk_320da545:

    # "Making sure nothing’s lying around, I spot my laptop on the coffee table."
    "Asegurándome de que no haya nada por ahí, veo mi computadora portátil en la mesa de café."

# game/script.rpy:920
translate Paloslios continue_walk_1258903f:

    # "I hadn’t checked it all day, so I move over to open it."
    "No lo había revisado en todo el día, así que me acerco para abrirlo."

# game/script.rpy:923
translate Paloslios continue_walk_7a29c9f0:

    # "A flood of notifications hit me — almost forty unread messages, all from Silas."
    "Me llegó una avalancha de notificaciones: casi cuarenta mensajes sin leer, todos de Silas."

# game/script.rpy:925
translate Paloslios continue_walk_6128c5fd:

    # "My heart skips a beat."
    "Mi corazón da un vuelco."

# game/script.rpy:927
translate Paloslios continue_walk_2ecb4a9a:

    # "I quickly click on the first one."
    "Rápidamente hago clic en el primero."

# game/script.rpy:929
translate Paloslios continue_walk_66a661df:

    # "{color=#d3239b}{b}Silas{/b}: {i}Hey, where are you ? I’m getting worried."
    "{color=#d3239b}{b}Silas{/b}: {i}Oye, ¿dónde estás? Me estoy preocupando."

# game/script.rpy:932
translate Paloslios continue_walk_383a879a:

    # "Another message pops up, then another. All from Silas."
    "Aparece otro mensaje, luego otro. Todo de Silas."

# game/script.rpy:933
translate Paloslios continue_walk_e163febf:

    # "The messages shift from lighthearted to urgent. Something strange."
    "Los mensajes pasan de alegres a urgentes. Algo extraño."

# game/script.rpy:935
translate Paloslios continue_walk_2db3eb7f:

    # "{color=#d3239b}{b}Silas{/b}: {i}Why aren’t you responding ? I’m starting to think something’s wrong."
    "{color=#d3239b}{b}Silas{/b}: {i}¿Por qué no respondes? Estoy empezando a pensar que algo anda mal."

# game/script.rpy:936
translate Paloslios continue_walk_2edaabdb:

    # "{color=#d3239b}{b}Silas{/b}: {i}Please, tell me you’re alright."
    "{color=#d3239b}{b}Silas{/b}: {i}Por favor, dime que estás bien."

# game/script.rpy:937
translate Paloslios continue_walk_cf1df1f4:

    # "{color=#d3239b}{b}Silas{/b}: {i}I’m sorry my flight got canceled. I hope you didn’t wait long."
    "{color=#d3239b}{b}Silas{/b}: {i}Lamento que mi vuelo haya sido cancelado. Espero que no hayas esperado mucho."

# game/script.rpy:938
translate Paloslios continue_walk_20f35829:

    # "{color=#d3239b}{b}Silas{/b}: {i}I don’t have much wifi, but message me soon."
    "{color=#d3239b}{b}Silas{/b}: {i}No tengo mucho wifi, pero envíame un mensaje pronto."

# game/script.rpy:939
translate Paloslios continue_walk_09b5ff8e:

    # "{color=#d3239b}{b}Silas{/b}: {i}[name] ?"
    "{color=#d3239b}{b}Silas{/b}: {i}[name] ?"

# game/script.rpy:941
translate Paloslios continue_walk_a1eb7e71:

    # "A weird, uneasy feeling twists in my stomach."
    "Una sensación extraña e incómoda se retuerce en mi estómago."

# game/script.rpy:942
translate Paloslios continue_walk_a8957f77:

    # "Why would he have sent me so many messages ?"
    "¿Por qué me habría enviado tantos mensajes?"

# game/script.rpy:944
translate Paloslios continue_walk_e6ebd2bc:

    # "I hear the bedroom door open again."
    "Oigo que la puerta del dormitorio se abre de nuevo."

# game/script.rpy:947
translate Paloslios continue_walk_3ac53ff8:

    # voice silas_v79
    # s "She’s cute. I think she likes me."
    voice silas_v79
    s "Ella es linda. Creo que le gusto."

# game/script.rpy:950
translate Paloslios continue_walk_d2ab7542:

    # "I stare at my laptop, the last message from Silas on the screen."
    "Miro mi computadora portátil, el último mensaje de Silas en la pantalla."

# game/script.rpy:954
translate Paloslios continue_walk_0d031bd4:

    # voice silas_v80
    # s "Something’s going on ?"
    voice silas_v80
    s "¿Algo está pasando?"

# game/script.rpy:957
translate Paloslios continue_walk_447ebb54:

    # "I quickly shut the laptop."
    "Cerré rápidamente la computadora portátil."

# game/script.rpy:959
translate Paloslios continue_walk_f6138f20:

    # mc "Uh, sorry, work mail just came in. Kinda ruined my mood."
    mc "Lo siento, acaba de llegar el correo del trabajo. Un poco arruinó mi estado de ánimo."

# game/script.rpy:962
translate Paloslios continue_walk_4a814c40:

    # mc "I should answer it now because it’s urgent. Do you mind ?"
    mc "Debería responderla ahora porque es urgente. Te importa ?"

# game/script.rpy:963
translate Paloslios continue_walk_291af349:

    # mc "You can wait in the bedroom if you want."
    mc "Puedes esperar en el dormitorio si quieres."

# game/script.rpy:965
translate Paloslios continue_walk_e2db03fb:

    # "Silas looks a little puzzled but nods, carrying the cat back."
    "Silas parece un poco desconcertado, pero asiente y se lleva al gato de regreso."

# game/script.rpy:967
translate Paloslios continue_walk_da9bbc0c:

    # voice silas_v81
    # s "Don’t get too distracted by work ! I’m still here !"
    voice silas_v81
    s "¡No te distraigas demasiado con el trabajo! ¡Todavía estoy aquí!"

# game/script.rpy:969
translate Paloslios continue_walk_b78aa4fb:

    # "I scrutinize him as he walks away."
    "Lo escudriño mientras se aleja."

# game/script.rpy:971
translate Paloslios continue_walk_f9cd796d:

    # "The moment the bedroom door clicks shut, I waste no time opening the laptop."
    "En el momento en que la puerta del dormitorio se cierra, no pierdo el tiempo en abrir la computadora portátil."

# game/script.rpy:973
translate Paloslios continue_walk_df98a446:

    # "My hands trembling, I type a message to Silas."
    "Con las manos temblorosas, le escribo un mensaje a Silas."

# game/script.rpy:975
translate Paloslios continue_walk_4bfbf872:

    # mc "I just saw your messages. Why so many ? What’s going on ?"
    mc "Acabo de ver tus mensajes. ¿Por qué tantos? Qué está sucediendo ?"

# game/script.rpy:977
translate Paloslios continue_walk_20e94eab:

    # "Almost instantly, a notification pops up."
    "Casi al instante, aparece una notificación."

# game/script.rpy:980
translate Paloslios continue_walk_df56cdce:

    # "{color=#d3239b}{b}Silas{/b}: {fi=13-1.1-40}{color=#d3239b}{i}Sorry, I wasn’t there to answer you."
    "{color=#d3239b}{b}Silas{/b}: {fi=13-1.1-40}{color=#d3239b}{i}Lo siento, no estaba allí para responderte."

# game/script.rpy:982
translate Paloslios continue_walk_2b1c05fb:

    # "{color=#d3239b}{b}Silas{/b}: {fi=13-1.1-40}{color=#d3239b}{i}I’m trying to get a flight tomorrow."
    "{color=#d3239b}{b}Silas{/b}: {fi=13-1.1-40}{color=#d3239b}{i}Estoy intentando conseguir un vuelo mañana."

# game/script.rpy:984
translate Paloslios continue_walk_90a7d5d7:

    # "{color=#d3239b}{b}Silas{/b}: {fi=13-1.1-40}{color=#d3239b}{i}Sorry if I made you worry."
    "{color=#d3239b}{b}Silas{/b}: {fi=13-1.1-40}{color=#d3239b}{i}Perdón si te hice preocupar."

# game/script.rpy:986
translate Paloslios continue_walk_7562a93a:

    # "I read the message over and over. It doesn’t make sense."
    "Leí el mensaje una y otra vez. No tiene sentido."

# game/script.rpy:988
translate Paloslios continue_walk_5a967036:

    # "He wasn’t here. He couldn’t have been."
    "Él no estaba aquí. No podría haberlo sido."

# game/script.rpy:990
translate Paloslios continue_walk_b0837c5b:

    # "Then who was with me—"
    "Entonces ¿quién estaba conmigo?"

# game/script.rpy:992
translate Paloslios continue_walk_0f77cfd7:

    # "I freeze."
    "Me congelo."

# game/script.rpy:994
translate Paloslios continue_walk_e9088dc7:

    # "The bedroom door creaks open again, slower this time."
    "La puerta del dormitorio se abre de nuevo con un chirrido, esta vez más lento."

# game/script.rpy:996
translate Paloslios continue_walk_90f5b5f0:

    # "A low meow breaks the silence."
    "Un maullido grave rompe el silencio."

# game/script.rpy:998
translate Paloslios continue_walk_59c33b10:

    # "A calm, deep hum follows."
    "Sigue un zumbido tranquilo y profundo."

# game/script.rpy:1000
translate Paloslios continue_walk_57933f30:

    # "Dread twists in my chest."
    "El miedo se retuerce en mi pecho."

# game/script.rpy:1002
translate Paloslios continue_walk_a9fc00a0:

    # "{sc=2}There is a stranger in my house."
    "{sc=2}Hay un extraño en mi casa."

# game/script.rpy:1004
translate Paloslios continue_walk_76a05d84:

    # "{sc=3}Hell, a stranger has been lying to me all day."
    "{sc=3}Diablos, un extraño me ha estado mintiendo todo el día."

# game/script.rpy:1006
translate Paloslios continue_walk_8ee2b6d1:

    # "{sc=6}{b}{color=#f60808}WHO IS THAT ?!"
    "{sc=6}{b}{color=#f60808}¡¿QUIÉN ES ESE?!"

# game/script.rpy:1008
translate Paloslios continue_walk_10d51a12:

    # "{sc=3}The soft sound of the cat purring sends a chill through me."
    "{sc=3}El suave sonido del ronroneo del gato me provoca un escalofrío."

# game/script.rpy:1009
translate Paloslios continue_walk_d7dea783:

    # "{sc=1}It’s too calm. Too normal. It feels wrong."
    "{sc=1}Está demasiado tranquilo. Demasiado normal. Se siente mal."

# game/script.rpy:1010
translate Paloslios continue_walk_bac79679:

    # "My body tenses, and anxiety shoots through me like a wave."
    "Mi cuerpo se tensa y la ansiedad me atraviesa como una ola."

# game/script.rpy:1011
translate Paloslios continue_walk_6a0caa47:

    # "I can hear the man, whoever he is cooing at my cat, making her purr even louder."
    "Puedo escuchar al hombre, sea quien sea, arrullar a mi gata, haciéndola ronronear aún más fuerte."

# game/script.rpy:1012
translate Paloslios continue_walk_a432b9a0:

    # "But I can’t seem to make myself move."
    "Pero parece que no puedo moverme."

# game/script.rpy:1013
translate Paloslios continue_walk_472ce6cb:

    # "My body won’t obey me. My legs feel as if they’re chained to the couch."
    "Mi cuerpo no me obedece. Siento las piernas como si estuvieran encadenadas al sofá."

# game/script.rpy:1014
translate Paloslios continue_walk_75c29081:

    # "My pulse thrums in my ear, but all I can do is sit here."
    "Mi pulso late en mi oído, pero lo único que puedo hacer es sentarme aquí."

# game/script.rpy:1015
translate Paloslios continue_walk_5362fe07:

    # "My phone buzzes on the coffee table, but I don’t dare look away from the bedroom door. Not yet. Afraid to even blink."
    "Mi teléfono suena sobre la mesa de café, pero no me atrevo a apartar la mirada de la puerta del dormitorio. Aún no. Miedo incluso de parpadear."

# game/script.rpy:1016
translate Paloslios continue_walk_ec3a6685:

    # "My mind is racing through every possible scenario."
    "Mi mente recorre todos los escenarios posibles."

# game/script.rpy:1017
translate Paloslios continue_walk_f00e0dd0:

    # "The laptop screen is still open in front of me, the message from the real Silas who seemingly went offline."
    "La pantalla del portátil todavía está abierta frente a mí, el mensaje del verdadero Silas que aparentemente se desconectó."

# game/script.rpy:1018
translate Paloslios continue_walk_1c60f3d0:

    # "Then, as if in a trance, I feel my hand slowly reach for my phone on the coffee table."
    "Luego, como en trance, siento que mi mano alcanza lentamente mi teléfono sobre la mesa de café."

# game/script.rpy:1019
translate Paloslios continue_walk_848cee96:

    # "My fingertips graze it, but I hesitate. The weight of the decision is suffocating, and my mind spins in circles."
    "Mis dedos lo rozan, pero dudo. El peso de la decisión es asfixiante y mi mente da vueltas en círculos."

# game/script.rpy:1021
translate Paloslios continue_walk_8191514f:

    # "{sc=1}What do I do-"
    "{sc=1}¿Qué hago?"

# game/script.rpy:1038
translate Paloslios confront_the_man_6dde92e7:

    # "Maybe it was adrenaline."
    "Quizás fue adrenalina."

# game/script.rpy:1039
translate Paloslios confront_the_man_12b112af:

    # "Or maybe it was a death wish disguised as courage."
    "O tal vez fue un deseo de muerte disfrazado de coraje."

# game/script.rpy:1040
translate Paloslios confront_the_man_99bf8176:

    # "Either way, I stood up."
    "De cualquier manera, me levanté."

# game/script.rpy:1043
translate Paloslios confront_the_man_497d2b9e:

    # "My legs felt like they were made of glass, each step toward the bedroom door sharp and fragile."
    "Mis piernas se sentían como si estuvieran hechas de vidrio, cada paso hacia la puerta del dormitorio era agudo y frágil."

# game/script.rpy:1044
translate Paloslios confront_the_man_24c81d9b:

    # "My hand hovered over the handle, shaking."
    "Mi mano se cernía sobre el mango, temblando."

# game/script.rpy:1045
translate Paloslios confront_the_man_3e049803:

    # "The air felt heavier near the threshold, like it was thick with something I wasn’t supposed to breathe."
    "El aire se sentía más pesado cerca del umbral, como si estuviera cargado de algo que se suponía que no debía respirar."

# game/script.rpy:1046
translate Paloslios confront_the_man_3c980921:

    # "And yet... I turned the knob."
    "Y sin embargo... giré la perilla."

# game/script.rpy:1048
translate Paloslios confront_the_man_99f2fb25:

    # "The door creaked open."
    "La puerta se abrió con un chirrido."

# game/script.rpy:1049
translate Paloslios confront_the_man_f06014b4:

    # "He was crouched on the floor, scratching my cat behind her ears, a gentle smile on his lips."
    "Estaba agachado en el suelo, rascando a mi gata detrás de las orejas y con una suave sonrisa en los labios."

# game/script.rpy:1051
translate Paloslios confront_the_man_5686b4a4:

    # "But when he looked up at me..."
    "Pero cuando me miró..."

# game/script.rpy:1053
translate Paloslios confront_the_man_5478078f:

    # "When our eyes met..."
    "Cuando nuestras miradas se encontraron..."

# game/script.rpy:1054
translate Paloslios confront_the_man_ded78b74:

    # "Everything changed."
    "Todo cambió."

# game/script.rpy:1056
translate Paloslios confront_the_man_fae874c3:

    # "Never in my life had I seen someone shift so completely, so instantly."
    "Nunca en mi vida había visto a alguien cambiar tan completamente, tan instantáneamente."

# game/script.rpy:1057
translate Paloslios confront_the_man_d9ffd2df:

    # "The warmth was gone."
    "El calor había desaparecido."

# game/script.rpy:1058
translate Paloslios confront_the_man_40e2a4bf:

    # "The easy laughter, the harmless nervousness from earlier... gone. Vanished like a breath on a mirror."
    "La risa fácil, el nerviosismo inofensivo de antes… desaparecido. Desapareció como un aliento en un espejo."

# game/script.rpy:1059
translate Paloslios confront_the_man_b114d1f9:

    # "It was like watching someone drop a mask."
    "Fue como ver a alguien dejar caer una máscara."

# game/script.rpy:1060
translate Paloslios confront_the_man_76531341:

    # "It didn’t just fall it shattered against you."
    "No sólo cayó, sino que se hizo añicos contra ti."

# game/script.rpy:1061
translate Paloslios confront_the_man_7b09d2b5:

    # "Suddenly, you’re staring at something that’s known you just enough to make your skin crawl."
    "De repente, estás mirando algo que te conoce lo suficiente como para ponerte la piel de gallina."

# game/script.rpy:1062
translate Paloslios confront_the_man_2b38d5ab:

    # "What replaced it wasn’t even human."
    "Lo que lo reemplazó ni siquiera fue humano."

# game/script.rpy:1063
translate Paloslios confront_the_man_73df0aaa:

    # "I don’t know who he was."
    "No sé quién era."

# game/script.rpy:1064
translate Paloslios confront_the_man_c1866190:

    # "But I know he didn’t intend for me to find out."
    "Pero sé que él no tenía la intención de que yo lo descubriera."

# game/script.rpy:1065
translate Paloslios confront_the_man_497332ef:

    # "For a split second, neither of us moved."
    "Por una fracción de segundo, ninguno de nosotros se movió."

# game/script.rpy:1066
translate Paloslios confront_the_man_c046727c:

    # "{sc=1}Then he smiled."
    "{sc=1}Luego sonrió."

# game/script.rpy:1067
translate Paloslios confront_the_man_3c023580:

    # "{sc=1}Not the smile from the café, or when we talked about books."
    "{sc=1}Ni la sonrisa del café, ni cuando hablábamos de libros."

# game/script.rpy:1068
translate Paloslios confront_the_man_ca821db8:

    # "{sc=1}Not the one he had when he told me he loved me too."
    "{sc=1}No el que tenía cuando me dijo que él también me amaba."

# game/script.rpy:1069
translate Paloslios confront_the_man_f9dcb809:

    # "{sc=1}Something else."
    "{sc=1}Algo más."

# game/script.rpy:1070
translate Paloslios confront_the_man_3d9e395a:

    # "{sc=1}Something sinister and deprived of any ounce of humanity."
    "{sc=1}Algo siniestro y desprovisto de cualquier gramo de humanidad."

# game/script.rpy:1072
translate Paloslios confront_the_man_676c9e8b:

    # centered "Ending 1: {b}{color=f60808}Fear"
    centered "Finalizando 1: {b}{color=f60808}Miedo"

# game/script.rpy:1079
translate Paloslios run_away_753a6bbe:

    # "The logical part of my brain clawed its way back to the surface."
    "La parte lógica de mi cerebro volvió a la superficie."

# game/script.rpy:1080
translate Paloslios run_away_13d103e3:

    # "Move. NOW!"
    "Mover. ¡AHORA!"

# game/script.rpy:1082
translate Paloslios run_away_6002d6b8:

    # "My fingers wrapped around my phone, clumsy and cold."
    "Mis dedos se enredaron alrededor de mi teléfono, torpes y fríos."

# game/script.rpy:1083
translate Paloslios run_away_2ac87167:

    # "I didn’t even think about the charger still plugged in or the shoes abandoned near the door."
    "Ni siquiera pensé en el cargador todavía enchufado o en los zapatos abandonados cerca de la puerta."

# game/script.rpy:1085
translate Paloslios run_away_45e2d222:

    # "My body just moved, driven by pure survival."
    "Mi cuerpo simplemente se movió, impulsado por pura supervivencia."

# game/script.rpy:1087
translate Paloslios run_away_36ef0cf3:

    # "I bolted to the front door, my heartbeat a deafening drum in my ears."
    "Corrí hacia la puerta principal, con los latidos de mi corazón como un tambor ensordecedor en mis oídos."

# game/script.rpy:1088
translate Paloslios run_away_de5a6df4:

    # "I didn’t care if he heard. I didn’t care if he followed."
    "No me importaba si él escuchaba. No me importaba si él me seguía."

# game/script.rpy:1089
translate Paloslios run_away_3551ef52:

    # "I needed to get out."
    "Necesitaba salir."

# game/script.rpy:1091
translate Paloslios run_away_2f67862f:

    # "I flung the door open, almost tripping over the threshold, the hallway beyond stretching out like a lifeline."
    "Abrí la puerta de golpe, casi tropezando con el umbral, el pasillo más allá se extendía como un salvavidas."

# game/script.rpy:1092
translate Paloslios run_away_49e9c9d9:

    # "I sprinted down the corridor, dialing emergency services with shaking hands."
    "Corrí por el pasillo, llamando a los servicios de emergencia con manos temblorosas."

# game/script.rpy:1094
translate Paloslios run_away_1f35973d:

    # "I kept looking back over my shoulder, my breath choked by the anxiety flooding every part of my body, half-expecting to see him standing there."
    "Seguí mirando hacia atrás por encima del hombro, con la respiración entrecortada por la ansiedad que inundaba cada parte de mi cuerpo, medio esperando verlo parado allí."

# game/script.rpy:1095
translate Paloslios run_away_c0c1f199:

    # "Smiling."
    "Sonriente."

# game/script.rpy:1097
translate Paloslios run_away_b0bae50b:

    # "But the door to my apartment remained closed."
    "Pero la puerta de mi apartamento permaneció cerrada."

# game/script.rpy:1102
translate Paloslios run_away_106f8daa:

    # "I didn’t stop until I was out on the street, lungs burning, the night air cutting into my skin."
    "No paré hasta que estuve en la calle, con los pulmones ardiendo y el aire de la noche cortando mi piel."

# game/script.rpy:1103
translate Paloslios run_away_284147ce:

    # "The phone connected to the police, my voice cracking as I gave my address."
    "El teléfono se conectó con la policía y mi voz se quebró cuando di mi dirección."

# game/script.rpy:1104
translate Paloslios run_away_9ce6e491:

    # "I don’t remember what I said."
    "No recuerdo lo que dije."

# game/script.rpy:1105
translate Paloslios run_away_4c17f22a:

    # "I don’t remember when the officers arrived, nor what I did while waiting for them."
    "No recuerdo cuándo llegaron los agentes ni qué hice mientras los esperaba."

# game/script.rpy:1107
translate Paloslios run_away_ace927ff:

    # "I just remember that when I went back up with the cops, my cat was still there."
    "Sólo recuerdo que cuando volví con la policía, mi gato todavía estaba allí."

# game/script.rpy:1108
translate Paloslios run_away_c488766d:

    # "With a note left on top of my open laptop."
    "Con una nota dejada encima de mi computadora portátil abierta."

# game/script.rpy:1110
translate Paloslios run_away_b858a62a:

    # voice silas_v83
    # "\"I had a great time today.\""
    voice silas_v83
    "\"Hoy lo he pasado genial.\""

# game/script.rpy:1112
translate Paloslios run_away_2e89d11a:

    # voice silas_v84
    # "\"But please, don’t bring strangers home :)\""
    voice silas_v84
    "\p\"Pero por favor, no traigas extraños a casa :)\""

# game/script.rpy:1115
translate Paloslios run_away_a142fe6c:

    # centered "Ending 2: {b}Escape"
    centered "Finalizando 2: {b}Escape"

# game/script.rpy:1122
translate Paloslios play_along_f282baf6:

    # "I don’t know what broke inside me, but something did."
    "No sé qué se rompió dentro de mí, pero algo lo hizo."

# game/script.rpy:1123
translate Paloslios play_along_646ba28b:

    # "Maybe it was the terror."
    "Quizás fue el terror."

# game/script.rpy:1124
translate Paloslios play_along_a4531e52:

    # "Maybe it was the exhaustion."
    "Quizás fue el cansancio."

# game/script.rpy:1125
translate Paloslios play_along_42cf0fe2:

    # "Maybe I just wanted this to not be true."
    "Quizás sólo quería que esto no fuera cierto."

# game/script.rpy:1126
translate Paloslios play_along_f861d504:

    # "I closed my eyes, sucking in a shaky breath, and pushed the laptop screen shut."
    "Cerré los ojos, respiré entrecortadamente y cerré la pantalla del portátil."

# game/script.rpy:1127
translate Paloslios play_along_c02d64dc:

    # "It was probably just a prank."
    "Probablemente fue sólo una broma."

# game/script.rpy:1128
translate Paloslios play_along_fd0586e2:

    # "Or a misunderstanding."
    "O un malentendido."

# game/script.rpy:1129
translate Paloslios play_along_b63d960a:

    # "Maybe someone stole his phone..."
    "Tal vez alguien le robó el teléfono..."

# game/script.rpy:1130
translate Paloslios play_along_d590d9d9:

    # "Yeah. People do that."
    "Sí. La gente hace eso."

# game/script.rpy:1131
translate Paloslios play_along_2cbaaa91:

    # "I laughed, a brittle, hollow sound."
    "Me reí, un sonido quebradizo y hueco."

# game/script.rpy:1132
translate Paloslios play_along_edd2a85e:

    # "This was Silas."
    "Éste era Silas."

# game/script.rpy:1133
translate Paloslios play_along_0bda683f:

    # "At least, this was my boyfriend."
    "Al menos, este era mi novio."

# game/script.rpy:1134
translate Paloslios play_along_6971f34d:

    # "I mean, look at him... He was playing with my cat."
    "Quiero decir, míralo... Estaba jugando con mi gato."

# game/script.rpy:1135
translate Paloslios play_along_9d2c03e5:

    # "What kind of monster would do that ?"
    "¿Qué clase de monstruo haría eso?"

# game/script.rpy:1138
translate Paloslios play_along_29e1661c:

    # "I stood up, smoothing out my clothes like I was about to have a normal night, and walked to the bedroom door."
    "Me levanté, me alisé la ropa como si estuviera a punto de pasar una noche normal y caminé hacia la puerta del dormitorio."

# game/script.rpy:1140
translate Paloslios play_along_11ed65f7:

    # mc "Everything’s okay in there ?"
    mc "¿Está todo bien ahí dentro?"

# game/script.rpy:1142
translate Paloslios play_along_7c3b2ef1:

    # voice silas_v85
    # s "Yeah ! Your cat’s adorable."
    voice silas_v85
    s "Sí ! Tu gato es adorable."

# game/script.rpy:1146
translate Paloslios play_along_f0add8e3:

    # "That night, we watched a movie."
    "Esa noche vimos una película."

# game/script.rpy:1147
translate Paloslios play_along_dbc34b34:

    # "We laughed."
    "Nos reímos."

# game/script.rpy:1148
translate Paloslios play_along_ef3b87f5:

    # "We ordered food."
    "Pedimos comida."

# game/script.rpy:1149
translate Paloslios play_along_81025fcb:

    # "I ignored the cold way his eyes would sometimes linger on me, like he was waiting for me to catch on."
    "Ignoré la forma fría en que sus ojos a veces se detenían en mí, como si estuviera esperando a que me diera cuenta."

# game/script.rpy:1150
translate Paloslios play_along_eb1653ae:

    # "I never asked who he was."
    "Nunca pregunté quién era."

# game/script.rpy:1151
translate Paloslios play_along_fc94a874:

    # "We didn’t sleep together."
    "No dormimos juntos."

# game/script.rpy:1152
translate Paloslios play_along_ef8d2d4c:

    # "But by the morning, he was gone."
    "Pero por la mañana ya no estaba."

# game/script.rpy:1154
translate Paloslios play_along_c5c5df82:

    # centered "Ending 3: {b}Delusion"
    centered "Finalizando 3: {b}Delirio"

# game/script.rpy:1174
translate Paloslios epilogue_64fe00df:

    # centered "A few months later..."
    centered "Unos meses después..."

# game/script.rpy:1178
translate Paloslios epilogue_b7a9b8e9:

    # "The street feels different now."
    "La calle se siente diferente ahora."

# game/script.rpy:1179
translate Paloslios epilogue_55086d9b:

    # "Quieter."
    "Más tranquilo."

# game/script.rpy:1180
translate Paloslios epilogue_c53efff2:

    # "Or maybe it’s just me who’s finally changed."
    "O tal vez soy yo quien finalmente ha cambiado."

# game/script.rpy:1181
translate Paloslios epilogue_78fc9037:

    # "Late morning sunlight filters over the bookstore’s awning, brushing the pavement with a warm gold."
    "La luz del sol del final de la mañana se filtra sobre el toldo de la librería, rozando el pavimento con un cálido dorado."

# game/script.rpy:1182
translate Paloslios epilogue_acfc6baf:

    # "I slow my steps without thinking, like my body still isn’t used to walking past this place without bracing for... Something."
    "Reduzco mis pasos sin pensar, como si mi cuerpo todavía no estuviera acostumbrado a pasar por este lugar sin prepararse para… algo."

# game/script.rpy:1183
translate Paloslios epilogue_ba6ec095:

    # "I guess muscle memory takes time to heal."
    "Supongo que la memoria muscular necesita tiempo para sanar."

# game/script.rpy:1184
translate Paloslios epilogue_667deb1b:

    # "For months, I avoided this street entirely."
    "Durante meses evité esta calle por completo."

# game/script.rpy:1185
translate Paloslios epilogue_e1396b19:

    # "Every time I gathered the courage to pass here again, some part of me twisted, half-expecting to catch a familiar blond head leaning against the wall, mocking me."
    "Cada vez que reunía el coraje para pasar por aquí otra vez, una parte de mí se retorcía, medio esperando encontrar una cabeza rubia familiar apoyada contra la pared, burlándose de mí."

# game/script.rpy:1186
translate Paloslios epilogue_61b9912f:

    # "But the corner stayed empty. Just as empty as my inbox, where Silas’s old conversations used to sit."
    "Pero la esquina quedó vacía. Tan vacía como mi bandeja de entrada, donde solían reposar las viejas conversaciones de Silas."

# game/script.rpy:1187
translate Paloslios epilogue_e674d60f:

    # "I pull my phone from my pocket at the thought."
    "Saco mi teléfono de mi bolsillo ante el pensamiento."

# game/script.rpy:1188
translate Paloslios epilogue_a15f2c52:

    # "No new messages, of course."
    "Por supuesto, no hay mensajes nuevos."

# game/script.rpy:1189
translate Paloslios epilogue_77e426d3:

    # "Silas is gone."
    "Silas se ha ido."

# game/script.rpy:1190
translate Paloslios epilogue_aa9d6f43:

    # "Not gone gone- Just gone from my life."
    "No se ha ido, sólo se ha ido de mi vida."

# game/script.rpy:1191
translate Paloslios epilogue_930451cf:

    # "We talked a little, right after everything. He was kind about it, but understandably got freaked out that I didn't realize it wasn't him."
    "Hablamos un poco, justo después de todo. Él fue amable al respecto, pero comprensiblemente se asustó porque no me di cuenta de que no era él."

# game/script.rpy:1192
translate Paloslios epilogue_a49bc3ea:

    # "I felt so ashamed, so shallow..."
    "Me sentí tan avergonzada, tan superficial..."

# game/script.rpy:1193
translate Paloslios epilogue_bdce9c6a:

    # "A month later, he told me he’d met someone. Someone real. Someone who wasn't me."
    "Un mes después, me dijo que había conocido a alguien. Alguien real. Alguien que no era yo."

# game/script.rpy:1194
translate Paloslios epilogue_f2ee3fb9:

    # "And that was that."
    "Y eso fue todo."

# game/script.rpy:1195
translate Paloslios epilogue_f5d32f33:

    # "Real Silas left my life, and fake Silas was never found by the cops."
    "El Silas real abandonó mi vida y la policía nunca encontró al Silas falso."

# game/script.rpy:1196
translate Paloslios epilogue_fb5e514c:

    # "I should have felt heartbroken."
    "Debería haberme sentido desconsolado."

# game/script.rpy:1197
translate Paloslios epilogue_cf764c4f:

    # "Instead, all I felt was stupid."
    "En cambio, todo lo que sentí fue una estupidez."

# game/script.rpy:1198
translate Paloslios epilogue_067759f2:

    # "So stupid that I let myself get so wrapped up in an idea of someone that I missed the warning signs flashing right in front of me."
    "Tan estúpido que me dejé envolver tanto en la idea de alguien que me perdí las señales de advertencia que parpadeaban justo frente a mí."

# game/script.rpy:1199
translate Paloslios epilogue_8d5e5b79:

    # "It haunted me for so long."
    "Me persiguió durante tanto tiempo."

# game/script.rpy:1200
translate Paloslios epilogue_f229ae9c:

    # "Days turned into weeks, the fear turned into caution, and then eventually into something tolerable."
    "Los días se convirtieron en semanas, el miedo se convirtió en precaución y, finalmente, en algo tolerable."

# game/script.rpy:1201
translate Paloslios epilogue_f202d48a:

    # "Life, stubborn as ever, kept going."
    "La vida, testaruda como siempre, siguió adelante."

# game/script.rpy:1202
translate Paloslios epilogue_7bd84863:

    # "And somehow, I managed to catch up."
    "Y de alguna manera logré ponerme al día."

# game/script.rpy:1203
translate Paloslios epilogue_cd0089f3:

    # "I breathe out slowly, finally ready to get over my fear."
    "Exhalo lentamente, finalmente lista para superar mi miedo."

# game/script.rpy:1204
translate Paloslios epilogue_89a6a492:

    # "I was gonna walk this road, head high."
    "Iba a recorrer este camino con la cabeza en alto."

# game/script.rpy:1206
translate Paloslios epilogue_3b75ed04:

    # mc "No freak in sight today."
    mc "No hay ningún fenómeno a la vista hoy."

# game/script.rpy:1207
translate Paloslios epilogue_280e6979:

    # mc "See [name] ? you're safe..."
    mc "¿Ves [name]? estás a salvo..."

# game/script.rpy:1209
translate Paloslios epilogue_33f3c4ae:

    # "A small victory, but a victory nonetheless."
    "Una pequeña victoria, pero una victoria al fin y al cabo."

# game/script.rpy:1210
translate Paloslios epilogue_3dd1c422:

    # "I turn away from the bookstore and start walking again, letting the familiar rhythm of the street pull me forward."
    "Me alejo de la librería y empiezo a caminar de nuevo, dejando que el ritmo familiar de la calle me impulse hacia adelante."

# game/script.rpy:1211
translate Paloslios epilogue_8a16b706:

    # "My thoughts drift, unfurling into something softer, something almost peaceful-"
    "Mis pensamientos vagan, desplegándose en algo más suave, algo casi pacífico."

# game/script.rpy:1212
translate Paloslios epilogue_992d2bb6:

    # voice silas_v86
    # eh "Hey [name] !"
    voice silas_v86
    eh "¡Hola [name]!"

# game/script.rpy:1214
translate Paloslios epilogue_72833b9d:

    # "I stop."
    "Me detengo."

# game/script.rpy:1215
translate Paloslios epilogue_330a9cf8:

    # "{sc=2}{color=#f60808}This is a nightmare-"
    "{sc=2}{color=#f60808}Esto es una pesadilla-"

# game/script.rpy:1216
translate Paloslios epilogue_06eb7d55:

    # "{color=#f60808}For a heartbeat, my mind refuses to make sense of what I’m seeing."
    "{color=#f60808}Por un instante, mi mente se niega a darle sentido a lo que estoy viendo."

# game/script.rpy:1219
translate Paloslios epilogue_ddb0927b:

    # "{color=#FC8B8B}A man I’ve never met is walking toward me-"
    "{color=#FC8B8B}Un hombre que nunca he conocido camina hacia mí-"

# game/script.rpy:1220
translate Paloslios epilogue_0aec5c7b:

    # "{color=#FCD4D4}Someone I should’ve passed on the street without a second glance."
    "{color=#FCD4D4}Alguien con quien debería haberme cruzado en la calle sin mirarlo dos veces."

# game/script.rpy:1221
translate Paloslios epilogue_2f3087a1:

    # "But the moment he smiles, something inside me sinks into a sinister and cold feeling."
    "Pero en el momento en que sonríe, algo dentro de mí se hunde en una sensación fría y siniestra."

# game/script.rpy:1225
translate Paloslios epilogue_bd1d9ebd:

    # "Before I can step back, before I can even raise a hand in protest, he closes the distance and wraps his arms around me."
    "Antes de que pueda dar un paso atrás, antes de que pueda siquiera levantar una mano en señal de protesta, él acorta la distancia y me rodea con sus brazos."

# game/script.rpy:1227
translate Paloslios epilogue_f846ee80:

    # "The hug feels like a thousand slaps."
    "El abrazo se siente como mil bofetadas."

# game/script.rpy:1228
translate Paloslios epilogue_7c06529c:

    # "It's warm, firm, and completely wrong."
    "Es cálido, firme y completamente incorrecto."

# game/script.rpy:1231
translate Paloslios epilogue_03de2a70:

    # "Before I can step back, before I can even raise a hand in protest, he closes the distance and, with a quick hand, plays with my hair."
    "Antes de que pueda dar un paso atrás, antes de que pueda siquiera levantar una mano en señal de protesta, él acorta la distancia y, con una mano rápida, juega con mi cabello."

# game/script.rpy:1234
translate Paloslios epilogue_cae1e0eb:

    # "My body locks up instantly."
    "Mi cuerpo se bloquea al instante."

# game/script.rpy:1235
translate Paloslios epilogue_15b010e5:

    # "I can’t move."
    "No puedo moverme."

# game/script.rpy:1236
translate Paloslios epilogue_62cb7084:

    # "I can’t breathe."
    "No puedo respirar."

# game/script.rpy:1237
translate Paloslios epilogue_d1cbf0ad:

    # "Then he laughs."
    "Luego se ríe."

# game/script.rpy:1238
translate Paloslios epilogue_0127dc5e:

    # "The sound crawls straight down my spine."
    "El sonido recorre mi columna vertebral."

# game/script.rpy:1239
translate Paloslios epilogue_57385a5c:

    # "It’s the same laugh."
    "Es la misma risa."

# game/script.rpy:1240
translate Paloslios epilogue_b08cff17:

    # "The same voice."
    "La misma voz."

# game/script.rpy:1242
translate Paloslios epilogue_5c127976:

    # "He pulls back, hands moving to grip my shoulders as if he owns the gesture."
    "Él se retira y sus manos se mueven para agarrar mis hombros como si fuera dueño del gesto."

# game/script.rpy:1243
translate Paloslios epilogue_815ab073:

    # "He's delighted."
    "Está encantado."

# game/script.rpy:1246
translate Paloslios epilogue_4bcdf905:

    # voice silas_v87
    # eh "Wow. You’re stiff today. Didn’t think you’d freeze up like that. Like a deer !"
    voice silas_v87
    eh "Guau. Estás rígido hoy. No pensé que te congelarías así. ¡Como un ciervo!"

# game/script.rpy:1250
translate Paloslios epilogue_1f56758c:

    # "My mouth opens, but nothing comes out."
    "Mi boca se abre, pero no sale nada."

# game/script.rpy:1251
translate Paloslios epilogue_8ec1b8d5:

    # "I'm terrified by his eyes."
    "Estoy aterrorizada por sus ojos."

# game/script.rpy:1252
translate Paloslios epilogue_cd5ad067:

    # "Despite all his effort in acting warm, his eyes are the same."
    "A pesar de todo su esfuerzo por actuar con calidez, sus ojos son los mismos."

# game/script.rpy:1253
translate Paloslios epilogue_1fdb5f05:

    # "Emotionless, glassy, flat."
    "Sin emociones, vidrioso, plano."

# game/script.rpy:1254
translate Paloslios epilogue_7b76e92e:

    # "The same eyes I saw in my doorway."
    "Los mismos ojos que vi en mi puerta."

# game/script.rpy:1255
translate Paloslios epilogue_13af87a1:

    # "The same ones I still see in nightmares."
    "Los mismos que todavía veo en las pesadillas."

# game/script.rpy:1258
translate Paloslios epilogue_2f50d6bd:

    # voice silas_v88
    # eh "Didn’t expect to run into you here."
    voice silas_v88
    eh "No esperaba encontrarme contigo aquí."

# game/script.rpy:1262
translate Paloslios epilogue_61802cfe:

    # voice silas_v89
    # eh "Small world, right ?"
    voice silas_v89
    eh "Mundo pequeño, ¿verdad?"

# game/script.rpy:1264
translate Paloslios epilogue_dbdf0b5f:

    # "I try to take a step back, but he matches it effortlessly, gliding forward like he’s moving with me rather than after me."
    "Intento dar un paso atrás, pero él lo iguala sin esfuerzo, deslizándose hacia adelante como si se moviera conmigo en lugar de detrás de mí."

# game/script.rpy:1267
translate Paloslios epilogue_ade2f3e0:

    # voice silas_v90
    # eh "What ? Cat got your tongue ?"
    voice silas_v90
    eh "Qué ? ¿El gato te comió la lengua?"

# game/script.rpy:1271
translate Paloslios epilogue_b1f647c6:

    # voice silas_v91
    # eh "You're so happy to see me !"
    voice silas_v91
    eh "¡Estás tan feliz de verme!"

# game/script.rpy:1274
translate Paloslios epilogue_d76b6090:

    # "My hands are shaking so violently I’m afraid he’ll notice."
    "Mis manos tiemblan tan violentamente que temo que él se dé cuenta."

# game/script.rpy:1275
translate Paloslios epilogue_66cc8bda:

    # "He leans in slightly, head tilted, smile curling with almost childlike delight."
    "Se inclina ligeramente, con la cabeza inclinada y una sonrisa curvada con un deleite casi infantil."

# game/script.rpy:1278
translate Paloslios epilogue_b4cbcf55:

    # voice silas_v92
    # eh "Come on,"
    voice silas_v92
    eh "vamos,"

# game/script.rpy:1282
translate Paloslios epilogue_64fcb79a:

    # voice silas_v93
    # eh "Don’t look at me like that. It’s just me."
    voice silas_v93
    eh "No me mires así. Soy solo yo."

# game/script.rpy:1286
translate Paloslios epilogue_6d1db2bb:

    # eh "..."
    eh "..."

# game/script.rpy:1289
translate Paloslios epilogue_03448f31:

    # voice silas_v94
    voice silas_v94

# game/script.rpy:1291
translate Paloslios epilogue_0c116f3b:

    # eh "Your lack of reaction is starting to bore me [name]."
    eh "Tu falta de reacción está empezando a aburrirme [name]."

# game/script.rpy:1293
translate Paloslios epilogue_6e6b807c:

    # "Another step closer."
    "Otro paso más cerca."

# game/script.rpy:1294
translate Paloslios epilogue_b289c726:

    # "I can’t tell if he’s closing on me on purpose or if he’s simply incapable of respecting personal space."
    "No puedo decir si se acerca a mí a propósito o si simplemente es incapaz de respetar el espacio personal."

# game/script.rpy:1296
translate Paloslios epilogue_279db8dc:

    # voice silas_95
    # eh "I once again ran into you by chance. Lucky, right ?"
    voice silas_95
    eh "Una vez más me encontré contigo por casualidad. Suerte, ¿verdad?"

# game/script.rpy:1300
translate Paloslios epilogue_5fead15a:

    # voice silas_96
    # eh "Not that I’m complaining."
    voice silas_96
    eh "No es que me esté quejando."

# game/script.rpy:1302
translate Paloslios epilogue_38136834:

    # "My pulse thunders so loudly, I’m not sure if he can hear it."
    "Mi pulso late tan fuerte que no estoy seguro de si él puede oírlo."

# game/script.rpy:1303
translate Paloslios epilogue_36dd5e2f:

    # "He’s still smiling."
    "Él todavía está sonriendo."

# game/script.rpy:1304
translate Paloslios epilogue_4780e320:

    # "Still standing too close."
    "Todavía estando demasiado cerca."

# game/script.rpy:1305
translate Paloslios epilogue_bd21ea67:

    # "And I realize I have to say something, ANYTHING before my fear swallows me whole."
    "Y me doy cuenta de que tengo que decir algo, CUALQUIER COSA antes de que el miedo me trague por completo."

# game/script.rpy:1311
translate Paloslios epilogue_ea95d3fb:

    # mc "I... I swear-"
    mc "Yo... lo juro-"

# game/script.rpy:1312
translate Paloslios epilogue_13e86f96:

    # "I manage, my voice barely holding together,"
    "Me las arreglo, mi voz apenas se mantiene unida,"

# game/script.rpy:1313
translate Paloslios epilogue_6754b2c5:

    # mc "If you don’t back off, I’ll scream so loud I won't even have to call the police for them to come."
    mc "Si no retrocedes, gritaré tan fuerte que ni siquiera tendré que llamar a la policía para que vengan."

# game/script.rpy:1315
translate Paloslios epilogue_71571e4c:

    # "He beams."
    "Él sonríe."

# game/script.rpy:1316
translate Paloslios epilogue_ad57a3a6:

    # "He fucking beams."
    "Él sonríe."

# game/script.rpy:1317
translate Paloslios epilogue_345a86ab:

    # "He's happy as if I’ve just handed him his favorite toy."
    "Está feliz como si le acabara de entregar su juguete favorito."

# game/script.rpy:1320
translate Paloslios epilogue_cdcae7ea:

    # voice silas_98
    voice silas_98

# game/script.rpy:1323
translate Paloslios epilogue_8221a9c2:

    # eh "There’s the fire I remember !"
    eh "¡Ahí está el fuego que recuerdo!"

# game/script.rpy:1327
translate Paloslios epilogue_e7114ebc:

    # voice silas_99
    voice silas_99

# game/script.rpy:1330
translate Paloslios epilogue_daf5c6dc:

    # eh "Aw, why didn't you do that last time, huh ?"
    eh "Ah, ¿por qué no hiciste eso la última vez?"

# game/script.rpy:1334
translate Paloslios epilogue_edee61d2:

    # "His eyes shine with something that feels too close to excitement."
    "Sus ojos brillan con algo que se siente demasiado cercano a la emoción."

# game/script.rpy:1335
translate Paloslios epilogue_0691d152:

    # "He leans back just slightly, giving me a sliver of space. Not because he’s scared, but because he’s 'indulging' me."
    "Se inclina ligeramente hacia atrás, dándome un poco de espacio. No porque tenga miedo, sino porque me está \"complaciendo\"."

# game/script.rpy:1336
translate Paloslios epilogue_4bab2be7:

    # voice silas_100
    voice silas_100

# game/script.rpy:1338
translate Paloslios epilogue_911b4828:

    # eh "Let’s not make a scene. Let's be civilized !"
    eh "No hagamos una escena. ¡Seamos civilizados!"

# game/script.rpy:1339
translate Paloslios epilogue_becc4a38:

    # "His smile widens."
    "Su sonrisa se amplía."

# game/script.rpy:1340
translate Paloslios epilogue_bb7c2a01:

    # voice silas_102
    # eh "You and I should talk. Preferably over a milkshake."
    voice silas_102
    eh "Tú y yo deberíamos hablar. Preferiblemente con un batido."

# game/script.rpy:1345
translate Paloslios epilogue_be056f57:

    # voice silas_103
    # eh "You still like strawberry, right ?"
    voice silas_103
    eh "Todavía te gusta la fresa, ¿verdad?"

# game/script.rpy:1348
translate Paloslios epilogue_d1b35bec:

    # voice silas_104
    # eh "You still like chocolate, right ?"
    voice silas_104
    eh "Todavía te gusta el chocolate, ¿verdad?"

# game/script.rpy:1351
translate Paloslios epilogue_73330659:

    # voice silas_105
    voice silas_105

# game/script.rpy:1352
translate Paloslios epilogue_35846516:

    # "My stomach turns."
    "Mi estómago se revuelve."

# game/script.rpy:1353
translate Paloslios epilogue_fc963ab5:

    # eh "You still like vanilla, right ?"
    eh "Todavía te gusta la vainilla, ¿verdad?"

# game/script.rpy:1358
translate Paloslios epilogue_141d7a78:

    # "My voice comes out small, breathless."
    "Mi voz sale pequeña, sin aliento."

# game/script.rpy:1359
translate Paloslios epilogue_743e5081:

    # mc "What... what do you want ?"
    mc "¿Qué... qué quieres?"

# game/script.rpy:1361
translate Paloslios epilogue_d58ab386:

    # "He lights up instantly, smiling bright and painfully familiar."
    "Se ilumina al instante, con una sonrisa brillante y dolorosamente familiar."

# game/script.rpy:1362
translate Paloslios epilogue_231ae01c:

    # voice silas_101
    voice silas_101

# game/script.rpy:1365
translate Paloslios epilogue_617005df:

    # eh "Oh There you go ! See ? You can talk."
    eh "¡Ahí tienes! Ver ? Puedes hablar."

# game/script.rpy:1366
translate Paloslios epilogue_4f578d1a:

    # "He taps a finger against his chin, pretending to think."
    "Se golpea la barbilla con un dedo, fingiendo pensar."

# game/script.rpy:1367
translate Paloslios epilogue_78c8f1dd:

    # voice silas_106
    voice silas_106

# game/script.rpy:1370
translate Paloslios epilogue_f02944de:

    # eh "What do I want ?"
    eh "¿Qué quiero?"

# game/script.rpy:1371
translate Paloslios epilogue_b1f065a2:

    # voice silas_107
    voice silas_107

# game/script.rpy:1374
translate Paloslios epilogue_039ee1b6:

    # eh "Plenty of things. But nothing scary, promise, I pinky promise, I'll be nice."
    eh "Muchas cosas. Pero nada aterrador, lo prometo, lo prometo con el meñique, seré amable."

# game/script.rpy:1375
translate Paloslios epilogue_2330ff8c:

    # "He grins wider, like we’re sharing an inside joke."
    "Él sonríe más ampliamente, como si estuviéramos compartiendo una broma interna."

# game/script.rpy:1376
translate Paloslios epilogue_7e543610:

    # voice silas_108
    voice silas_108

# game/script.rpy:1379
translate Paloslios epilogue_a07cd0ec:

    # eh "Let’s chat. Catch up. Clear the air."
    eh "Charlemos. Ponerse al día. Limpia el aire."

# game/script.rpy:1380
translate Paloslios epilogue_6f5bc060:

    # voice silas_109
    # eh "Preferably over a milkshake. You loved that place, remember ?"
    voice silas_109
    eh "Preferiblemente con un batido. Amabas ese lugar, ¿recuerdas?"

# game/script.rpy:1385
translate Paloslios epilogue_be056f57_1:

    # voice silas_103
    # eh "You still like strawberry, right ?"
    voice silas_103
    eh "Todavía te gusta la fresa, ¿verdad?"

# game/script.rpy:1388
translate Paloslios epilogue_d1b35bec_1:

    # voice silas_104
    # eh "You still like chocolate, right ?"
    voice silas_104
    eh "Todavía te gusta el chocolate, ¿verdad?"

# game/script.rpy:1391
translate Paloslios epilogue_67ab50a2:

    # voice silas_105
    # eh "You still like vanilla, right ?"
    voice silas_105
    eh "Todavía te gusta la vainilla, ¿verdad?"

# game/script.rpy:1393
translate Paloslios epilogue_7b3aa578:

    # "A chill slides down my spine."
    "Un escalofrío recorre mi espalda."

# game/script.rpy:1397
translate Paloslios epiloguedate_a1c57421:

    # mc "{sc=1}Do I have a choice-"
    mc "{sc=1}¿Tengo otra opción?"

# game/script.rpy:1398
translate Paloslios epiloguedate_40bc5a2c:

    # voice silas_110
    voice silas_110

# game/script.rpy:1402
translate Paloslios epiloguedate_c73aa1d5:

    # eh "Don’t be an idiot, of course not. Come on."
    eh "No seas idiota, por supuesto que no. Vamos."

# game/script.rpy:1405
translate Paloslios epiloguedate_235e4e29:

    # "I don’t move at first."
    "Al principio no me muevo."

# game/script.rpy:1406
translate Paloslios epiloguedate_583e352d:

    # "But he waits."
    "Pero él espera."

# game/script.rpy:1415
translate Paloslios epiloguedate_5ac1670c:

    # "{sc=1}I start to sprint, and the terrifying sound of someone following me makes me fear for my life."
    "{sc=1}Empiezo a correr y el sonido aterrador de alguien siguiéndome me hace temer por mi vida."

# game/script.rpy:1416
translate Paloslios epiloguedate_9ee034cc:

    # "{sc=1}I didn't manage to go very far before I feel hands gripping my shoulders."
    "{sc=1}No logré llegar muy lejos cuando sentí unas manos agarrando mis hombros."

# game/script.rpy:1417
translate Paloslios epiloguedate_1fd213df:

    # "{sc=1}Desperately, I try to get away, but he's stronger."
    "{sc=1}Desesperadamente, trato de escaparme, pero él es más fuerte."

# game/script.rpy:1418
translate Paloslios epiloguedate_4c4c016c:

    # "{sc=1}Eventually, with his hands on my shoulder, Silas walks me to the milkshake shop."
    "{sc=1}Finalmente, con sus manos en mi hombro, Silas me acompaña a la tienda de batidos."

# game/script.rpy:1424
translate Paloslios datedate_b9fbd33d:

    # centered "{sc=1}The world blurs."
    centered "{sc=1}El mundo se desdibuja."

# game/script.rpy:1425
translate Paloslios datedate_4eb5c5d5:

    # centered "{sc=1}The sidewalk."
    centered "{sc=1}La acera."

# game/script.rpy:1426
translate Paloslios datedate_1b73b484:

    # centered "{sc=1}The street noise."
    centered "{sc=1}El ruido de la calle."

# game/script.rpy:1427
translate Paloslios datedate_a505a836:

    # centered "{sc=1}The bookstore behind me."
    centered "{sc=1}La librería detrás de mí."

# game/script.rpy:1428
translate Paloslios datedate_c6319f4e:

    # centered "{sc=1}By the time my thoughts catch up, we’re already there."
    centered "{sc=1}Para cuando mis pensamientos se ponen al día, ya estamos allí."

# game/script.rpy:1430
translate Paloslios datedate_39767be5:

    # centered "{sc=1}The familiar neon sign was buzzing faintly overhead, and the pastel booths were washed in the soft glow of the evening."
    centered "{sc=1}  El familiar letrero de neón zumbaba débilmente en lo alto, y las cabinas de colores pastel estaban bañadas por el suave resplandor\n de la noche."

# game/script.rpy:1431
translate Paloslios datedate_2fa00345:

    # centered "{sc=1}{color=#f60808}Silas doesn’t hesitate."
    centered "{sc=1}{color=#f60808}Silas no duda."

# game/script.rpy:1435
translate Paloslios datedate_2b90acba:

    # "He walks right past the tables near the entrance and chooses a booth tucked far in the back."
    "Pasa junto a las mesas cerca de la entrada y elige un reservado escondido en la parte de atrás."

# game/script.rpy:1436
translate Paloslios datedate_5546a347:

    # "The one nearly hidden behind a partition wall, half in shadow."
    "El que estaba casi escondido detrás de un tabique, medio en la sombra."

# game/script.rpy:1437
translate Paloslios datedate_114156da:

    # "Out of sight."
    "Fuera de la vista."

# game/script.rpy:1438
translate Paloslios datedate_7a310200:

    # "He slides into the seat across from me like this is a perfectly ordinary outing."
    "Se desliza en el asiento frente a mí como si ésta fuera una salida perfectamente normal."

# game/script.rpy:1439
translate Paloslios datedate_62ac47e5:

    # "I sit slowly, every muscle tight, the vinyl booth cold under my palms."
    "Me siento lentamente, con todos los músculos tensos y la cabina de vinilo fría bajo mis palmas."

# game/script.rpy:1440
translate Paloslios datedate_d82b4464:

    # "For a moment, it’s just the hum of the neon sign and the faint clatter of the kitchen."
    "Por un momento, es sólo el zumbido del letrero de neón y el leve ruido de la cocina."

# game/script.rpy:1441
translate Paloslios datedate_698752aa:

    # "Then the waitress arrives."
    "Entonces llega la camarera."

# game/script.rpy:1442
translate Paloslios datedate_c36505d0:

    # "She brightens the second she sees him."
    "Ella se ilumina en el momento en que lo ve."

# game/script.rpy:1444
translate Paloslios datedate_1e111316:

    # w "Oh ! Hi again, sweetie, back so soon ? Want your usual ?"
    w "Oh ! Hola de nuevo cariño, ¿has vuelto tan pronto? ¿Quieres lo de siempre?"

# game/script.rpy:1445
translate Paloslios datedate_0eddcdf7:

    # "He leans his cheek into his hand, voice softening mischievously."
    "Él apoya su mejilla en su mano y su voz se suaviza con picardía."

# game/script.rpy:1447
translate Paloslios datedate_9199fa51:

    # voice silas_v95
    # c "Oh, Dolly, you know I come back to this place just for your perfect smile."
    voice silas_v95
    c "Oh, Dolly, sabes que vuelvo a este lugar sólo por tu sonrisa perfecta."

# game/script.rpy:1449
translate Paloslios datedate_57021f44:

    # "She giggles- Actually giggles like an idiot."
    "Ella se ríe... En realidad se ríe como una idiota."

# game/script.rpy:1450
translate Paloslios datedate_5c903693:

    # "Oh gosh, I want to kill myself right now."
    "Dios mío, quiero suicidarme ahora mismo."

# game/script.rpy:1453
translate Paloslios datedate_7764b178:

    # voice silas_v96
    # c "I’m trying something new today."
    voice silas_v96
    c "Estoy probando algo nuevo hoy."

# game/script.rpy:1455
translate Paloslios datedate_8dc7fe81:

    # "He glances at me with a sly, amused glint."
    "Me mira con un brillo astuto y divertido."

# game/script.rpy:1458
translate Paloslios datedate_c9681c86:

    # voice silas_v97
    # c "I’ll take some water. And they’ll have a smoothie. Mango flavored."
    voice silas_v97
    c "Tomaré un poco de agua. Y tomarán un batido. Con sabor a mango."

# game/script.rpy:1461
translate Paloslios datedate_ec38caf8:

    # "The waitress nods cheerfully, jotting it down."
    "La camarera asiente alegremente y lo toma nota."

# game/script.rpy:1462
translate Paloslios datedate_00dd2629:

    # w "Coming right up !"
    w "¡Ya viene!"

# game/script.rpy:1463
translate Paloslios datedate_320e4e23:

    # "She leaves with a bounce in her step."
    "Ella se va con un rebote en su paso."

# game/script.rpy:1464
translate Paloslios datedate_87c16be2:

    # "The second she’s out of earshot, my breath finally rips free."
    "En el momento en que ella está fuera del alcance del oído, mi aliento finalmente se libera."

# game/script.rpy:1466
translate Paloslios datedate_cf2a30ec:

    # mc "What the hell is wrong with you ?"
    mc "¿Qué diablos te pasa?"

# game/script.rpy:1467
translate Paloslios datedate_c4198394:

    # mc "This isn’t the weirdest thing you’ve done, but also- Why mango ?"
    mc "Esto no es lo más raro que has hecho, pero también... ¿Por qué mango?"

# game/script.rpy:1470
translate Paloslios datedate_c019b415:

    # voice silas_v98
    # c "Mango smoothie sucks here, I don't like it, so I hope you'll hate it."
    voice silas_v98
    c "El batido de mango apesta aquí, no me gusta, así que espero que lo odies."

# game/script.rpy:1472
translate Paloslios datedate_08cdfc49:

    # mc "You’re a fucking freak."
    mc "Eres un maldito fenómeno."

# game/script.rpy:1473
translate Paloslios datedate_435e4ba3:

    # mc "Why are we here ?"
    mc "¿Por qué estamos aquí?"

# game/script.rpy:1476
translate Paloslios datedate_ce62f9eb:

    # "My voice cracks between anger and fear."
    "Mi voz se quiebra entre la ira y el miedo."

# game/script.rpy:1479
translate Paloslios datedate_16c4e728:

    # "He doesn’t flinch."
    "Él no se inmuta."

# game/script.rpy:1480
translate Paloslios datedate_ceafdb2d:

    # "He doesn’t stop smiling."
    "No deja de sonreír."

# game/script.rpy:1481
translate Paloslios datedate_242f7131:

    # "If anything, the question seems to please him."
    "En todo caso, la pregunta parece complacerle."

# game/script.rpy:1482
translate Paloslios datedate_2e5855a9:

    # "He rests his elbows on the table, leaning forward just a little."
    "Apoya los codos sobre la mesa, inclinándose un poco hacia adelante."

# game/script.rpy:1483
translate Paloslios datedate_48ad1159:

    # "He says gently, as if explaining something to a child."
    "Dice suavemente, como si le explicara algo a un niño."

# game/script.rpy:1486
translate Paloslios datedate_c1f145bc:

    # voice silas_v99
    # c "Because this is where we had fun last time."
    voice silas_v99
    c "Porque aquí es donde nos divertimos la última vez."

# game/script.rpy:1488
translate Paloslios datedate_28e28446:

    # voice silas_v100
    # c "{i}And you [name], are very good company."
    voice silas_v100
    c "{i}Y tú [name], eres muy buena compañía."

# game/script.rpy:1492
translate Paloslios datedate_69d36b96:

    # mc "You shoved me against a wall and broke my front door. I do not share the same feeling."
    mc "Me empujaste contra una pared y rompiste la puerta de entrada. No comparto el mismo sentimiento."

# game/script.rpy:1495
translate Paloslios datedate_a9df3a2f:

    # mc "I couldn't find how you escaped and it made me so paranoid I had to move apartments. I do not share the feeling."
    mc "No pude encontrar cómo escapaste y me puso tan paranoico que tuve que mudarme de apartamento. No comparto el sentimiento."

# game/script.rpy:1498
translate Paloslios datedate_1034c7e5:

    # mc "I couldn't live in my apartment with the fear that you could one day come back and attack me. I do not share the feeling."
    mc "No podía vivir en mi apartamento con el miedo de que algún día pudieras volver y atacarme. No comparto el sentimiento."

# game/script.rpy:1499
translate Paloslios datedate_08a00d27:

    # voice silas_v101
    # c "Oh, so you thought of me ? That's touching."
    voice silas_v101
    c "Oh, ¿entonces pensaste en mí? Eso es conmovedor."

# game/script.rpy:1503
translate Paloslios datedate_e30ce636:

    # mc "If you intend to make fun of me all evening, I would rather go."
    mc "Si pretendes burlarte de mí toda la noche, preferiría irme."

# game/script.rpy:1506
translate Paloslios datedate_56e54a1a:

    # voice silas_v102
    # c "I want to talk."
    voice silas_v102
    c "quiero hablar"

# game/script.rpy:1508
translate Paloslios datedate_f783ca83:

    # mc "Oh, sure, let me just pull up my recorder, I know people who would love to hear from you... {sc=2}THE COPS WHO ARE WORKING ON YOUR CASE {/sc}!!"
    mc "Oh, claro, déjame sacar mi grabadora, conozco gente a la que le encantaría saber de ti... {sc=2}¡¡LOS POLICÍAS QUE ESTÁN TRABAJANDO EN TU CASO {/sc}!!"

# game/script.rpy:1509
translate Paloslios datedate_833916e6:

    # mc "And why do you look like that !? You look ridiculous with blue hair."
    mc "¿¡Y por qué te ves así!? Te ves ridícula con el pelo azul."

# game/script.rpy:1510
translate Paloslios datedate_b8a147da:

    # voice silas_v103
    voice silas_v103

# game/script.rpy:1513
translate Paloslios datedate_3bb98cf1:

    # c "You think I look hot."
    c "Crees que luzco sexy."

# game/script.rpy:1514
translate Paloslios datedate_f886b46c:

    # mc "What- the fuck ? I didn't say that, Silas."
    mc "¿Qué carajo? Yo no dije eso, Silas."

# game/script.rpy:1515
translate Paloslios datedate_965ea018:

    # mc "That's not even your real name, I shouldn't call you that..."
    mc "Ese ni siquiera es tu verdadero nombre, no debería llamarte así..."

# game/script.rpy:1518
translate Paloslios datedate_f846885f:

    # voice silas_v104
    # c "Man, I feel bad for the guy you mistook me for. Who named their kid Silas ? That's a wack ass name."
    voice silas_v104
    c "Hombre, me siento mal por el tipo con el que me confundiste. ¿Quién llamó a su hijo Silas? Ese es un nombre loco."

# game/script.rpy:1520
translate Paloslios datedate_56de79ef:

    # mc "Hey, don't talk about him that way !"
    mc "¡Oye, no hables de él de esa manera!"

# game/script.rpy:1521
translate Paloslios datedate_0f1ae8a0:

    # voice silas_v105
    voice silas_v105

# game/script.rpy:1524
translate Paloslios datedate_a9ef98e6:

    # c "Oh, sorry, I made fun of your pretty boyfriend. That’s soooo mean."
    c "Oh, lo siento, me burlé de tu lindo novio. Eso es muy malo."

# game/script.rpy:1527
translate Paloslios datedate_2b35b6fe:

    # mc "..."
    mc "..."

# game/script.rpy:1528
translate Paloslios datedate_d19f855d:

    # c "..."
    c "..."

# game/script.rpy:1531
translate Paloslios datedate_10d0e743:

    # voice silas_v106
    # c "Don't tell me you guys broke up ?"
    voice silas_v106
    c "¿No me digan que rompieron?"

# game/script.rpy:1536
translate Paloslios datedate_2b35b6fe_1:

    # mc "..."
    mc "..."

# game/script.rpy:1537
translate Paloslios datedate_bab1b3fd:

    # voice silas_v107
    voice silas_v107

# game/script.rpy:1540
translate Paloslios datedate_a12080e7:

    # c "Let me guess... Even he didn't like you ? Doesn't surprise me, but it's funny nonetheless."
    c "Déjame adivinar... ¿Ni siquiera a él le agradaste? No me sorprende, pero aun así es divertido."

# game/script.rpy:1543
translate Paloslios datedate_2b35b6fe_2:

    # mc "..."
    mc "..."

# game/script.rpy:1544
translate Paloslios datedate_3d60d11e:

    # mc "We were never together to begin with..."
    mc "Para empezar, nunca estuvimos juntos..."

# game/script.rpy:1550
translate Paloslios datedate_373fbf55:

    # voice silas_v108
    # c "Oh, you just made my day ! You know what, you get a prize for being so hilarious."
    voice silas_v108
    c "¡Oh, acabas de alegrarme el día! ¿Sabes qué? Obtienes un premio por ser tan divertido."

# game/script.rpy:1558
translate Paloslios name_convos_655fdf7f:

    # voice silas_v109
    # c "My name is Damien"
    voice silas_v109
    c "mi nombre es damián"

# game/script.rpy:1562
translate Paloslios name_convos_5d7e0fda:

    # voice silas_v110
    # c "My name is Sylvain."
    voice silas_v110
    c "Mi nombre es Sylvain."

# game/script.rpy:1567
translate Paloslios name_convos_b5fce11b:

    # voice silas_v111
    # c "My name is Felix."
    voice silas_v111
    c "Mi nombre es Félix."

# game/script.rpy:1572
translate Paloslios name_convos_82abae30:

    # voice silas_v113
    # c "My name is Hugo."
    voice silas_v113
    c "Mi nombre es Hugo."

# game/script.rpy:1576
translate Paloslios name_convos_6d2ff85b:

    # voice silas_v112
    # c "My name is Mathéo."
    voice silas_v112
    c "Mi nombre es Matheo."

# game/script.rpy:1579
translate Paloslios name_convos_8ca1bcae:

    # "That probably not his real name..."
    "Probablemente ese no sea su verdadero nombre..."

# game/script.rpy:1580
translate Paloslios name_convos_bc87a503:

    # mc "The name doesn't suit you."
    mc "El nombre no te conviene."

# game/script.rpy:1583
translate Paloslios name_convos_fae0e1fe:

    # voice silas_v114
    # c "Hey, don’t insult my mother’s choice, she does love me."
    voice silas_v114
    c "Oye, no insultes la elección de mi madre, ella sí me ama."

# game/script.rpy:1585
translate Paloslios name_convos_213710c9:

    # mc "I’m sure that’s not even your name."
    mc "Estoy seguro de que ni siquiera es tu nombre."

# game/script.rpy:1586
translate Paloslios name_convos_e5557355:

    # voice silas_v115
    # c "..."
    voice silas_v115
    c "..."

# game/script.rpy:1589
translate Paloslios name_convos_e8872cd1:

    # voice silas_v116
    voice silas_v116

# game/script.rpy:1592
translate Paloslios name_convos_f0e5f7f1:

    # c "I won’t ever talk to you again after today."
    c "No volveré a hablar contigo después de hoy."

# game/script.rpy:1593
translate Paloslios name_convos_03b32f00:

    # "He lifts the glass to his lips and takes a slow sip, as if he hasn’t just said something that makes my pulse spike painfully in my ears."
    "Se lleva el vaso a los labios y toma un sorbo lento, como si no acabara de decir algo que hace que mi pulso se acelere dolorosamente en mis oídos."

# game/script.rpy:1596
translate Paloslios name_convos_f3cff21c:

    # voice silas_v118
    # c "My gift, as a thank you for the fun."
    voice silas_v118
    c "Mi regalo, como agradecimiento por la diversión."

# game/script.rpy:1598
translate Paloslios name_convos_31b079a3:

    # "His gaze drifts over my face, lingering in a way that feels invasive, like he’s cataloguing every reaction."
    "Su mirada recorre mi rostro, deteniéndose de una manera que parece invasiva, como si estuviera catalogando cada reacción."

# game/script.rpy:1599
translate Paloslios name_convos_492aa1e6:

    # voice silas_v119
    voice silas_v119

# game/script.rpy:1602
translate Paloslios name_convos_28ec1244:

    # c "So if you have questions, you should start asking them instead of wasting time."
    c "Entonces, si tienes preguntas, deberías empezar a hacerlas en lugar de perder el tiempo."

# game/script.rpy:1604
translate Paloslios name_convos_63cb4a2f:

    # "My hands tighten under the table, digging my nails into my palms, grounding myself in the sting."
    "Mis manos se aprietan debajo de la mesa, clavándome las uñas en las palmas, arraigándome en el aguijón."

# game/script.rpy:1605
translate Paloslios name_convos_51fcf635:

    # mc "Why would I believe anything you say ?"
    mc "¿Por qué iba a creer cualquier cosa que digas?"

# game/script.rpy:1606
translate Paloslios name_convos_7a9e52e3:

    # voice silas_v120
    voice silas_v120

# game/script.rpy:1609
translate Paloslios name_convos_7196db0a:

    # c "Oh, you shouldn’t."
    c "Oh, no deberías."

# game/script.rpy:1610
translate Paloslios name_convos_3e48eb02:

    # "He leans forward a little, lowering his voice-not enough that someone wouldn’t be able to hear us, but enough that it feels like he’s pulling me into something private."
    "Se inclina un poco hacia adelante y baja la voz, no lo suficiente como para que alguien no pueda escucharnos, pero sí lo suficiente como para que parezca que me está arrastrando a algo privado."

# game/script.rpy:1611
translate Paloslios name_convos_df5302c0:

    # voice silas_v121
    voice silas_v121

# game/script.rpy:1614
translate Paloslios name_convos_ec95bfb7:

    # c "But you will."
    c "Pero lo harás."

# game/script.rpy:1615
translate Paloslios name_convos_248f3f3e:

    # voice silas_v122
    voice silas_v122

# game/script.rpy:1618
translate Paloslios name_convos_c54e852c:

    # c "Because you hate not knowing. Because uncertainty gnaws at you worse than fear ever did."
    c "Porque odias no saberlo. Porque la incertidumbre te carcome más que el miedo."

# game/script.rpy:1619
translate Paloslios name_convos_42781530:

    # voice silas_v124
    # c "You’ve been replaying that night for months. Trying to find the moment where everything went wrong. "
    voice silas_v124
    c "Has estado repitiendo esa noche durante meses. Tratando de encontrar el momento en el que todo salió mal. "

# game/script.rpy:1621
translate Paloslios name_convos_b312d557:

    # voice silas_v123
    voice silas_v123

# game/script.rpy:1624
translate Paloslios name_convos_396aa999:

    # c "Trying to figure out how someone like me slipped past you."
    c "Tratando de descubrir cómo alguien como yo se te escapó."

# game/script.rpy:1625
translate Paloslios name_convos_52365659:

    # voice silas_v125
    voice silas_v125

# game/script.rpy:1628
translate Paloslios name_convos_d92b37d3:

    # c "{sc=1}How didn't I see it coming ? Why would someone do that? Who was it ? Will I be able to sleep tonight ?"
    c "{sc=1}¿Cómo no lo vi venir? ¿Por qué alguien haría eso? ¿Quién fue? ¿Podré dormir esta noche?"

# game/script.rpy:1629
translate Paloslios name_convos_33f37464:

    # "My throat tightens."
    "Mi garganta se aprieta."

# game/script.rpy:1630
translate Paloslios name_convos_b2c2d286:

    # voice silas_v126
    voice silas_v126

# game/script.rpy:1633
translate Paloslios name_convos_a9fdaa33:

    # c "I’m just offering you closure."
    c "Sólo te estoy ofreciendo un cierre."

# game/script.rpy:1634
translate Paloslios name_convos_12ffd920:

    # voice silas_v127
    voice silas_v127

# game/script.rpy:1637
translate Paloslios name_convos_97a8fc1b:

    # c "That’s generous, don’t you think ?"
    c "Eso es generoso, ¿no crees?"

# game/script.rpy:1638
translate Paloslios name_convos_6e1348f2:

    # mc "Why now ?"
    mc "¿Por qué ahora?"

# game/script.rpy:1639
translate Paloslios name_convos_27c5635f:

    # voice silas_v128
    voice silas_v128

# game/script.rpy:1642
translate Paloslios name_convos_a40c4316:

    # c "Because I ran into you... Also because you looked like you’d finally convinced yourself you were safe."
    c "Porque me encontré contigo... También porque parecía que finalmente te habías convencido de que estabas a salvo."

# game/script.rpy:1643
translate Paloslios name_convos_70db5b7b:

    # voice silas_v129
    # c "You rebuilt yourself."
    voice silas_v129
    c "Te reconstruiste a ti mismo."

# game/script.rpy:1645
translate Paloslios name_convos_d566253a:

    # "He continues, leaning back again, stretching his arms along the back of the booth like he owns the space."
    "Continúa, inclinándose hacia atrás de nuevo, estirando los brazos a lo largo de la parte trasera de la cabina como si fuera el dueño del espacio."

# game/script.rpy:1646
translate Paloslios name_convos_2b68f434:

    # voice silas_v130
    voice silas_v130

# game/script.rpy:1649
translate Paloslios name_convos_8fb60ce3:

    # c "You did it, you moved on. A whole life that didn’t include me."
    c "Lo hiciste, seguiste adelante. Toda una vida que no me incluía."

# game/script.rpy:1650
translate Paloslios name_convos_aa957a88:

    # "He lets out a quiet, amused breath."
    "Deja escapar un suspiro tranquilo y divertido."

# game/script.rpy:1651
translate Paloslios name_convos_0638b750:

    # voice silas_v131
    voice silas_v131

# game/script.rpy:1654
translate Paloslios name_convos_400e10a4:

    # c "I find that lame."
    c "Eso me parece tonto."

# game/script.rpy:1655
translate Paloslios name_convos_305b3a14:

    # "My heart pounds violently as I struggle to find my voice."
    "Mi corazón late violentamente mientras lucho por encontrar mi voz."

# game/script.rpy:1656
translate Paloslios name_convos_440ea475:

    # mc "What are you ?"
    mc "Qué vas a ?"

# game/script.rpy:1657
translate Paloslios name_convos_361251e3:

    # "The question slips out before I can stop it, heavy and fragile all at once."
    "La pregunta se me escapa antes de que pueda detenerla, pesada y frágil a la vez."

# game/script.rpy:1660
translate Paloslios name_convos_bc35f790:

    # "He blinks."
    "Él parpadea."

# game/script.rpy:1663
translate Paloslios name_convos_d1cbf0ad:

    # "Then he laughs."
    "Luego se ríe."

# game/script.rpy:1664
translate Paloslios name_convos_036c5ebf:

    # "It’s a real laugh, bright, sharp, delighted, as if I’ve just said something incredibly entertaining."
    "Es una risa real, brillante, aguda, encantada, como si acabara de decir algo increíblemente entretenido."

# game/script.rpy:1665
translate Paloslios name_convos_4c14fa19:

    # voice silas_v132
    voice silas_v132

# game/script.rpy:1668
translate Paloslios name_convos_914ded40:

    # c "That’s a big one question ! You sure you don’t want to start smaller ?"
    c "¡Esa es una gran pregunta! ¿Estás seguro de que no quieres empezar con algo más pequeño?"

# game/script.rpy:1669
translate Paloslios name_convos_7a7e75e0:

    # "He leans forward again, elbows resting on the table now, his voice dropping into something dangerously calm."
    "Se inclina hacia adelante de nuevo, ahora con los codos apoyados en la mesa, y su voz adquiere un tono peligrosamente tranquilo."

# game/script.rpy:1670
translate Paloslios name_convos_3ec07d4c:

    # voice silas_v133
    voice silas_v133

# game/script.rpy:1673
translate Paloslios name_convos_c35d02e1:

    # c "Like how I knew where you lived ? How long have I been reading your messages before you ever noticed me ?"
    c "¿Cómo supe dónde vivías? ¿Cuánto tiempo llevo leyendo tus mensajes antes de que te hayas dado cuenta de mí?"

# game/script.rpy:1674
translate Paloslios name_convos_974be65d:

    # voice silas_v134
    voice silas_v134

# game/script.rpy:1677
translate Paloslios name_convos_02b757aa:

    # c "Pick one question."
    c "Elija una pregunta."

# game/script.rpy:1678
translate Paloslios name_convos_23da3e37:

    # voice silas_v135
    # c "You earned that much."
    voice silas_v135
    c "Ganaste tanto."

# game/script.rpy:1682
translate Paloslios name_convos_4b14a3ce:

    # "The waitress retuns then, her presence jarring and painfully normal."
    "La camarera regresa entonces, su presencia discordante y dolorosamente normal."

# game/script.rpy:1683
translate Paloslios name_convos_4ad9121e:

    # "She slides the drinks onto the table with a smile that doesn’t belong at this moment."
    "Desliza las bebidas sobre la mesa con una sonrisa que no pertenece a este momento."

# game/script.rpy:1684
translate Paloslios name_convos_375ac427:

    # w "Mango smoothie and water !"
    w "¡Batido de mango y agua!"

# game/script.rpy:1685
translate Paloslios name_convos_84fa9a78:

    # "She beams at him."
    "Ella le sonríe."

# game/script.rpy:1686
translate Paloslios name_convos_8330f732:

    # w "Enjoy !"
    w "Disfrutar !"

# game/script.rpy:1687
translate Paloslios name_convos_99969960:

    # "And she leaves again."
    "Y ella se va de nuevo."

# game/script.rpy:1688
translate Paloslios name_convos_12a32a3a:

    # "He glances at the glass in front of me, then back at my face."
    "Mira el vaso frente a mí y luego vuelve a mirarme a la cara."

# game/script.rpy:1689
translate Paloslios name_convos_ee4bb2eb:

    # voice silas_v136
    voice silas_v136

# game/script.rpy:1691
translate Paloslios name_convos_48943783:

    # c "You should drink that. Before it melts."
    c "Deberías beber eso. Antes de que se derrita."

# game/script.rpy:1692
translate Paloslios name_convos_7629a10f:

    # "My stomach churns."
    "Mi estómago se revuelve."

# game/script.rpy:1693
translate Paloslios name_convos_9e883eb7:

    # mc "I’m not thirsty."
    mc "No tengo sed."

# game/script.rpy:1694
translate Paloslios name_convos_7e3a903c:

    # voice silas_v137
    voice silas_v137

# game/script.rpy:1697
translate Paloslios name_convos_80a95a98:

    # c "That wasn’t a suggestion."
    c "Esa no fue una sugerencia."

# game/script.rpy:1699
translate Paloslios name_convos_f9d0ec48:

    # "The mango smoothie sits between us, bright, artificial, painfully cheerful."
    "El batido de mango se encuentra entre nosotros, brillante, artificial, dolorosamente alegre."

# game/script.rpy:1703
translate Paloslios name_convos_42f2c5a1:

    # "My hand shakes as I reach for the glass."
    "Mi mano tiembla cuando alcanzo el vaso."

# game/script.rpy:1704
translate Paloslios name_convos_e894ff0a:

    # "It’s colder than I expected. My fingers stiffen around it."
    "Hace más frío de lo que esperaba. Mis dedos se ponen rígidos a su alrededor."

# game/script.rpy:1705
translate Paloslios name_convos_4d5b0f5e:

    # "I bring the straw to my lips and take a sip."
    "Me llevo la pajita a los labios y tomo un sorbo."

# game/script.rpy:1706
translate Paloslios name_convos_5ec6faca:

    # "The sweetness floods my mouth, thick and cloying, turning my stomach."
    "La dulzura inunda mi boca, espesa y empalagosa, revolviéndome el estómago."

# game/script.rpy:1707
translate Paloslios name_convos_a4ebed3a:

    # "He watches closely."
    "Él observa de cerca."

# game/script.rpy:1708
translate Paloslios name_convos_8870e858:

    # "My throat tightens as I swallow."
    "Mi garganta se aprieta mientras trago."

# game/script.rpy:1709
translate Paloslios name_convos_e65d7054:

    # "He doesn’t look away until I lower the glass."
    "No aparta la mirada hasta que bajo el vaso."

# game/script.rpy:1711
translate Paloslios name_convos_bbc59082:

    # voice silas_v138
    # c "Okay, drinks are done, time for the questions."
    voice silas_v138
    c "Bien, se terminaron las bebidas, es hora de las preguntas."

# game/script.rpy:1715
translate Paloslios name_convos_6a20a80d:

    # "I shake my head."
    "Sacudo la cabeza."

# game/script.rpy:1717
translate Paloslios name_convos_6587d5a2:

    # "For a moment, he just stares at me."
    "Por un momento, él simplemente me mira fijamente."

# game/script.rpy:1720
translate Paloslios name_convos_d0ba7413:

    # "Then he laughs quietly."
    "Luego se ríe en voz baja."

# game/script.rpy:1721
translate Paloslios name_convos_c9d1e611:

    # voice silas_v139
    # c "Suit yourself."
    voice silas_v139
    c "Haz lo que quieras."

# game/script.rpy:1724
translate Paloslios name_convos_96442a63:

    # "He reaches across the table, fingers closing around the glass, and pulls it toward him."
    "Se acerca a la mesa, cierra los dedos alrededor del vaso y lo acerca hacia él."

# game/script.rpy:1725
translate Paloslios name_convos_c722ea01:

    # "He takes a long sip."
    "Toma un largo sorbo."

# game/script.rpy:1726
translate Paloslios name_convos_f619ffcf:

    # "His face twists immediately."
    "Su rostro se tuerce inmediatamente."

# game/script.rpy:1727
translate Paloslios name_convos_2b3bdad2:

    # voice silas_v140
    voice silas_v140

# game/script.rpy:1729
translate Paloslios name_convos_71cb3ec0:

    # c "Ugh... Still disgusting."
    c "Uf... Sigue siendo repugnante."

# game/script.rpy:1730
translate Paloslios name_convos_d2c539be:

    # "He sets it down with a soft clink."
    "Lo deja con un suave tintineo."

# game/script.rpy:1731
translate Paloslios name_convos_1b785d65:

    # voice silas_v141
    # c "I actually hate smoothies."
    voice silas_v141
    c "De hecho, odio los batidos."

# game/script.rpy:1733
translate Paloslios name_convos_591dfa75:

    # "He wipes his mouth with the back of his hand."
    "Se limpia la boca con el dorso de la mano."

# game/script.rpy:1736
translate Paloslios name_convos_0f2626d5:

    # voice silas_v142
    # c "Drinking something this cold is completely unnecessary."
    voice silas_v142
    c "Beber algo tan frío es completamente innecesario."

# game/script.rpy:1738
translate Paloslios name_convos_b93022fc:

    # "He looks back at me."
    "Él me mira."

# game/script.rpy:1739
translate Paloslios name_convos_73dcbd83:

    # voice silas_v143
    voice silas_v143

# game/script.rpy:1742
translate Paloslios name_convos_80a1487b:

    # c "If you don't intend to drink, then let's start with the questions."
    c "Si no tiene intención de beber, comencemos con las preguntas."

# game/script.rpy:1744
translate Paloslios name_convos_f2d94c52:

    # voice silas_v144
    voice silas_v144

# game/script.rpy:1747
translate Paloslios name_convos_0e32c0db:

    # c "Well ?"
    c "Bien ?"

# game/script.rpy:1761
translate Paloslios me_5c740751:

    # "The words leave my mouth before I can soften them."
    "Las palabras salen de mi boca antes de que pueda suavizarlas."

# game/script.rpy:1762
translate Paloslios me_f13ea009:

    # mc "{i}Why me ?"
    mc "{i}¿Por qué yo?"

# game/script.rpy:1763
translate Paloslios me_25e1e0a5:

    # "He pauses."
    "Hace una pausa."

# game/script.rpy:1764
translate Paloslios me_2764e6b5:

    # "Just long enough to look... mildly surprised ?"
    "El tiempo suficiente para parecer... ¿ligeramente sorprendido?"

# game/script.rpy:1766
translate Paloslios me_b5740ee7:

    # voice silas_v146
    # c "Ah, that one..."
    voice silas_v146
    c "Ah, ese..."

# game/script.rpy:1768
translate Paloslios me_72d30a10:

    # "He leans back in the booth, crossing his arms loosely, eyes drifting toward the ceiling as if he’s replaying an unremarkable memory."
    "Se recuesta en la cabina, cruza los brazos libremente y mira hacia el techo como si estuviera repitiendo un recuerdo sin importancia."

# game/script.rpy:1769
translate Paloslios me_0dad67b8:

    # voice silas_v147
    voice silas_v147

# game/script.rpy:1772
translate Paloslios me_1693ae9c:

    # c "I was on my way to a friend’s place. Late, as usual. I wasn’t looking for anything, let alone planning anything."
    c "Estaba de camino a casa de un amigo. Tarde, como siempre. No estaba buscando nada, y mucho menos planeando nada."

# game/script.rpy:1773
translate Paloslios me_d010bc68:

    # "His gaze comes back to me."
    "Su mirada vuelve a mí."

# game/script.rpy:1774
translate Paloslios me_9ce6298e:

    # voice silas_v148
    # c "You were just there."
    voice silas_v148
    c "Estabas justo ahí."

# game/script.rpy:1776
translate Paloslios me_5e3e8f53:

    # "The words hit harder than I expected."
    "Las palabras golpearon más fuerte de lo que esperaba."

# game/script.rpy:1777
translate Paloslios me_a045e24b:

    # voice silas_v149
    voice silas_v149

# game/script.rpy:1780
translate Paloslios me_e4a04680:

    # c "I didn’t wake up thinking today I’ll ruin someone’s life."
    c "No me desperté pensando que hoy le arruinaré la vida a alguien."

# game/script.rpy:1781
translate Paloslios me_a717b836:

    # voice silas_v150
    voice silas_v150

# game/script.rpy:1784
translate Paloslios me_c88d102b:

    # c "I did see you in the crowd. You looked distracted. Nervous. Like someone who lives a lot inside their own head."
    c "Te vi entre la multitud. Parecías distraído. Nervioso. Como alguien que vive mucho dentro de su propia cabeza."

# game/script.rpy:1785
translate Paloslios me_9d1135d6:

    # "He tilts his head."
    "Él inclina la cabeza."

# game/script.rpy:1786
translate Paloslios me_f401acb6:

    # voice silas_v151
    voice silas_v151

# game/script.rpy:1789
translate Paloslios me_33e04d1e:

    # c "And then you approached me."
    c "Y luego te acercaste a mí."

# game/script.rpy:1790
translate Paloslios me_17df0a8d:

    # "I swallow."
    "Trago."

# game/script.rpy:1791
translate Paloslios me_b76961b6:

    # voice silas_v152
    voice silas_v152

# game/script.rpy:1794
translate Paloslios me_92cb34cb:

    # c "So no, you’re not special."
    c "Entonces no, no eres especial."

# game/script.rpy:1795
translate Paloslios me_3f9289f6:

    # mc "Not even to you ?"
    mc "¿Ni siquiera para ti?"

# game/script.rpy:1796
translate Paloslios me_60b85729:

    # "I hate how this is the first thing I dared to say."
    "Odio que esto sea lo primero que me atreví a decir."

# game/script.rpy:1799
translate Paloslios me_bb69a053:

    # voice silas_v153
    # c "No."
    voice silas_v153
    c "No."

# game/script.rpy:1801
translate Paloslios me_17c5fbd3:

    # "He takes a sip of his water."
    "Toma un sorbo de su agua."

# game/script.rpy:1802
translate Paloslios me_2d0a90b6:

    # voice silas_v154
    voice silas_v154

# game/script.rpy:1805
translate Paloslios me_0c4cb455:

    # c "You wanna know what I did that night ?"
    c "¿Quieres saber qué hice esa noche?"

# game/script.rpy:1806
translate Paloslios me_c2d2cf4c:

    # voice silas_v155
    # c "I went to a party, drank cheap beer, and made out with like four people. And then I moved on."
    voice silas_v155
    c "Fui a una fiesta, bebí cerveza barata y me besé con unas cuatro personas. Y luego seguí adelante."

# game/script.rpy:1808
translate Paloslios me_2ac41b0c:

    # "He watches my reaction closely."
    "Él observa mi reacción de cerca."

# game/script.rpy:1809
translate Paloslios me_2b00b090:

    # voice silas_v156
    voice silas_v156

# game/script.rpy:1812
translate Paloslios me_b533b12f:

    # c "You’re the only one who didn’t."
    c "Eres el único que no lo hizo."

# game/script.rpy:1817
translate Paloslios lieday_9c1dbd53:

    # "The question burns on my tongue."
    "La pregunta arde en mi lengua."

# game/script.rpy:1818
translate Paloslios lieday_965823a3:

    # mc "How did you lie to me all day ?"
    mc "¿Cómo me mentiste todo el día?"

# game/script.rpy:1819
translate Paloslios lieday_9d1dd57b:

    # "He stares at me for a second."
    "Me mira fijamente por un segundo."

# game/script.rpy:1820
translate Paloslios lieday_e449c9c0:

    # "Then laughs."
    "Luego se ríe."

# game/script.rpy:1821
translate Paloslios lieday_dd410118:

    # "Not loud."
    "No ruidoso."

# game/script.rpy:1822
translate Paloslios lieday_95eb6d64:

    # "Not cruel."
    "No cruel."

# game/script.rpy:1823
translate Paloslios lieday_83c6da99:

    # "Genuinely amused."
    "Realmente divertido."

# game/script.rpy:1825
translate Paloslios lieday_6b8253a1:

    # voice silas_v157
    # c "That’s barely a question. It’s easy !"
    voice silas_v157
    c "Eso es apenas una pregunta. ¡Es fácil!"

# game/script.rpy:1827
translate Paloslios lieday_c3b60cea:

    # "My fingers dig into the edge of the table."
    "Mis dedos se hunden en el borde de la mesa."

# game/script.rpy:1828
translate Paloslios lieday_4316ea7a:

    # mc "Easy ?"
    mc "Fácil ?"

# game/script.rpy:1829
translate Paloslios lieday_4bd8fb8a:

    # voice silas_v158
    voice silas_v158

# game/script.rpy:1832
translate Paloslios lieday_9e36b338:

    # c "Yes, you just say things. Confidently. People fill in the rest."
    c "Sí, solo dices cosas. Con confianza. La gente completa el resto."

# game/script.rpy:1833
translate Paloslios lieday_35846516:

    # "My stomach turns."
    "Mi estómago se revuelve."

# game/script.rpy:1834
translate Paloslios lieday_6beadfd6:

    # mc "Did you know about the meeting ?"
    mc "¿Sabías de la reunión?"

# game/script.rpy:1835
translate Paloslios lieday_27e859ea:

    # mc "About Silas ? About me waiting there ?"
    mc "¿Sobre Silas? ¿Sobre mí esperando allí?"

# game/script.rpy:1836
translate Paloslios lieday_705628da:

    # voice silas_v159
    voice silas_v159

# game/script.rpy:1839
translate Paloslios lieday_80cdea86:

    # c "No, not a clue."
    c "No, ni idea."

# game/script.rpy:1840
translate Paloslios lieday_15402e27:

    # "He leans forward, eyes bright with something sharp."
    "Se inclina hacia adelante, con los ojos brillantes por algo afilado."

# game/script.rpy:1841
translate Paloslios lieday_2382ae8e:

    # voice silas_v160
    voice silas_v160

# game/script.rpy:1844
translate Paloslios lieday_0c7b0331:

    # c "I just threw out random answers. Half-truths. Vague reactions. You did all the work for me."
    c "Simplemente tiré respuestas aleatorias. Medias verdades. Reacciones vagas. Hiciste todo el trabajo por mí."

# game/script.rpy:1845
translate Paloslios lieday_94874166:

    # voice silas_v161
    voice silas_v161

# game/script.rpy:1848
translate Paloslios lieday_35998443:

    # c "You were so focused on how you felt that you never stopped to really look at me."
    c "Estabas tan concentrado en cómo te sentías que nunca te detuviste a mirarme realmente."

# game/script.rpy:1849
translate Paloslios lieday_a7f6f8ec:

    # "My voice shakes."
    "Mi voz tiembla."

# game/script.rpy:1850
translate Paloslios lieday_22750dcd:

    # mc "You kissed me !"
    mc "¡Me besaste!"

# game/script.rpy:1851
translate Paloslios lieday_5ca6e924:

    # voice silas_v163
    voice silas_v163

# game/script.rpy:1854
translate Paloslios lieday_3ec2cbed:

    # c "Like that’s hard ? It didn’t mean anything."
    c "¿Eso es difícil? No significó nada."

# game/script.rpy:1855
translate Paloslios lieday_96e620b6:

    # voice silas_v164
    voice silas_v164

# game/script.rpy:1858
translate Paloslios lieday_49d0ea00:

    # c "People kiss strangers all the time."
    c "La gente besa a extraños todo el tiempo."

# game/script.rpy:1859
translate Paloslios lieday_fd6ccf69:

    # voice silas_v165
    voice silas_v165

# game/script.rpy:1862
translate Paloslios lieday_79c2a197:

    # c "You confuse intimacy with significance."
    c "Confundes intimidad con significado."

# game/script.rpy:1863
translate Paloslios lieday_e0715dbc:

    # mc "But-"
    mc "Pero-"

# game/script.rpy:1864
translate Paloslios lieday_dfd80a1a:

    # voice silas_v166
    voice silas_v166

# game/script.rpy:1867
translate Paloslios lieday_e5bea5a9:

    # c "That’s not my problem."
    c "Ese no es mi problema."

# game/script.rpy:1872
translate Paloslios whythat_b85b3353:

    # mc "Why did you do it ?"
    mc "¿Por qué lo hiciste?"

# game/script.rpy:1873
translate Paloslios whythat_b759eadc:

    # "This time, he doesn’t smile right away."
    "Esta vez no sonríe de inmediato."

# game/script.rpy:1874
translate Paloslios whythat_81d4f779:

    # "He studies me instead, fingers tapping idly against the table."
    "En lugar de eso, me estudia y golpea distraídamente la mesa con los dedos."

# game/script.rpy:1875
translate Paloslios whythat_b454bb5c:

    # voice silas_v167
    voice silas_v167

# game/script.rpy:1877
translate Paloslios whythat_be8628e0:

    # c "Poor impulse control, that’s what they call it."
    c "Mal control de los impulsos, así lo llaman."

# game/script.rpy:1878
translate Paloslios whythat_fac42972:

    # "My breath catches."
    "Me quedo sin aliento."

# game/script.rpy:1879
translate Paloslios whythat_2a8c5047:

    # voice silas_v168
    voice silas_v168

# game/script.rpy:1882
translate Paloslios whythat_f94a65aa:

    # c "Specialists, plural. Apparently, I’m missing chunks of empathy."
    c "Especialistas, plural. Aparentemente, me faltan trozos de empatía."

# game/script.rpy:1883
translate Paloslios whythat_02cfca75:

    # "He says it the way someone might talk about a vitamin deficiency."
    "Lo dice del mismo modo que alguien hablaría de una deficiencia de vitaminas."

# game/script.rpy:1884
translate Paloslios whythat_28017d4f:

    # "What the hell ?"
    "Qué demonios ?"

# game/script.rpy:1885
translate Paloslios whythat_cb85ba5c:

    # voice silas_v169
    # c "When the opportunity showed up, I took it. No deeper reason than that."
    voice silas_v169
    c "Cuando se presentó la oportunidad, la aproveché. No hay razón más profunda que esa."

# game/script.rpy:1887
translate Paloslios whythat_0b761860:

    # "His mouth curves into something resembling a grin."
    "Su boca se curva en algo parecido a una sonrisa."

# game/script.rpy:1888
translate Paloslios whythat_a3e3e60b:

    # voice silas_v170
    voice silas_v170

# game/script.rpy:1891
translate Paloslios whythat_f069a3ff:

    # c "It was fun."
    c "Fue divertido."

# game/script.rpy:1892
translate Paloslios whythat_05b43978:

    # "The word lands like a slap."
    "La palabra cae como una bofetada."

# game/script.rpy:1893
translate Paloslios whythat_d58632c0:

    # mc "So that's what I was? Just fun ?!"
    mc "¿Entonces eso es lo que yo era? ¿Simplemente divertido?"

# game/script.rpy:1894
translate Paloslios whythat_7f19b534:

    # voice silas_v171
    voice silas_v171

# game/script.rpy:1897
translate Paloslios whythat_a56cabbc:

    # c "I wanted to see how long I could keep it up. How far I could go before you noticed."
    c "Quería ver cuánto tiempo podría seguir así. Hasta dónde podría llegar antes de que te dieras cuenta."

# game/script.rpy:1898
translate Paloslios whythat_289165cb:

    # "He chuckles."
    "Él se ríe."

# game/script.rpy:1899
translate Paloslios whythat_304b7643:

    # voice silas_v172
    voice silas_v172

# game/script.rpy:1902
translate Paloslios whythat_b2d1ea1c:

    # c "And when it kept working ? When you trusted me more, and more ? It became hilarious !"
    c "¿Y cuando siguió funcionando? ¿Cuando confiaste más en mí, y más? ¡Se volvió hilarante!"

# game/script.rpy:1903
translate Paloslios whythat_5c533ae2:

    # voice silas_v173
    # c "I just waited for the moment you’d finally catch on."
    voice silas_v173
    c "Solo esperé el momento en que finalmente te dieras cuenta."

# game/script.rpy:1905
translate Paloslios whythat_5bb9a8ff:

    # voice silas_v174
    voice silas_v174

# game/script.rpy:1908
translate Paloslios whythat_43a9fd34:

    # c "That being said, it wasn't my favorite moment, kinda lame ending, I'll admit."
    c "Dicho esto, no fue mi momento favorito, lo admito, un final un poco aburrido."

# game/script.rpy:1912
translate Paloslios hurt_7f82d8b7:

    # "The question comes out trembling."
    "La pregunta sale temblorosa."

# game/script.rpy:1913
translate Paloslios hurt_04114389:

    # voice silas_v175
    voice silas_v175

# game/script.rpy:1915
translate Paloslios hurt_e422f806:

    # c "Did I... plan to hurt you ? That night ?"
    c "¿Planeaba... hacerte daño? ¿Esa noche?"

# game/script.rpy:1916
translate Paloslios hurt_b4002846:

    # "He frowns."
    "Él frunce el ceño."

# game/script.rpy:1917
translate Paloslios hurt_375345ed:

    # "Actually frown."
    "En realidad frunce el ceño."

# game/script.rpy:1918
translate Paloslios hurt_84c5b22e:

    # "There’s something almost like disappointment in his eyes."
    "Hay algo casi parecido a la decepción en sus ojos."

# game/script.rpy:1921
translate Paloslios hurt_602e8823:

    # voice silas_v176
    # c "No, ew."
    voice silas_v176
    c "No, uff."

# game/script.rpy:1923
translate Paloslios hurt_cdf72a15:

    # voice silas_v177
    voice silas_v177

# game/script.rpy:1926
translate Paloslios hurt_3a84e35a:

    # c "That doesn’t interest me."
    c "Eso no me interesa."

# game/script.rpy:1927
translate Paloslios hurt_73c50fa6:

    # "I stare at him, confused."
    "Lo miro fijamente, confundida."

# game/script.rpy:1928
translate Paloslios hurt_62dc2eda:

    # voice silas_v178
    voice silas_v178

# game/script.rpy:1931
translate Paloslios hurt_fef15169:

    # c "I wasn’t there to hurt you, I was there to see how far the situation could go. That’s different."
    c "No estaba allí para lastimarte, estaba allí para ver hasta dónde podía llegar la situación. Eso es diferente."

# game/script.rpy:1932
translate Paloslios hurt_2e6b5078:

    # "His gaze drifts briefly, thoughtful."
    "Su mirada se desvía brevemente, pensativa."

# game/script.rpy:1933
translate Paloslios hurt_3cfb71f1:

    # voice silas_v179
    voice silas_v179

# game/script.rpy:1936
translate Paloslios hurt_44b3e77d:

    # c "That being said, I half-expected you to make a move. You boldly invited me to stay. I thought you wanted to sleep with me."
    c "Dicho esto, casi esperaba que hicieras un movimiento. Me invitaste audazmente a quedarme. Pensé que querías dormir conmigo."

# game/script.rpy:1937
translate Paloslios hurt_8e49327e:

    # "My skin crawls."
    "Se me eriza la piel."

# game/script.rpy:1938
translate Paloslios hurt_b20fc637:

    # mc "Would you have ?"
    mc "¿Lo habrías hecho?"

# game/script.rpy:1939
translate Paloslios hurt_49d09a0d:

    # voice silas_v180
    voice silas_v180

# game/script.rpy:1942
translate Paloslios hurt_7e41477a:

    # c "Yes"
    c "si"

# game/script.rpy:1943
translate Paloslios hurt_ae5ef3db:

    # "His lack of hesitation is shameless."
    "Su falta de vacilación es descarada."

# game/script.rpy:1944
translate Paloslios hurt_b364bbe4:

    # voice silas_v181
    # c "And-"
    voice silas_v181
    c "Y-"

# game/script.rpy:1946
translate Paloslios hurt_0b7f6c8e:

    # voice silas_v182
    voice silas_v182

# game/script.rpy:1949
translate Paloslios hurt_565a67d7:

    # c "I probably would’ve called you by another name halfway through."
    c "Probablemente te habría llamado por otro nombre a mitad de camino."

# game/script.rpy:1950
translate Paloslios hurt_e0615bac:

    # "My breath stutters."
    "Mi respiración se entrecorta."

# game/script.rpy:1951
translate Paloslios hurt_689f1edf:

    # voice silas_v183
    voice silas_v183

# game/script.rpy:1954
translate Paloslios hurt_028949e5:

    # c "Just to see your face,"
    c "Sólo para ver tu cara,"

# game/script.rpy:1955
translate Paloslios hurt_266266da:

    # voice silas_v184
    # c "That moment when everything breaks. That’s the part I enjoy."
    voice silas_v184
    c "Ese momento en el que todo se rompe. Esa es la parte que disfruto."

# game/script.rpy:1957
translate Paloslios hurt_60fcfda3:

    # voice silas_v185
    voice silas_v185

# game/script.rpy:1960
translate Paloslios hurt_802c9dd9:

    # c "And that was the only thing I was after."
    c "Y eso era lo único que buscaba."

# game/script.rpy:1968
translate Paloslios commoned_6c467ef7:

    # voice silas_v188
    # c "Anyway."
    voice silas_v188
    c "De todos modos."

# game/script.rpy:1970
translate Paloslios commoned_9d8bee1a:

    # "He glances at his phone."
    "Él mira su teléfono."

# game/script.rpy:1973
translate Paloslios commoned_7c17c5ab:

    # voice silas_v187
    # c "I’m getting hungry. I’ll probably do some grocery shopping for tonight."
    voice silas_v187
    c "Me está entrando hambre. Probablemente haré algunas compras para esta noche."

# game/script.rpy:1975
translate Paloslios commoned_0be63988:

    # "He stands up smoothly, the vinyl seat creaking softly as he slides out of the booth."
    "Se levanta suavemente, el asiento de vinilo cruje suavemente mientras sale de la cabina."

# game/script.rpy:1978
translate Paloslios commoned_9e4914e2:

    # voice silas_v189
    # c "Tell Dolly to put the drinks on my tab, okay ?"
    voice silas_v189
    c "Dile a Dolly que ponga las bebidas en mi cuenta, ¿vale?"

# game/script.rpy:1980
translate Paloslios commoned_ff0d8897:

    # "He pauses, then looks back at me."
    "Hace una pausa y luego me mira."

# game/script.rpy:1981
translate Paloslios commoned_e80a047c:

    # voice silas_v190
    # c "Oh, my name’s {color=#f60808}Mark{/color} here, by the way."
    voice silas_v190
    c "Oh, por cierto, mi nombre es {color=#f60808}Mark{/color}."

# game/script.rpy:1983
translate Paloslios commoned_257d0c3f:

    # voice silas_v191
    # c "Also, I’m moving out next week."
    voice silas_v191
    c "Además, me mudo la próxima semana."

# game/script.rpy:1985
translate Paloslios commoned_4b074331:

    # voice silas_v193
    voice silas_v193

# game/script.rpy:1988
translate Paloslios commoned_1d79d7f5:

    # c "New place, new area, I'll block everyone from my contacts here."
    c "Nuevo lugar, nueva área, bloquearé a todos de mis contactos aquí."

# game/script.rpy:1989
translate Paloslios commoned_77580dd0:

    # voice silas_v192
    # c "I meant what I said earlier. This was the last conversation we’ll ever have."
    voice silas_v192
    c "Quise decir lo que dije antes. Esta fue la última conversación que tendremos."

# game/script.rpy:1991
translate Paloslios commoned_0b8e6f07:

    # voice silas_v194
    voice silas_v194

# game/script.rpy:1994
translate Paloslios commoned_86cefccf:

    # c "You can say one last thing if you want. Else I'm just leaving."
    c "Puedes decir una última cosa si quieres. De lo contrario, simplemente me voy."

# game/script.rpy:1995
translate Paloslios commoned_7a77849e:

    # "He turns fully now, waiting."
    "Ahora se gira completamente, esperando."

# game/script.rpy:2012
translate Paloslios nothingend_08a73c46:

    # "He stands there, waiting."
    "Él se queda allí, esperando."

# game/script.rpy:2013
translate Paloslios nothingend_2579330b:

    # "I swallow, my mouth dry."
    "Trago, tengo la boca seca."

# game/script.rpy:2014
translate Paloslios nothingend_5234e997:

    # "I don’t say a word."
    "No digo una palabra."

# game/script.rpy:2015
translate Paloslios nothingend_e1e2b40e:

    # "I just stare at him, hands curled tight in my lap, chest rising and falling too fast."
    "Solo lo miro fijamente, con las manos apretadas en mi regazo, el pecho subiendo y bajando demasiado rápido."

# game/script.rpy:2016
translate Paloslios nothingend_4c3d20a6:

    # "For a moment, something flickers across his face."
    "Por un momento, algo parpadea en su rostro."

# game/script.rpy:2017
translate Paloslios nothingend_4d365134:

    # "Disappointment."
    "Decepción."

# game/script.rpy:2018
translate Paloslios nothingend_855d4d53:

    # voice silas_v200
    voice silas_v200

# game/script.rpy:2020
translate Paloslios nothingend_25e9635c:

    # c "Right..."
    c "Correcto..."

# game/script.rpy:2021
translate Paloslios nothingend_5bc7f0ea:

    # "He nods once, more to himself than to me."
    "Asiente una vez, más para sí mismo que para mí."

# game/script.rpy:2024
translate Paloslios nothingend_df2e8a2a:

    # voice silas_v201
    # c "Figures."
    voice silas_v201
    c "Figuras."

# game/script.rpy:2027
translate Paloslios nothingend_fe37ef59:

    # "He doesn’t linger."
    "Él no se demora."

# game/script.rpy:2028
translate Paloslios nothingend_d20f1111:

    # "He turns, slips his hands into his pockets, and walks toward the exit without another glance."
    "Se da vuelta, mete las manos en los bolsillos y camina hacia la salida sin volver a mirar."

# game/script.rpy:2029
translate Paloslios nothingend_25a3686b:

    # "The bell above the door chimes softly as it closes behind him."
    "El timbre encima de la puerta suena suavemente mientras se cierra detrás de él."

# game/script.rpy:2034
translate Paloslios hatend_3b3806df:

    # "The words tear out of me before I can soften them."
    "Las palabras salen de mí antes de que pueda suavizarlas."

# game/script.rpy:2035
translate Paloslios hatend_f8f77318:

    # mc "I hate you."
    mc "Te odio."

# game/script.rpy:2036
translate Paloslios hatend_12c172c8:

    # mc "I fucking hate you."
    mc "Te odio, joder."

# game/script.rpy:2037
translate Paloslios hatend_86462a80:

    # mc "You psycho! Go fuck yourself."
    mc "¡Eres un psicópata! Vete a la mierda."

# game/script.rpy:2038
translate Paloslios hatend_bc35f790:

    # "He blinks."
    "Él parpadea."

# game/script.rpy:2039
translate Paloslios hatend_d8626dae:

    # "Then he smiles."
    "Luego sonríe."

# game/script.rpy:2040
translate Paloslios hatend_15edfa04:

    # "Satisfied."
    "Satisfecho."

# game/script.rpy:2041
translate Paloslios hatend_ea3112cd:

    # voice silas_v202
    voice silas_v202

# game/script.rpy:2043
translate Paloslios hatend_0fe0f05a:

    # c "I’d be disappointed if you didn’t."
    c "Me decepcionaría si no lo hicieras."

# game/script.rpy:2044
translate Paloslios hatend_0ae4252c:

    # "He gives a small nod, like I’ve met an expectation."
    "Él asiente levemente, como si hubiera cumplido una expectativa."

# game/script.rpy:2045
translate Paloslios hatend_89e69c09:

    # voice silas_v203
    # c "Take care of yourself."
    voice silas_v203
    c "Cuídate."

# game/script.rpy:2048
translate Paloslios hatend_d73a17b1:

    # "He turns and walks away, unbothered, the bell above the door chiming once as he leaves."
    "Se da vuelta y se aleja, sin molestarse, la campana sobre la puerta suena una vez cuando se va."

# game/script.rpy:2049
translate Paloslios hatend_f728729a:

    # "The door shuts."
    "La puerta se cierra."

# game/script.rpy:2053
translate Paloslios rememberend_60916446:

    # "My voice shakes despite my effort to keep it steady."
    "Mi voz tiembla a pesar de mi esfuerzo por mantenerla firme."

# game/script.rpy:2054
translate Paloslios rememberend_a9c5304b:

    # mc "Just.... Please remember me."
    mc "Sólo... Por favor, recuérdame."

# game/script.rpy:2055
translate Paloslios rememberend_25e1e0a5:

    # "He pauses."
    "Hace una pausa."

# game/script.rpy:2056
translate Paloslios rememberend_7007e747:

    # "Really pauses this time."
    "Realmente hace una pausa esta vez."

# game/script.rpy:2057
translate Paloslios rememberend_27bc770d:

    # "Slowly, he takes a step back toward me, studying my face with something quieter in his expression."
    "Lentamente, da un paso hacia mí, estudiando mi rostro con algo más tranquilo en su expresión."

# game/script.rpy:2058
translate Paloslios rememberend_6f127d38:

    # voice silas_v204
    voice silas_v204

# game/script.rpy:2060
translate Paloslios rememberend_a06126e7:

    # c "I won’t do that."
    c "No haré eso."

# game/script.rpy:2061
translate Paloslios rememberend_77f20d1a:

    # voice silas_v205
    voice silas_v205

# game/script.rpy:2064
translate Paloslios rememberend_8bafa6b5:

    # c "But I know you’ll remember me. That’s usually how it goes."
    c "Pero sé que me recordarás. Normalmente así es como sucede."

# game/script.rpy:2066
translate Paloslios rememberend_03c4a86d:

    # "He turns away, steps outside, and lets the door close behind him."
    "Se da vuelta, sale y deja que la puerta se cierre detrás de él."

# game/script.rpy:2067
translate Paloslios rememberend_1243a22f:

    # "The bell rings."
    "Suena el timbre."

# game/script.rpy:2072
translate Paloslios thankend_36244c85:

    # "I lift my chin, forcing the words past the tight knot in my throat."
    "Levanto la barbilla, forzando las palabras a superar el nudo apretado en mi garganta."

# game/script.rpy:2073
translate Paloslios thankend_a76dc4c2:

    # mc "Thank you for leaving me alone."
    mc "Gracias por dejarme en paz."

# game/script.rpy:2074
translate Paloslios thankend_28f46654:

    # "He exhales through his nose, concerned."
    "Exhala por la nariz, preocupado."

# game/script.rpy:2075
translate Paloslios thankend_5fcf16b1:

    # voice silas_v206
    voice silas_v206

# game/script.rpy:2077
translate Paloslios thankend_04f455b2:

    # c "Girl, where is your spine ?! That's pathetic."
    c "Chica, ¿dónde está tu columna? Eso es patético."

# game/script.rpy:2078
translate Paloslios thankend_8bc10372:

    # "He straightens, adjusting his jacket."
    "Se endereza y se ajusta la chaqueta."

# game/script.rpy:2079
translate Paloslios thankend_d459a42d:

    # voice silas_v207
    # c "You’ll be fine even if I were around. Get some self-respect."
    voice silas_v207
    c "Estarás bien incluso si yo estuviera cerca. Consigue algo de respeto por ti mismo."

# game/script.rpy:2082
translate Paloslios thankend_b81fa99b:

    # "Then he walks out, unhurried, like this was always just another errand on his list."
    "Luego sale, sin prisas, como si esto fuera siempre un recado más en su lista."

# game/script.rpy:2087
translate Paloslios COMMONENDING_809b2aba:

    # "And just like that-"
    "Y así de simple-"

# game/script.rpy:2088
translate Paloslios COMMONENDING_7b79030a:

    # "He’s gone."
    "Se ha ido."

# game/script.rpy:2090
translate Paloslios COMMONENDING_f4ef8e66:

    # "He doesn’t look back when he walks out of view."
    "No mira hacia atrás cuando se pierde de vista."

# game/script.rpy:2091
translate Paloslios COMMONENDING_e9872008:

    # "I sit there for a long moment, staring at the space across from me."
    "Me siento allí durante un largo momento, mirando el espacio frente a mí."

# game/script.rpy:2092
translate Paloslios COMMONENDING_fe390800:

    # "A moment passes before I actually dare to get up."
    "Pasa un momento antes de que me atreva a levantarme."

# game/script.rpy:2093
translate Paloslios COMMONENDING_f8fe92b3:

    # mc "I'm going home..."
    mc "Me voy a casa..."

