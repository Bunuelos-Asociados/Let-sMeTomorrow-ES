


    ####
    ##                                      ##
    ##  F95Zone Paloslios Renpy Translator  ##
    ##     https://ko-fi.com/paloslios      ##
    ##                                      ##
    ####



translate Paloslios strings:

    old "Choose your character's name"
    new "Elige el nombre de tu personaje"

    # game/script.rpy:166
    old "Hug him"
    new "abrázalo"

    # game/script.rpy:166
    old "Don’t hug"
    new "no abraces"

    # game/script.rpy:400
    old "Ask how he knows"
    new "Pregúntale cómo lo sabe."

    # game/script.rpy:400
    old "Let it go"
    new "déjalo ir"

    # game/script.rpy:518
    old "A Strawberry Milkshake"
    new "Un batido de fresa"

    # game/script.rpy:518
    old "A Chocolate Milkshake"
    new "Un batido de chocolate"

    # game/script.rpy:518
    old "A Vanilla Milkshake"
    new "Un batido de vainilla"

    # game/script.rpy:1023
    old "{sc=2}{color=#f60808}Confront the man"
    new "{sc=2}{color=#f60808}Enfrentar al hombre"

    # game/script.rpy:1023
    old "{sc=3}{color=#f60808}Get out and call the cops"
    new "{sc=3}{color=#f60808}Sal y llama a la policía."

    # game/script.rpy:1023
    old "{sc=2}{color=#f60808}Play along"
    new "{sc=2}{color=#f60808}Sigue el juego"

    # game/script.rpy:1309
    old "Tell him to back off, or you’ll scream"
    new "Dile que retroceda o gritarás."

    # game/script.rpy:1309
    old "Ask him what he wants"
    new "Pregúntale qué quiere"

    # game/script.rpy:1408
    old "{color=#f60808}Follow him "
    new "{color=#f60808}Síguelo "

    # game/script.rpy:1408
    old "{color=#f60808}Run away."
    new "{color=#f60808}Huye."

    # game/script.rpy:1534
    old "Say nothing."
    new "No digas nada."

    # game/script.rpy:1534
    old "Be honest."
    new "Sea honesto."

    # game/script.rpy:1701
    old "Drink the smoothie"
    new "bebe el batido"

    # game/script.rpy:1701
    old "Refuse to take the smoothie"
    new "Negarse a tomar el batido"

    # game/script.rpy:1750
    old "Why me ?"
    new "¿Por qué yo?"

    # game/script.rpy:1750
    old "How did you lie the entire day ?"
    new "¿Cómo mentiste todo el día?"

    # game/script.rpy:1750
    old "Why did you do that ?"
    new "¿Por qué hiciste eso?"

    # game/script.rpy:1750
    old "Did you intend to hurt me in my apartment ?"
    new "¿Tenías la intención de hacerme daño en mi apartamento?"

    # game/script.rpy:1998
    old "Tell him you hate him."
    new "Dile que lo odias."

    # game/script.rpy:1998
    old "Ask him to remember you."
    new "Pídele que te recuerde."

    # game/script.rpy:1998
    old "Thank him for leaving."
    new "Agradécele por irse."

translate Paloslios strings:

    # game/options.rpy:16
    old "lets meet tomorow"
    new "nos vemos mañana"

translate Paloslios strings:

    # game/screens.rpy:252
    old "Back"
    new "Atrás"

    # game/screens.rpy:253
    old "Skip"
    new "saltar"

    # game/screens.rpy:254
    old "Auto"
    new "Automático"

    # game/screens.rpy:255
    old "Save"
    new "Guardar"

    # game/screens.rpy:258
    old "Prefs"
    new "Preferencias"

    # game/screens.rpy:306
    old "Start"
    new "Empezar"

    # game/screens.rpy:308
    old "Load"
    new "Cargar"

    # game/screens.rpy:310
    old "Preferences"
    new "Preferencias"

    # game/screens.rpy:314
    old "End Replay"
    new "Finalizar repetición"

    # game/screens.rpy:318
    old "Main Menu"
    new "Menú principal"

    # game/screens.rpy:320
    old "About"
    new "Acerca de"

    # game/screens.rpy:331
    old "Quit"
    new "dejar de fumar"

    # game/screens.rpy:536
    old "Return"
    new "regresar"

    # game/screens.rpy:628
    old "Made with {a=https://www.renpy.org/}Ren'Py{/a} [renpy.version_only].\n\n[renpy.license!t]"
    new "Hecho con {a=https://www.renpy.org/}Ren'Py{/a}[renpy.version_only].\n\n[renpy.license!t]"

    # game/screens.rpy:664
    old "Page {}"
    new "Página {}"

    # game/screens.rpy:664
    old "Automatic saves"
    new "Guardado automático"

    # game/screens.rpy:664
    old "Quick saves"
    new "Guardado rápido"

    # game/screens.rpy:706
    old "{#file_time}%A, %B %d %Y, %H:%M"
    new "{#file_time}%A, %B %d %Y, %H:%M"

    # game/screens.rpy:706
    old "empty slot"
    new "ranura vacía"

    # game/screens.rpy:726
    old "<"
    new "<"

    # game/screens.rpy:729
    old "{#auto_page}A"
    new "{#auto_page}A"

    # game/screens.rpy:732
    old "{#quick_page}Q"
    new "{#quick_page}P"

    # game/screens.rpy:738
    old ">"
    new ">"

    # game/screens.rpy:742
    old "Upload Sync"
    new "Subir sincronización"

    # game/screens.rpy:746
    old "Download Sync"
    new "Descargar sincronización"

    # game/screens.rpy:805
    old "Display"
    new "mostrar"

    # game/screens.rpy:806
    old "Window"
    new "ventana"

    # game/screens.rpy:807
    old "Fullscreen"
    new "Pantalla completa"

    # game/screens.rpy:812
    old "Unseen Text"
    new "Texto invisible"

    # game/screens.rpy:813
    old "After Choices"
    new "después de las elecciones"

    # game/screens.rpy:814
    old "Transitions"
    new "transiciones"

    # game/screens.rpy:827
    old "Text Speed"
    new "velocidad del texto"

    # game/screens.rpy:831
    old "Auto-Forward Time"
    new "tiempo de avance automático"

    # game/screens.rpy:838
    old "Music Volume"
    new "volumen de música"

    # game/screens.rpy:845
    old "Sound Volume"
    new "volumen de sonido"

    # game/screens.rpy:851
    old "Test"
    new "prueba"

    # game/screens.rpy:855
    old "Voice Volume"
    new "volumen de voz"

    # game/screens.rpy:866
    old "Mute All"
    new "silenciar todo"

    # game/screens.rpy:955
    old "Help"
    new "Ayuda"

    # game/screens.rpy:964
    old "Keyboard"
    new "Teclado"

    # game/screens.rpy:965
    old "Mouse"
    new "ratón"

    # game/screens.rpy:968
    old "Gamepad"
    new "Mando de juegos"

    # game/screens.rpy:981
    old "Enter"
    new "Entrar"

    # game/screens.rpy:982
    old "Advances dialogue and activates the interface."
    new "Avanza el diálogo y activa la interfaz."

    # game/screens.rpy:985
    old "Space"
    new "espacio"

    # game/screens.rpy:986
    old "Advances dialogue without selecting choices."
    new "Avanza el diálogo sin seleccionar opciones."

    # game/screens.rpy:989
    old "Arrow Keys"
    new "Teclas de flecha"

    # game/screens.rpy:990
    old "Navigate the interface."
    new "Navega por la interfaz."

    # game/screens.rpy:993
    old "Escape"
    new "escapar"

    # game/screens.rpy:994
    old "Accesses the game menu."
    new "Accede al menú del juego."

    # game/screens.rpy:997
    old "Ctrl"
    new "control"

    # game/screens.rpy:998
    old "Skips dialogue while held down."
    new "Salta el diálogo mientras se mantiene presionado."

    # game/screens.rpy:1001
    old "Tab"
    new "Pestaña"

    # game/screens.rpy:1002
    old "Toggles dialogue skipping."
    new "Alterna la omisión de diálogos."

    # game/screens.rpy:1005
    old "Page Up"
    new "Página arriba"

    # game/screens.rpy:1006
    old "Rolls back to earlier dialogue."
    new "Vuelve al diálogo anterior."

    # game/screens.rpy:1009
    old "Page Down"
    new "Página abajo"

    # game/screens.rpy:1010
    old "Rolls forward to later dialogue."
    new "Avanza al diálogo posterior."

    # game/screens.rpy:1014
    old "Hides the user interface."
    new "Oculta la interfaz de usuario."

    # game/screens.rpy:1018
    old "Takes a screenshot."
    new "Toma una captura de pantalla."

    # game/screens.rpy:1022
    old "Toggles assistive {a=https://www.renpy.org/l/voicing}self-voicing{/a}."
    new "Alterna la voz propia {a=https://www.renpy.org/l/voicing}de asistencia{/a}."

    # game/screens.rpy:1026
    old "Opens the accessibility menu."
    new "Abre el menú de accesibilidad."

    # game/screens.rpy:1032
    old "Left Click"
    new "Clic izquierdo"

    # game/screens.rpy:1036
    old "Middle Click"
    new "Clic central"

    # game/screens.rpy:1040
    old "Right Click"
    new "Clic derecho"

    # game/screens.rpy:1044
    old "Mouse Wheel Up"
    new "Rueda del ratón hacia arriba"

    # game/screens.rpy:1048
    old "Mouse Wheel Down"
    new "Rueda del ratón hacia abajo"

    # game/screens.rpy:1055
    old "Right Trigger\nA/Bottom Button"
    new "Gatillo derecho\nA/Botón inferior"

    # game/screens.rpy:1059
    old "Left Trigger\nLeft Shoulder"
    new "Gatillo izquierdo\nHombro izquierdo"

    # game/screens.rpy:1063
    old "Right Shoulder"
    new "Hombro derecho"

    # game/screens.rpy:1067
    old "D-Pad, Sticks"
    new "Pad direccional, baquetas"

    # game/screens.rpy:1071
    old "Start, Guide, B/Right Button"
    new "Inicio, Guía, Botón B/Derecha"

    # game/screens.rpy:1075
    old "Y/Top Button"
    new "Botón Y/arriba"

    # game/screens.rpy:1078
    old "Calibrate"
    new "Calibrar"

    # game/screens.rpy:1143
    old "Yes"
    new "si"

    # game/screens.rpy:1144
    old "No"
    new "No"

    # game/screens.rpy:1190
    old "Skipping"
    new "saltando"

    # game/screens.rpy:1504
    old "Menu"
    new "Menú"

translate Paloslios strings:

    # renpy/common/00accessibility.rpy:28
    old "Self-voicing disabled."
    new "Voz propia desactivada."

    # renpy/common/00accessibility.rpy:29
    old "Clipboard voicing enabled. "
    new "Voz del portapapeles habilitada. "

    # renpy/common/00accessibility.rpy:30
    old "Self-voicing enabled. "
    new "Auto-voz habilitada. "

    # renpy/common/00accessibility.rpy:32
    old "bar"
    new "barra"

    # renpy/common/00accessibility.rpy:33
    old "selected"
    new "seleccionado"

    # renpy/common/00accessibility.rpy:34
    old "viewport"
    new "ventana gráfica"

    # renpy/common/00accessibility.rpy:35
    old "horizontal scroll"
    new "desplazamiento horizontal"

    # renpy/common/00accessibility.rpy:36
    old "vertical scroll"
    new "desplazamiento vertical"

    # renpy/common/00accessibility.rpy:37
    old "activate"
    new "activar"

    # renpy/common/00accessibility.rpy:38
    old "deactivate"
    new "desactivar"

    # renpy/common/00accessibility.rpy:39
    old "increase"
    new "aumentar"

    # renpy/common/00accessibility.rpy:40
    old "decrease"
    new "disminuir"

    # renpy/common/00accessibility.rpy:122
    old "Accessibility Menu. Use up and down arrows to navigate, and enter to activate buttons and bars."
    new "Menú de accesibilidad. Utilice las flechas hacia arriba y hacia abajo para navegar e ingrese para activar botones y barras."

    # renpy/common/00accessibility.rpy:141
    old "Font Override"
    new "Anulación de fuente"

    # renpy/common/00accessibility.rpy:145
    old "Default"
    new "Predeterminado"

    # renpy/common/00accessibility.rpy:149
    old "DejaVu Sans"
    new "DejaVu Sans"

    # renpy/common/00accessibility.rpy:153
    old "Opendyslexic"
    new "disléxico abierto"

    # renpy/common/00accessibility.rpy:159
    old "Text Size Scaling"
    new "Escala del tamaño del texto"

    # renpy/common/00accessibility.rpy:165
    old "Reset"
    new "Reiniciar"

    # renpy/common/00accessibility.rpy:171
    old "Line Spacing Scaling"
    new "Escala de interlineado"

    # renpy/common/00accessibility.rpy:183
    old "High Contrast Text"
    new "texto de alto contraste"

    # renpy/common/00accessibility.rpy:185
    old "Enable"
    new "Habilitar"

    # renpy/common/00accessibility.rpy:189
    old "Disable"
    new "Desactivar"

    # renpy/common/00accessibility.rpy:196
    old "Self-Voicing"
    new "Autoexpresión"

    # renpy/common/00accessibility.rpy:199
    old "Self-voicing support is limited when using a touch screen."
    new "La compatibilidad con la voz propia es limitada cuando se utiliza una pantalla táctil."

    # renpy/common/00accessibility.rpy:203
    old "Off"
    new "Apagado"

    # renpy/common/00accessibility.rpy:207
    old "Text-to-speech"
    new "Texto a voz"

    # renpy/common/00accessibility.rpy:211
    old "Clipboard"
    new "portapapeles"

    # renpy/common/00accessibility.rpy:215
    old "Debug"
    new "Depurar"

    # renpy/common/00accessibility.rpy:229
    old "Self-Voicing Volume Drop"
    new "Caída de volumen de voz propia"

    # renpy/common/00accessibility.rpy:238
    old "The options on this menu are intended to improve accessibility. They may not work with all games, and some combinations of options may render the game unplayable. This is not an issue with the game or engine. For the best results when changing fonts, try to keep the text size the same as it originally was."
    new "Las opciones de este menú están destinadas a mejorar la accesibilidad. Es posible que no funcionen con todos los juegos y algunas combinaciones de opciones pueden hacer que el juego no se pueda reproducir. Esto no es un problema con el juego o el motor. Para obtener mejores resultados al cambiar las fuentes, intente mantener el tamaño del texto igual que originalmente."

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Monday"
    new "{#weekday}lunes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Tuesday"
    new "{#weekday}Martes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Wednesday"
    new "{#weekday}miércoles"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Thursday"
    new "{#weekday}jueves"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Friday"
    new "{#weekday}viernes"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Saturday"
    new "{#weekday}sábado"

    # renpy/common/00action_file.rpy:26
    old "{#weekday}Sunday"
    new "{#weekday}Domingo"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Mon"
    new "{#weekday_short}lunes"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Tue"
    new "{#weekday_short}martes"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Wed"
    new "{#weekday_short}miércoles"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Thu"
    new "{#weekday_short}jueves"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Fri"
    new "{#weekday_short}viernes"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sat"
    new "{#weekday_short}sáb"

    # renpy/common/00action_file.rpy:37
    old "{#weekday_short}Sun"
    new "{#weekday_short}sol"

    # renpy/common/00action_file.rpy:47
    old "{#month}January"
    new "{#month}enero"

    # renpy/common/00action_file.rpy:47
    old "{#month}February"
    new "{#month}febrero"

    # renpy/common/00action_file.rpy:47
    old "{#month}March"
    new "{#month}marzo"

    # renpy/common/00action_file.rpy:47
    old "{#month}April"
    new "{#month}abril"

    # renpy/common/00action_file.rpy:47
    old "{#month}May"
    new "{#month}mayo"

    # renpy/common/00action_file.rpy:47
    old "{#month}June"
    new "{#month}junio"

    # renpy/common/00action_file.rpy:47
    old "{#month}July"
    new "{#month}julio"

    # renpy/common/00action_file.rpy:47
    old "{#month}August"
    new "{#month}agosto"

    # renpy/common/00action_file.rpy:47
    old "{#month}September"
    new "{#month}septiembre"

    # renpy/common/00action_file.rpy:47
    old "{#month}October"
    new "{#month}octubre"

    # renpy/common/00action_file.rpy:47
    old "{#month}November"
    new "{#month}Noviembre"

    # renpy/common/00action_file.rpy:47
    old "{#month}December"
    new "{#month}diciembre"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jan"
    new "{#month_short}enero"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Feb"
    new "{#month_short}febrero"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Mar"
    new "{#month_short}marzo"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Apr"
    new "{#month_short}abril"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}May"
    new "{#month_short}mayo"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jun"
    new "{#month_short}junio"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Jul"
    new "{#month_short}julio"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Aug"
    new "{#month_short}agosto"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Sep"
    new "{#month_short}septiembre"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Oct"
    new "{#month_short}octubre"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Nov"
    new "{#month_short}noviembre"

    # renpy/common/00action_file.rpy:63
    old "{#month_short}Dec"
    new "{#month_short}diciembre"

    # renpy/common/00action_file.rpy:258
    old "%b %d, %H:%M"
    new "%b %d, %H:%M"

    # renpy/common/00action_file.rpy:395
    old "Save slot %s: [text]"
    new "Guardar espacio %s: [text]"

    # renpy/common/00action_file.rpy:481
    old "Load slot %s: [text]"
    new "Cargar ranura %s: [text]"

    # renpy/common/00action_file.rpy:534
    old "Delete slot [text]"
    new "Eliminar ranura [text]"

    # renpy/common/00action_file.rpy:613
    old "File page auto"
    new "Página de archivo automática"

    # renpy/common/00action_file.rpy:615
    old "File page quick"
    new "Archivo de página rápido"

    # renpy/common/00action_file.rpy:617
    old "File page [text]"
    new "Página de archivo [text]"

    # renpy/common/00action_file.rpy:816
    old "Next file page."
    new "Siguiente página del archivo."

    # renpy/common/00action_file.rpy:888
    old "Previous file page."
    new "Página del archivo anterior."

    # renpy/common/00action_file.rpy:949
    old "Quick save complete."
    new "Guardado rápido completo."

    # renpy/common/00action_file.rpy:964
    old "Quick save."
    new "Guardado rápido."

    # renpy/common/00action_file.rpy:983
    old "Quick load."
    new "Carga rápida."

    # renpy/common/00action_other.rpy:416
    old "Language [text]"
    new "Idioma [text]"

    # renpy/common/00action_other.rpy:781
    old "Open [text] directory."
    new "Abra el directorio [text]."

    # renpy/common/00director.rpy:712
    old "The interactive director is not enabled here."
    new "El director interactivo no está habilitado aquí."

    # renpy/common/00director.rpy:1512
    old "⬆"
    new "⬆"

    # renpy/common/00director.rpy:1518
    old "⬇"
    new "⬇"

    # renpy/common/00director.rpy:1582
    old "Done"
    new "hecho"

    # renpy/common/00director.rpy:1592
    old "(statement)"
    new "(declaración)"

    # renpy/common/00director.rpy:1593
    old "(tag)"
    new "(etiqueta)"

    # renpy/common/00director.rpy:1594
    old "(attributes)"
    new "(atributos)"

    # renpy/common/00director.rpy:1595
    old "(transform)"
    new "(transformar)"

    # renpy/common/00director.rpy:1620
    old "(transition)"
    new "(transición)"

    # renpy/common/00director.rpy:1632
    old "(channel)"
    new "(canal)"

    # renpy/common/00director.rpy:1633
    old "(filename)"
    new "(nombre de archivo)"

    # renpy/common/00director.rpy:1662
    old "Change"
    new "Cambiar"

    # renpy/common/00director.rpy:1664
    old "Add"
    new "Añadir"

    # renpy/common/00director.rpy:1667
    old "Cancel"
    new "Cancelar"

    # renpy/common/00director.rpy:1670
    old "Remove"
    new "Quitar"

    # renpy/common/00director.rpy:1705
    old "Statement:"
    new "Declaración:"

    # renpy/common/00director.rpy:1726
    old "Tag:"
    new "Etiqueta:"

    # renpy/common/00director.rpy:1742
    old "Attributes:"
    new "Atributos:"

    # renpy/common/00director.rpy:1753
    old "Click to toggle attribute, right click to toggle negative attribute."
    new "Haga clic para alternar el atributo, haga clic derecho para alternar el atributo negativo."

    # renpy/common/00director.rpy:1765
    old "Transforms:"
    new "Transforma:"

    # renpy/common/00director.rpy:1776
    old "Click to set transform, right click to add to transform list."
    new "Haga clic para configurar la transformación, haga clic derecho para agregar a la lista de transformación."

    # renpy/common/00director.rpy:1777
    old "Customize director.transforms to add more transforms."
    new "Personalice director.transforms para agregar más transformaciones."

    # renpy/common/00director.rpy:1789
    old "Behind:"
    new "Detrás:"

    # renpy/common/00director.rpy:1800
    old "Click to set, right click to add to behind list."
    new "Haga clic para configurar, haga clic derecho para agregar a la lista detrás."

    # renpy/common/00director.rpy:1812
    old "Transition:"
    new "Transición:"

    # renpy/common/00director.rpy:1822
    old "Click to set."
    new "Haga clic para configurar."

    # renpy/common/00director.rpy:1823
    old "Customize director.transitions to add more transitions."
    new "Personalice director.transitions para agregar más transiciones."

    # renpy/common/00director.rpy:1835
    old "Channel:"
    new "Canal:"

    # renpy/common/00director.rpy:1846
    old "Customize director.audio_channels to add more channels."
    new "Personalice director.audio_channels para agregar más canales."

    # renpy/common/00director.rpy:1858
    old "Audio Filename:"
    new "Nombre del archivo de audio:"

    # renpy/common/00gui.rpy:448
    old "Are you sure?"
    new "¿Estás seguro?"

    # renpy/common/00gui.rpy:449
    old "Are you sure you want to delete this save?"
    new "¿Estás seguro de que deseas eliminar este guardado?"

    # renpy/common/00gui.rpy:450
    old "Are you sure you want to overwrite your save?"
    new "¿Estás seguro de que quieres sobrescribir tu guardado?"

    # renpy/common/00gui.rpy:451
    old "Loading will lose unsaved progress.\nAre you sure you want to do this?"
    new "Al cargar se perderá el progreso no guardado.\n¿Estás seguro de que quieres hacer esto?"

    # renpy/common/00gui.rpy:452
    old "Are you sure you want to quit?"
    new "¿Estás seguro de que quieres dejar de fumar?"

    # renpy/common/00gui.rpy:453
    old "Are you sure you want to return to the main menu?\nThis will lose unsaved progress."
    new "¿Estás seguro de que deseas volver al menú principal?\nEsto perderá el progreso no guardado."

    # renpy/common/00gui.rpy:454
    old "Are you sure you want to continue where you left off?"
    new "¿Estás seguro de que quieres continuar donde lo dejaste?"

    # renpy/common/00gui.rpy:455
    old "Are you sure you want to end the replay?"
    new "¿Estás seguro de que quieres finalizar la repetición?"

    # renpy/common/00gui.rpy:456
    old "Are you sure you want to begin skipping?"
    new "¿Estás seguro de que quieres empezar a saltar?"

    # renpy/common/00gui.rpy:457
    old "Are you sure you want to skip to the next choice?"
    new "¿Está seguro de que desea pasar a la siguiente opción?"

    # renpy/common/00gui.rpy:458
    old "Are you sure you want to skip unseen dialogue to the next choice?"
    new "¿Estás seguro de que deseas saltar el diálogo invisible a la siguiente opción?"

    # renpy/common/00gui.rpy:459
    old "This save was created on a different device. Maliciously constructed save files can harm your computer. Do you trust this save's creator and everyone who could have changed the file?"
    new "Este guardado se creó en un dispositivo diferente. Los archivos guardados creados con fines malintencionados pueden dañar su computadora. ¿Confías en el creador de este guardado y en todos los que podrían haber cambiado el archivo?"

    # renpy/common/00gui.rpy:460
    old "Do you trust the device the save was created on? You should only choose yes if you are the device's sole user."
    new "¿Confías en el dispositivo en el que se creó el guardado? Sólo debes elegir Sí si eres el único usuario del dispositivo."

    # renpy/common/00keymap.rpy:325
    old "Failed to save screenshot as %s."
    new "No se pudo guardar la captura de pantalla como %s."

    # renpy/common/00keymap.rpy:346
    old "Saved screenshot as %s."
    new "Captura de pantalla guardada como %s."

    # renpy/common/00library.rpy:257
    old "Skip Mode"
    new "Modo de salto"

    # renpy/common/00library.rpy:344
    old "This program contains free software under a number of licenses, including the MIT License and GNU Lesser General Public License. A complete list of software, including links to full source code, can be found {a=https://www.renpy.org/l/license}here{/a}."
    new "Este programa contiene software gratuito bajo varias licencias, incluida la licencia MIT y la licencia pública general reducida GNU. Puede encontrar una lista completa de software, incluidos enlaces al código fuente completo, {a=https://www.renpy.org/l/license}aquí{/a}."

    # renpy/common/00preferences.rpy:290
    old "display"
    new "mostrar"

    # renpy/common/00preferences.rpy:310
    old "transitions"
    new "transiciones"

    # renpy/common/00preferences.rpy:319
    old "skip transitions"
    new "saltar transiciones"

    # renpy/common/00preferences.rpy:321
    old "video sprites"
    new "sprites de vídeo"

    # renpy/common/00preferences.rpy:330
    old "show empty window"
    new "mostrar ventana vacía"

    # renpy/common/00preferences.rpy:339
    old "text speed"
    new "velocidad del texto"

    # renpy/common/00preferences.rpy:347
    old "joystick"
    new "palanca de mando"

    # renpy/common/00preferences.rpy:347
    old "joystick..."
    new "palanca de mando..."

    # renpy/common/00preferences.rpy:354
    old "skip"
    new "saltar"

    # renpy/common/00preferences.rpy:357
    old "skip unseen [text]"
    new "saltar sin ser visto [text]"

    # renpy/common/00preferences.rpy:362
    old "skip unseen text"
    new "saltar texto no visto"

    # renpy/common/00preferences.rpy:364
    old "begin skipping"
    new "comenzar a saltar"

    # renpy/common/00preferences.rpy:368
    old "after choices"
    new "después de las elecciones"

    # renpy/common/00preferences.rpy:375
    old "skip after choices"
    new "saltar después de las opciones"

    # renpy/common/00preferences.rpy:377
    old "auto-forward time"
    new "tiempo de avance automático"

    # renpy/common/00preferences.rpy:391
    old "auto-forward"
    new "reenvío automático"

    # renpy/common/00preferences.rpy:398
    old "Auto forward"
    new "Avance automático"

    # renpy/common/00preferences.rpy:401
    old "auto-forward after click"
    new "reenvío automático después de hacer clic"

    # renpy/common/00preferences.rpy:410
    old "automatic move"
    new "movimiento automático"

    # renpy/common/00preferences.rpy:419
    old "wait for voice"
    new "espera la voz"

    # renpy/common/00preferences.rpy:428
    old "voice sustain"
    new "sostenimiento de voz"

    # renpy/common/00preferences.rpy:437
    old "self voicing"
    new "autoexpresión"

    # renpy/common/00preferences.rpy:440
    old "self voicing enable"
    new "habilitación de voz propia"

    # renpy/common/00preferences.rpy:442
    old "self voicing disable"
    new "desactivar la voz propia"

    # renpy/common/00preferences.rpy:446
    old "self voicing volume drop"
    new "caída del volumen de la voz propia"

    # renpy/common/00preferences.rpy:454
    old "clipboard voicing"
    new "portapapeles"

    # renpy/common/00preferences.rpy:457
    old "clipboard voicing enable"
    new "habilitar la voz del portapapeles"

    # renpy/common/00preferences.rpy:459
    old "clipboard voicing disable"
    new "desactivar la voz del portapapeles"

    # renpy/common/00preferences.rpy:463
    old "debug voicing"
    new "depurar voz"

    # renpy/common/00preferences.rpy:466
    old "debug voicing enable"
    new "habilitar voz de depuración"

    # renpy/common/00preferences.rpy:468
    old "debug voicing disable"
    new "depurar voz desactivar"

    # renpy/common/00preferences.rpy:472
    old "emphasize audio"
    new "enfatizar el audio"

    # renpy/common/00preferences.rpy:481
    old "rollback side"
    new "lado de retroceso"

    # renpy/common/00preferences.rpy:491
    old "gl powersave"
    new "ahorro de energía gl"

    # renpy/common/00preferences.rpy:497
    old "gl framerate"
    new "velocidad de fotogramas gl"

    # renpy/common/00preferences.rpy:500
    old "gl tearing"
    new "vaso desgarrado"

    # renpy/common/00preferences.rpy:503
    old "font transform"
    new "transformación de fuente"

    # renpy/common/00preferences.rpy:506
    old "font size"
    new "tamaño de fuente"

    # renpy/common/00preferences.rpy:514
    old "font line spacing"
    new "interlineado de fuente"

    # renpy/common/00preferences.rpy:522
    old "system cursor"
    new "cursor del sistema"

    # renpy/common/00preferences.rpy:531
    old "renderer menu"
    new "menú de renderizado"

    # renpy/common/00preferences.rpy:534
    old "accessibility menu"
    new "menú de accesibilidad"

    # renpy/common/00preferences.rpy:537
    old "high contrast text"
    new "texto de alto contraste"

    # renpy/common/00preferences.rpy:546
    old "audio when minimized"
    new "audio cuando está minimizado"

    # renpy/common/00preferences.rpy:555
    old "audio when unfocused"
    new "audio cuando está desenfocado"

    # renpy/common/00preferences.rpy:564
    old "web cache preload"
    new "precarga de caché web"

    # renpy/common/00preferences.rpy:579
    old "voice after game menu"
    new "menú de voz después del juego"

    # renpy/common/00preferences.rpy:588
    old "restore window position"
    new "restaurar la posición de la ventana"

    # renpy/common/00preferences.rpy:597
    old "reset"
    new "Reiniciar"

    # renpy/common/00preferences.rpy:610
    old "main volume"
    new "volumen principal"

    # renpy/common/00preferences.rpy:611
    old "music volume"
    new "volumen de música"

    # renpy/common/00preferences.rpy:612
    old "sound volume"
    new "volumen de sonido"

    # renpy/common/00preferences.rpy:613
    old "voice volume"
    new "volumen de voz"

    # renpy/common/00preferences.rpy:614
    old "mute main"
    new "silenciar principal"

    # renpy/common/00preferences.rpy:615
    old "mute music"
    new "música muda"

    # renpy/common/00preferences.rpy:616
    old "mute sound"
    new "sonido mudo"

    # renpy/common/00preferences.rpy:617
    old "mute voice"
    new "voz muda"

    # renpy/common/00preferences.rpy:618
    old "mute all"
    new "silenciar todo"

    # renpy/common/00preferences.rpy:701
    old "Clipboard voicing enabled. Press 'shift+C' to disable."
    new "Voz del portapapeles habilitada. Presione 'shift+C' para desactivar."

    # renpy/common/00preferences.rpy:703
    old "Self-voicing would say \"[renpy.display.tts.last]\". Press 'alt+shift+V' to disable."
    new "La voz propia diría \"[renpy.display.tts.last]\". Presione 'alt+shift+V' para desactivar."

    # renpy/common/00preferences.rpy:705
    old "Self-voicing enabled. Press 'v' to disable."
    new "Auto-voz habilitada. Presione 'v' para desactivar."

    # renpy/common/00speechbubble.rpy:420
    old "Speech Bubble Editor"
    new "Editor de burbujas de discurso"

    # renpy/common/00speechbubble.rpy:425
    old "(hide)"
    new "(ocultar)"

    # renpy/common/00speechbubble.rpy:436
    old "(clear retained bubbles)"
    new "(burbujas retenidas claras)"

    # renpy/common/00sync.rpy:70
    old "Sync downloaded."
    new "Sincronización descargada."

    # renpy/common/00sync.rpy:193
    old "Could not connect to the Ren'Py Sync server."
    new "No se pudo conectar al servidor Ren'Py Sync."

    # renpy/common/00sync.rpy:195
    old "The Ren'Py Sync server timed out."
    new "Se agotó el tiempo de espera del servidor Ren'Py Sync."

    # renpy/common/00sync.rpy:197
    old "An unknown error occurred while connecting to the Ren'Py Sync server."
    new "Se produjo un error desconocido al conectarse al servidor Ren'Py Sync."

    # renpy/common/00sync.rpy:213
    old "The Ren'Py Sync server does not have a copy of this sync. The sync ID may be invalid, or it may have timed out."
    new "El servidor Ren'Py Sync no tiene una copia de esta sincronización. Es posible que el ID de sincronización no sea válido o que se haya agotado el tiempo de espera."

    # renpy/common/00sync.rpy:316
    old "Please enter the sync ID you generated.\nNever enter a sync ID you didn't create yourself."
    new "Ingrese el ID de sincronización que generó.\nNunca ingrese un ID de sincronización que no haya creado usted mismo."

    # renpy/common/00sync.rpy:335
    old "The sync ID is not in the correct format."
    new "El ID de sincronización no tiene el formato correcto."

    # renpy/common/00sync.rpy:355
    old "The sync could not be decrypted."
    new "No se pudo descifrar la sincronización."

    # renpy/common/00sync.rpy:378
    old "The sync belongs to a different game."
    new "La sincronización pertenece a un juego diferente."

    # renpy/common/00sync.rpy:383
    old "The sync contains a file with an invalid name."
    new "La sincronización contiene un archivo con un nombre no válido."

    # renpy/common/00sync.rpy:440
    old "This will upload your saves to the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}.\nDo you want to continue?"
    new "Esto cargará tus archivos guardados en el {a=https://sync.renpy.org}Servidor de sincronización Ren'Py{/a}.\n¿Quieres continuar?"

    # renpy/common/00sync.rpy:472
    old "Enter Sync ID"
    new "Introduce el ID de sincronización"

    # renpy/common/00sync.rpy:483
    old "This will contact the {a=https://sync.renpy.org}Ren'Py Sync Server{/a}."
    new "Esto se pondrá en contacto con el {a=https://sync.renpy.org}Servidor de sincronización Ren'Py{/a}."

    # renpy/common/00sync.rpy:513
    old "Sync Success"
    new "Sincronización exitosa"

    # renpy/common/00sync.rpy:516
    old "The Sync ID is:"
    new "El ID de sincronización es:"

    # renpy/common/00sync.rpy:522
    old "You can use this ID to download your save on another device.\nThis sync will expire in an hour.\nRen'Py Sync is supported by {a=https://www.renpy.org/sponsors.html}Ren'Py's Sponsors{/a}."
    new "Puedes usar esta ID para descargar tu archivo guardado en otro dispositivo.\nEsta sincronización caducará en una hora.\nRen'Py Sync cuenta con el respaldo de {a=https://www.renpy.org/sponsors.html}Patrocinadores de Ren'Py{/a}."

    # renpy/common/00sync.rpy:526
    old "Continue"
    new "Continuar"

    # renpy/common/00sync.rpy:551
    old "Sync Error"
    new "Error de sincronización"

    # renpy/common/00translation.rpy:63
    old "Translation identifier: [identifier]"
    new "Identificador de traducción: [identifier]"

    # renpy/common/00translation.rpy:84
    old " translates [tl.filename]:[tl.linenumber]"
    new " traduce [tl.filename]:[tl.linenumber]"

    # renpy/common/00translation.rpy:101
    old "\n{color=#fff}Copied to clipboard.{/color}"
    new "\n{color=#fff}Copiado al portapapeles.{/color}"

    # renpy/common/00iap.rpy:231
    old "Contacting App Store\nPlease Wait..."
    new "Contactando a App Store\nEspere..."

    # renpy/common/00updater.rpy:505
    old "No update methods found."
    new "No se encontraron métodos de actualización."

    # renpy/common/00updater.rpy:552
    old "Could not download file list: "
    new "No se pudo descargar la lista de archivos: "

    # renpy/common/00updater.rpy:555
    old "File list digest does not match."
    new "El resumen de la lista de archivos no coincide."

    # renpy/common/00updater.rpy:765
    old "An error is being simulated."
    new "Se está simulando un error."

    # renpy/common/00updater.rpy:953
    old "Either this project does not support updating, or the update status file was deleted."
    new "O este proyecto no admite actualizaciones o se eliminó el archivo de estado de actualización."

    # renpy/common/00updater.rpy:967
    old "This account does not have permission to perform an update."
    new "Esta cuenta no tiene permiso para realizar una actualización."

    # renpy/common/00updater.rpy:970
    old "This account does not have permission to write the update log."
    new "Esta cuenta no tiene permiso para escribir el registro de actualización."

    # renpy/common/00updater.rpy:1050
    old "Could not verify update signature."
    new "No se pudo verificar la firma de actualización."

    # renpy/common/00updater.rpy:1373
    old "The update file was not downloaded."
    new "El archivo de actualización no se descargó."

    # renpy/common/00updater.rpy:1391
    old "The update file does not have the correct digest - it may have been corrupted."
    new "El archivo de actualización no tiene el resumen correcto; es posible que esté dañado."

    # renpy/common/00updater.rpy:1541
    old "While unpacking {}, unknown type {}."
    new "Mientras desembala {}, unknown type {}."

    # renpy/common/00updater.rpy:2022
    old "Updater"
    new "Actualizador"

    # renpy/common/00updater.rpy:2029
    old "An error has occured:"
    new "Ha ocurrido un error:"

    # renpy/common/00updater.rpy:2031
    old "Checking for updates."
    new "Buscando actualizaciones."

    # renpy/common/00updater.rpy:2033
    old "This program is up to date."
    new "Este programa está actualizado."

    # renpy/common/00updater.rpy:2035
    old "[u.version] is available. Do you want to install it?"
    new "[u.version] está disponible. ¿Quieres instalarlo?"

    # renpy/common/00updater.rpy:2037
    old "Preparing to download the updates."
    new "Preparándose para descargar las actualizaciones."

    # renpy/common/00updater.rpy:2039
    old "Downloading the updates."
    new "Descargando las actualizaciones."

    # renpy/common/00updater.rpy:2041
    old "Unpacking the updates."
    new "Descomprimiendo las actualizaciones."

    # renpy/common/00updater.rpy:2043
    old "Finishing up."
    new "Terminando."

    # renpy/common/00updater.rpy:2045
    old "The updates have been installed. The program will restart."
    new "Las actualizaciones han sido instaladas. El programa se reiniciará."

    # renpy/common/00updater.rpy:2047
    old "The updates have been installed."
    new "Las actualizaciones han sido instaladas."

    # renpy/common/00updater.rpy:2049
    old "The updates were cancelled."
    new "Las actualizaciones fueron canceladas."

    # renpy/common/00updater.rpy:2064
    old "Proceed"
    new "Continuar"

    # renpy/common/00updater.rpy:2080
    old "Preparing to download the game data."
    new "Preparándose para descargar los datos del juego."

    # renpy/common/00updater.rpy:2082
    old "Downloading the game data."
    new "Descargando los datos del juego."

    # renpy/common/00updater.rpy:2084
    old "The game data has been downloaded."
    new "Los datos del juego se han descargado."

    # renpy/common/00updater.rpy:2086
    old "An error occured when trying to download game data:"
    new "Se produjo un error al intentar descargar los datos del juego:"

    # renpy/common/00updater.rpy:2091
    old "This game cannot be run until the game data has been downloaded."
    new "Este juego no se puede ejecutar hasta que se hayan descargado los datos del juego."

    # renpy/common/00updater.rpy:2098
    old "Retry"
    new "Reintentar"

    # renpy/common/00gallery.rpy:643
    old "Image [index] of [count] locked."
    new "Imagen [index] de [count] bloqueada."

    # renpy/common/00gallery.rpy:663
    old "prev"
    new "anterior"

    # renpy/common/00gallery.rpy:664
    old "next"
    new "siguiente"

    # renpy/common/00gallery.rpy:665
    old "slideshow"
    new "presentación de diapositivas"

    # renpy/common/00gallery.rpy:666
    old "return"
    new "regresar"

    # renpy/common/00gltest.rpy:90
    old "Renderer"
    new "renderizador"

    # renpy/common/00gltest.rpy:94
    old "Automatically Choose"
    new "Elegir automáticamente"

    # renpy/common/00gltest.rpy:101
    old "Force GL Renderer"
    new "Forzar renderizador GL"

    # renpy/common/00gltest.rpy:106
    old "Force ANGLE Renderer"
    new "Forzar el renderizador de ÁNGULO"

    # renpy/common/00gltest.rpy:111
    old "Force GLES Renderer"
    new "Forzar renderizador GLES"

    # renpy/common/00gltest.rpy:117
    old "Force GL2 Renderer"
    new "Forzar renderizador GL2"

    # renpy/common/00gltest.rpy:122
    old "Force ANGLE2 Renderer"
    new "Forzar el renderizador ANGLE2"

    # renpy/common/00gltest.rpy:127
    old "Force GLES2 Renderer"
    new "Forzar el renderizador GLES2"

    # renpy/common/00gltest.rpy:137
    old "Enable (No Blocklist)"
    new "Habilitar (sin lista de bloqueo)"

    # renpy/common/00gltest.rpy:160
    old "Powersave"
    new "Ahorro de energía"

    # renpy/common/00gltest.rpy:174
    old "Framerate"
    new "Velocidad de fotogramas"

    # renpy/common/00gltest.rpy:178
    old "Screen"
    new "Pantalla"

    # renpy/common/00gltest.rpy:182
    old "60"
    new "60"

    # renpy/common/00gltest.rpy:186
    old "30"
    new "30"

    # renpy/common/00gltest.rpy:192
    old "Tearing"
    new "lagrimeo"

    # renpy/common/00gltest.rpy:208
    old "Changes will take effect the next time this program is run."
    new "Los cambios entrarán en vigor la próxima vez que se ejecute este programa."

    # renpy/common/00gltest.rpy:244
    old "Performance Warning"
    new "Advertencia de rendimiento"

    # renpy/common/00gltest.rpy:249
    old "This computer is using software rendering."
    new "Esta computadora está utilizando renderizado de software."

    # renpy/common/00gltest.rpy:251
    old "This game requires use of GL2 that can't be initialised."
    new "Este juego requiere el uso de GL2 que no se puede inicializar."

    # renpy/common/00gltest.rpy:253
    old "This computer has a problem displaying graphics: [problem]."
    new "Esta computadora tiene un problema al mostrar gráficos: [problem]."

    # renpy/common/00gltest.rpy:257
    old "Its graphics drivers may be out of date or not operating correctly. This can lead to slow or incorrect graphics display."
    new "Es posible que sus controladores de gráficos estén desactualizados o no funcionen correctamente. Esto puede provocar una visualización de gráficos lenta o incorrecta."

    # renpy/common/00gltest.rpy:261
    old "The {a=edit:1:log.txt}log.txt{/a} file may contain information to help you determine what is wrong with your computer."
    new "El archivo {a=edit:1:log.txt}log.txt{/a} puede contener información que le ayudará a determinar qué está mal en su computadora."

    # renpy/common/00gltest.rpy:266
    old "More details on how to fix this can be found in the {a=[url]}documentation{/a}."
    new "Puede encontrar más detalles sobre cómo solucionar este problema en la {a=[url]}documentación{/a}."

    # renpy/common/00gltest.rpy:271
    old "Continue, Show this warning again"
    new "Continuar, mostrar esta advertencia nuevamente"

    # renpy/common/00gltest.rpy:275
    old "Continue, Don't show warning again"
    new "Continuar, no volver a mostrar advertencia"

    # renpy/common/00gltest.rpy:283
    old "Change render options"
    new "Cambiar opciones de renderizado"

    # renpy/common/00gamepad.rpy:33
    old "Select Gamepad to Calibrate"
    new "Seleccione el mando para calibrar"

    # renpy/common/00gamepad.rpy:36
    old "No Gamepads Available"
    new "No hay mandos disponibles"

    # renpy/common/00gamepad.rpy:56
    old "Calibrating [name] ([i]/[total])"
    new "Calibrando [name] ([i]/[total])"

    # renpy/common/00gamepad.rpy:60
    old "Press or move the '[control!s]' [kind]."
    new "Presione o mueva el '[control!s]' [kind]."

    # renpy/common/00gamepad.rpy:70
    old "Skip (A)"
    new "Saltar (A)"

    # renpy/common/00gamepad.rpy:73
    old "Back (B)"
    new "Atrás (B)"

    # renpy/common/_errorhandling.rpym:674
    old "Open"
    new "Abierto"

    # renpy/common/_errorhandling.rpym:676
    old "Opens the traceback.txt file in a text editor."
    new "Abre el archivo traceback.txt en un editor de texto."

    # renpy/common/_errorhandling.rpym:678
    old "Copy BBCode"
    new "Copiar código BBC"

    # renpy/common/_errorhandling.rpym:680
    old "Copies the traceback.txt file to the clipboard as BBcode for forums like https://lemmasoft.renai.us/."
    new "Copia el archivo traceback.txt al portapapeles como BBcode para foros como https://lemmasoft.renai.us/."

    # renpy/common/_errorhandling.rpym:682
    old "Copy Markdown"
    new "Copiar rebajas"

    # renpy/common/_errorhandling.rpym:684
    old "Copies the traceback.txt file to the clipboard as Markdown for Discord."
    new "Copia el archivo traceback.txt al portapapeles como Markdown for Discord."

    # renpy/common/_errorhandling.rpym:716
    old "An exception has occurred."
    new "Ha ocurrido una excepción."

    # renpy/common/_errorhandling.rpym:739
    old "Rollback"
    new "Revertir"

    # renpy/common/_errorhandling.rpym:741
    old "Attempts a roll back to a prior time, allowing you to save or choose a different choice."
    new "Intenta retroceder a un momento anterior, lo que le permite guardar o elegir una opción diferente."

    # renpy/common/_errorhandling.rpym:744
    old "Ignore"
    new "ignorar"

    # renpy/common/_errorhandling.rpym:748
    old "Ignores the exception, allowing you to continue."
    new "Ignora la excepción y le permite continuar."

    # renpy/common/_errorhandling.rpym:750
    old "Ignores the exception, allowing you to continue. This often leads to additional errors."
    new "Ignora la excepción y le permite continuar. Esto suele provocar errores adicionales."

    # renpy/common/_errorhandling.rpym:754
    old "Reload"
    new "recargar"

    # renpy/common/_errorhandling.rpym:756
    old "Reloads the game from disk, saving and restoring game state if possible."
    new "Vuelve a cargar el juego desde el disco, guardando y restaurando el estado del juego si es posible."

    # renpy/common/_errorhandling.rpym:759
    old "Console"
    new "Consola"

    # renpy/common/_errorhandling.rpym:761
    old "Opens a console to allow debugging the problem."
    new "Abre una consola para permitir la depuración del problema."

    # renpy/common/_errorhandling.rpym:774
    old "Quits the game."
    new "Abandona el juego."

    # renpy/common/_errorhandling.rpym:796
    old "Parsing the script failed."
    new "Error al analizar el script."

translate Paloslios strings:

    # game/hook_add_change_language_entrance.rpy:64
    old "Language"
    new "Idioma"

