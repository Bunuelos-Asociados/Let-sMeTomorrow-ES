init python:

    config.language = "han_spanish"